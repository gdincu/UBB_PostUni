package Service;

import Domain.Cake;
import Repository.IOtherTeamRepository;

import java.util.List;

public class OtherTeamCakeService {
    private IOtherTeamRepository<Cake> repository;

    public OtherTeamCakeService(IOtherTeamRepository<Cake> repository) {
        this.repository = repository;
    }

    public void update(String id, String name, String ingredients, double calories, double price, boolean sugarFree) {
        Cake cake = new Cake(id, name, ingredients, calories, price, sugarFree);
        repository.update(cake);
    }

    public void add(String id, String name, String ingredients, double calories, double price, boolean sugarFree) {
        Cake cake = new Cake(id, name, ingredients, calories, price, sugarFree);
        repository.insert(cake);

    }

    public void remove(String id) {
        repository.remove(id);
    }

    public List<Cake> getAll() {
        return repository.getAll();
    }
}
