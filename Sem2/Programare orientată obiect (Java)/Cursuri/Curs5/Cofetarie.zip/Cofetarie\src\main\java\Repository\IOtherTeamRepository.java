package Repository;

import Domain.Entity;

import java.util.List;

public interface IOtherTeamRepository<T extends Entity> {
    T findById(String id);
    void insert(T cake);
    void update(T cake);
    void remove(String id);
    List<T> getAll();
}
