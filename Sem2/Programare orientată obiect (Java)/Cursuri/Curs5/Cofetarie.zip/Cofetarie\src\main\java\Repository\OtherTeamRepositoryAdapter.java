package Repository;

import Domain.Entity;

import java.util.List;

public class OtherTeamRepositoryAdapter<T extends Entity> implements IOtherTeamRepository<T> {

    private IRepository<T> adaptee;

    public OtherTeamRepositoryAdapter(IRepository<T> adaptee) {
        this.adaptee = adaptee;
    }

    @Override
    public T findById(String id) {
        return adaptee.findById(id);
    }

    @Override
    public void insert(T cake) {
        if (findById(cake.getId()) != null) {
            throw new RepositoryException("The given id already exists!");
        }

        adaptee.upsert(cake);
    }

    @Override
    public void update(T cake) {
        if (findById(cake.getId()) == null) {
            throw new RepositoryException("The given id doesn't exist!");
        }

        adaptee.upsert(cake);
    }

    @Override
    public void remove(String id) {
        adaptee.remove(id);
    }

    @Override
    public List<T> getAll() {
        return null;
    }
}
