package Service;

import Domain.Cake;
import Repository.IRepository;

import java.util.List;
import java.util.Stack;

public class CakeService {

    private IRepository<Cake> repository;
    private Stack<UndoRedoOperation<Cake>> undoableOperations = new Stack<>();
    private Stack<UndoRedoOperation<Cake>> redoableeOperations = new Stack<>();

    public CakeService(IRepository<Cake> repository) {
        this.repository = repository;
    }

    public void addOrUpdate(String id, String name, String ingredients, double calories, double price, boolean sugarFree) {
        Cake existing = repository.findById(id);
        if (existing != null) {
            // keep unchanged fields as they were
            if (name.isEmpty()) {
                name = existing.getName();
            }
            if (ingredients.isEmpty()) {
                ingredients = existing.getIngredients();
            }
            if (calories == 0) {
                calories = existing.getCalories();
            }
            if (price == 0) {
                price = existing.getPrice();
            }
            Cake cake = new Cake(id, name, ingredients, calories, price, sugarFree);
            repository.upsert(cake);
        } else {
            // sigur e add
            Cake cake = new Cake(id, name, ingredients, calories, price, sugarFree);
            repository.upsert(cake);
            undoableOperations.add(new AddOperation<>(repository, cake));
            redoableeOperations.clear();
        }

    }

    public void undo() {
        if (!undoableOperations.empty()) {
            UndoRedoOperation<Cake> lastOperation = undoableOperations.pop();
            lastOperation.doUndo();
            redoableeOperations.add(lastOperation);

        }
    }

    public void redo() {
        if (!redoableeOperations.empty()) {
            UndoRedoOperation<Cake> lastOperation = redoableeOperations.pop();
            lastOperation.doRedo();
            undoableOperations.add(lastOperation);
        }
    }

    public void remove(String id) {
        repository.remove(id);
    }

    public List<Cake> getAll() {
        return repository.getAll();
    }
}
