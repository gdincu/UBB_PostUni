package sample.Domain;

public class InvoiceDateFormatException extends RuntimeException {
    public InvoiceDateFormatException(String message) {
        super(message);
    }
}
