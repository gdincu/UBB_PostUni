package Tests;

import Domain.Cake;
import Domain.CakeValidator;
import Repository.IRepository;
import Repository.InMemoryRepository;

import static org.junit.jupiter.api.Assertions.*;

class CakeRepositoryTest {

    @org.junit.jupiter.api.Test
    void findByIdWithExistingIdShouldReturnCorrectCake() {

        IRepository<Cake> repo = new InMemoryRepository<>(new CakeValidator());
        Cake added = new Cake("1", "test", "test", 100,100,true);
        repo.upsert(added);
        Cake found = repo.findById("1");
        assertNotNull(found, "Returned null for existing id!");
        assertEquals("1", found.getId(), String.format("Returned id %s instead of correct id=1!", found.getId()));
        assertEquals("test", found.getName(), String.format("Returned name=%s instead of %s", found.getName(), added.getName()));
        // ... so on
    }

    @org.junit.jupiter.api.Test
    void upsert() {
    }

    @org.junit.jupiter.api.Test
    void remove() {
    }

    @org.junit.jupiter.api.Test
    void getAll() {
    }
}