package UI;

import Service.CakeService;
import javafx.event.ActionEvent;
import javafx.scene.control.Button;
import javafx.scene.control.CheckBox;
import javafx.scene.control.Spinner;
import javafx.scene.control.TextField;
import javafx.stage.Stage;

public class CakeAddController {
    public TextField txtName;
    public TextField txtIngredients;
    public TextField txtCalories;
    public TextField txtPrice;
    public CheckBox chkSugarFree;
    public Button btnAdd;
    public Button btnCancel;
    public Spinner spnId;

    private CakeService cakeService;

    public void setService(CakeService cakeService) {
        this.cakeService = cakeService;
    }

    public void btnCancelClick(ActionEvent actionEvent) {
        Stage stage = (Stage) btnCancel.getScene().getWindow();
        stage.close();
    }

    public void btnAddClick(ActionEvent actionEvent) {

        try {
            String id = String.valueOf(spnId.getValue());
            String name = txtName.getText();
            String ingredients = txtIngredients.getText();
            double calories = Double.parseDouble(txtCalories.getText());
            double price = Double.parseDouble(txtPrice.getText());
            boolean sugarFree = chkSugarFree.isSelected();

            cakeService.addOrUpdate(id, name, ingredients, calories, price, sugarFree);

            btnCancelClick(actionEvent);
        } catch (RuntimeException rex) {
            Common.showValidationError(rex.getMessage());
        }
    }
}
