package Service;

import Domain.Entity;
import Repository.IRepository;

import java.util.List;

public class ClearOperation<T extends Entity> extends UndoRedoOperation<T> {

    private List<T> clearedEntities;

    public ClearOperation(IRepository<T> repository, List<T> clearedEntities) {
        super(repository);
        this.clearedEntities = clearedEntities;
    }

    @Override
    public void doUndo() {
        for (T entity : clearedEntities) {
            repository.upsert(entity);
        }
    }

    @Override
    public void doRedo() {
        for (T entity : clearedEntities) {
            repository.remove(entity.getId());
        }
    }
}
