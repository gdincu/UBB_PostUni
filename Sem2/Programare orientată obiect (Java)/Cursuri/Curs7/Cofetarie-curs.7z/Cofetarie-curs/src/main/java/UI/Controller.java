package UI;

import Domain.Cake;
import Service.CakeService;
import Service.ClientService;
import Service.TransactionService;
import javafx.application.Platform;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.concurrent.Task;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.cell.TextFieldTableCell;
import javafx.stage.Modality;
import javafx.stage.Stage;
import javafx.util.converter.DoubleStringConverter;

import java.io.IOException;
import java.util.logging.Level;
import java.util.logging.Logger;


public class Controller {

    public TableView tableViewCakes;
    public TableColumn tableColumnId;
    public TableColumn tableColumnName;
    public TableColumn tableColumnIngredients;
    @FXML
    public TableColumn tableColumnCalories;
    public TableColumn tableColumnPrice;
    public TableColumn tableColumnSugarFree;
    public Button btnCakeDelete;
    public Button btnCakeAdd;
    public TableColumn tableColumnIdClient;
    public TableColumn tableColumnNameClient;
    public Button btnFiboNoThreads;
    public Label lblFiboResults;
    public Button btnFiboBadThreads;
    public Button btnFiboGoodThreads;

    private CakeService cakeService;
    private ClientService clientService;
    private TransactionService transactionService;

    private ObservableList<Cake> cakes = FXCollections.observableArrayList();

    public void setServices(CakeService cakeService, ClientService clientService, TransactionService transactionService) {
        this.cakeService = cakeService;
        this.clientService = clientService;
        this.transactionService = transactionService;
    }

    @FXML
    private void initialize() {

        Platform.runLater(() -> {
            tableColumnCalories.setCellFactory(TextFieldTableCell.forTableColumn(new DoubleStringConverter()));
            cakes.addAll(cakeService.getAll());
            tableViewCakes.setItems(cakes);
        });
    }

    public void editCakeName(TableColumn.CellEditEvent cellEditEvent) {
        Cake editedCake = (Cake)cellEditEvent.getRowValue();
        try {
            String newName = (String)cellEditEvent.getNewValue();
            cakeService.addOrUpdate(editedCake.getId(), newName, editedCake.getIngredients(), editedCake.getCalories(), editedCake.getPrice(), editedCake.isSugarFree());
            editedCake.setName(newName);
        } catch (RuntimeException rex) {
            Common.showValidationError(rex.getMessage());
        }
        tableViewCakes.refresh();
    }

    public void editCakeCalories(TableColumn.CellEditEvent cellEditEvent) {
        Cake editedCake = (Cake)cellEditEvent.getRowValue();
        try {
            double newCalories = (double)cellEditEvent.getNewValue();
            cakeService.addOrUpdate(editedCake.getId(), editedCake.getName(), editedCake.getIngredients(), newCalories, editedCake.getPrice(), editedCake.isSugarFree());
            editedCake.setCalories(newCalories);
        } catch (RuntimeException rex) {
            Common.showValidationError(rex.getMessage());
        }
        tableViewCakes.refresh();
    }

    public void btnCakeAddClick(ActionEvent actionEvent) {

        try {
            FXMLLoader fxmlLoader = new FXMLLoader();
            fxmlLoader.setLocation(getClass().getResource("/cakeAdd.fxml"));

            Scene scene = new Scene(fxmlLoader.load(), 600, 200);
            Stage stage = new Stage();
            stage.setTitle("Cake add");
            stage.setScene(scene);
            stage.initModality(Modality.APPLICATION_MODAL);
            CakeAddController controller =  fxmlLoader.getController();
            controller.setService(cakeService);
            stage.showAndWait();
            cakes.clear();
            cakes.addAll(cakeService.getAll());
        } catch (IOException e) {
            Logger logger = Logger.getLogger(getClass().getName());
            logger.log(Level.SEVERE, "Failed to create new Window: Cake add.", e);
        }
    }

    public void btnCakeDeleteClick(ActionEvent actionEvent) {
        Cake selected = (Cake)tableViewCakes.getSelectionModel().getSelectedItem();
        if (selected != null) {
            try {
                cakeService.remove(selected.getId());
                cakes.clear();
                cakes.addAll(cakeService.getAll());
            } catch (RuntimeException rex) {
                Common.showValidationError(rex.getMessage());
            }
        }
    }

    public void btnCakeUndoClick(ActionEvent actionEvent) {
        cakeService.undo();
        cakes.clear();
        cakes.addAll(cakeService.getAll());
    }

    public void btnCakeRedoClick(ActionEvent actionEvent) {
        cakeService.redo();
        cakes.clear();
        cakes.addAll(cakeService.getAll());
    }

    public void btnCakeClear(ActionEvent actionEvent) {
        cakeService.clear();
        cakes.clear();
        cakes.addAll(cakeService.getAll());
    }

    private long getFiboRecursive(int n) {
        if (n < 2) {
            return n;
        }

        return getFiboRecursive(n - 1) + getFiboRecursive(n - 2);
    }

    public void btnFiboNoThreadsClick(ActionEvent actionEvent) {
        lblFiboResults.setText("fibo(45)=" + getFiboRecursive(45));
    }

    public void btnFiboBadThreadsClick(ActionEvent actionEvent) {
        new Thread(() -> {
            lblFiboResults.setText("fibo(45)=" + getFiboRecursive(45));
        }).start();
    }

    public void btnFiboGoodThreadsClick(ActionEvent actionEvent) {

        Task<Long> task = new Task<Long>() {
            @Override
            public Long call() throws Exception {
                return getFiboRecursive(50);
            }
        };

        task.setOnSucceeded(event -> {
            lblFiboResults.setText("fibo(50)=" + task.getValue());
        });

        new Thread(task).start();
    }
}
