package UI;

import Domain.Cake;
import Service.CakeService;

import java.util.Scanner;

public class Console {
    private CakeService cakeService;
    private Scanner scanner;

    public Console(CakeService cakeService) {
        this.cakeService = cakeService;
        this.scanner = new Scanner(System.in);
    }

    public void run() {
        while (true) {
            showMenu();

            String option = scanner.nextLine();
            switch (option) {
                case "1":
                    runCakes();
                    break;
                case "2":
                    //runClients();
                    break;
                case "3":
                    //runTransactions();
                    break;
                case "x":
                    return;
                default:
                    System.out.println("Optiune invalida!");
                    break;
            }
        }
    }

    private void runCakes() {
        while (true) {
            showCakesMenu();
            String option = scanner.nextLine();
            switch (option) {
                case "1":
                    handleAddCake();
                    break;
                case "2":
                    handleUpdateCake();
                    break;
                case "3":
                    handleRemoveCake();
                    break;
                case "4":
                    handleShowAllCakes();
                    break;
                case "x":
                    return;
                default:
                    System.out.println("Optiune invalida!");
            }
        }
    }

    private void handleShowAllCakes() {
        for (Cake cake : cakeService.getAll()) {
            System.out.println(cake);
        }
    }

    private void handleRemoveCake() {
        try {
            System.out.print("Enter id to remove: ");
            String id = scanner.nextLine();

            cakeService.remove(id);

            System.out.println("Cake removed successfully!");
        } catch (RuntimeException rex) {
            System.out.println("Errors:\n" + rex.getMessage());
        }
    }

    private void handleUpdateCake() {
        try {
            System.out.print("Enter id to update: ");
            String id = scanner.nextLine();
            System.out.print("Enter new name: ");
            String name = scanner.nextLine();
            System.out.print("Enter new ingredients: ");
            String ingredients = scanner.nextLine();
            System.out.print("Enter new number of calories: ");
            double calories = Double.parseDouble(scanner.nextLine());
            System.out.print("Enter new price: ");
            double price = Double.parseDouble(scanner.nextLine());
            System.out.print("Enter new sugar free (true/false): ");
            boolean sugarFree = Boolean.parseBoolean(scanner.nextLine());

            cakeService.update(id, name, ingredients, calories, price, sugarFree);

            System.out.println("Cake updated successfully!");
        } catch (RuntimeException rex) {
            System.out.println("Errors:\n" + rex.getMessage());
        }
    }

    private void handleAddCake() {
        try {
            System.out.print("Enter id: ");
            String id = scanner.nextLine();
            System.out.print("Enter name: ");
            String name = scanner.nextLine();
            System.out.print("Enter ingredients: ");
            String ingredients = scanner.nextLine();
            System.out.print("Enter number of calories: ");
            double calories = Double.parseDouble(scanner.nextLine());
            System.out.print("Enter price: ");
            double price = Double.parseDouble(scanner.nextLine());
            System.out.print("Enter sugar free (true/false): ");
            boolean sugarFree = Boolean.parseBoolean(scanner.nextLine());

            cakeService.insert(id, name, ingredients, calories, price, sugarFree);

            System.out.println("Cake added successfully!");
        } catch (RuntimeException rex) {
            System.out.println("Errors:\n" + rex.getMessage());
        }
    }

    private void showCakesMenu() {
        System.out.println("1. Add cake");
        System.out.println("2. Update cake");
        System.out.println("3. Remove cake");
        System.out.println("4. Show all");
        System.out.println("x. Back");
    }

    private void showMenu() {
        System.out.println("1. CRUD Cakes");
        System.out.println("2. CRUD Clients");
        System.out.println("3. CRUD Transactions");
        System.out.println("x. Exit");
    }
}
