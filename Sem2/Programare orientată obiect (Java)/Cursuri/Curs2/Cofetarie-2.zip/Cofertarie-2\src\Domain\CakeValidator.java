package Domain;

public class CakeValidator {

    public void validate(Cake cake) {

        String errors = "";
        if (cake.getCalories() <= 0) {
            errors += "The calories must be > 0!\n";
        }
        if (cake.getPrice() <= 0) {
            errors += "The price must be > 0!\n";
        }

        if (!errors.isEmpty()) {
            throw new RuntimeException(errors);
        }
    }
}
