package Repository;

import Domain.Cake;
import Domain.CakeValidator;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class CakeRepository {
    private Map<String, Cake> storage = new HashMap<>();
    private CakeValidator validator;

    /**
     * ...
     * @param cakeValidator
     */
    public CakeRepository(CakeValidator cakeValidator) {
        this.validator = cakeValidator;
    }

    public Cake getById(String id) {
        return storage.get(id);
    }

    /**
     *
     * @param cake
     */
    public void insert(Cake cake) {
        if (storage.containsKey(cake.getId())) {
            throw new RuntimeException(String.format("There already is a cake with id=%s", cake.getId()));
        }

        validator.validate(cake);
        storage.put(cake.getId(), cake);
    }

    /**
     *
     * @param cake
     */
    public void update(Cake cake) {
       if (!storage.containsKey(cake.getId())) {
           throw new RuntimeException(String.format("There is no cake with id=%s", cake.getId()));
       }

       validator.validate(cake);
       storage.put(cake.getId(), cake);
    }

    /**
     *
     * @param id
     */
    public void remove(String id) {
       if (!storage.containsKey(id)) {
           throw new RuntimeException(String.format("There is no cake with id=%s", id));
       }

       storage.remove(id);
    }

    /**
     *
     * @return
     */
    public List<Cake> getAll() {
        return new ArrayList<>(storage.values());
    }
}
