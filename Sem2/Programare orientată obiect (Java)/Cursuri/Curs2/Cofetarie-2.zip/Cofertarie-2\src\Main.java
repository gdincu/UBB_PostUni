import Domain.CakeValidator;
import Repository.CakeRepository;
import Service.CakeService;
import UI.Console;

public class Main {

    public static void main(String[] args) {
        CakeValidator cakeValidator = new CakeValidator();


        CakeRepository cakeRepository = new CakeRepository(cakeValidator);


        CakeService cakeService = new CakeService(cakeRepository);


        Console console = new Console(cakeService);
        console.run();
    }
}
