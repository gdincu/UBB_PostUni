package Tests.Repository;

import Domain.Cake;
import Domain.CakeValidator;
import Repository.CakeRepository;
import org.junit.jupiter.api.Test;

import java.util.List;

import static org.junit.jupiter.api.Assertions.*;

class CakeRepositoryTest {

    @Test
    void insertShouldAddCakes() {
        CakeValidator validator = new CakeValidator();
        CakeRepository repository = new CakeRepository(validator);
        Cake cake1 = new Cake("1","2","3",100,100,true);
        Cake cake2 = new Cake("2","2","3",100,100,true);
        Cake cake1Dupe = new Cake("1","2","3",100,100,true);

        repository.insert(cake1);
        List<Cake> all = repository.getAll();
        assertEquals(1, all.size());
        assertEquals(cake1, all.get(0));

        try {
            repository.insert(cake1Dupe);
            fail("Exception not thrown for duplicate cake id!");
        } catch (RuntimeException rex) {
            assertTrue(true);
        }
    }

    @Test
    void update() {
    }
}