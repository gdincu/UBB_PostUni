package Service;

import Domain.Cake;
import Repository.CakeRepository;

import java.util.List;

public class CakeService {
    private CakeRepository repository;

    public CakeService(CakeRepository repository) {
        this.repository = repository;
    }

    public void insert(String id, String name, String ingredients, double calories, double price, boolean sugarFree) {
        Cake cake = new Cake(id, name, ingredients, calories, price, sugarFree);
        repository.insert(cake);
    }

    public void update(String id, String name, String ingredients, double calories, double price, boolean sugarFree) {
        Cake cake = new Cake(id, name, ingredients, calories, price, sugarFree);
        repository.update(cake);
    }

    public void remove(String id) {
        repository.remove(id);
    }

    public List<Cake> getAll() {
        return repository.getAll();
    }
}
