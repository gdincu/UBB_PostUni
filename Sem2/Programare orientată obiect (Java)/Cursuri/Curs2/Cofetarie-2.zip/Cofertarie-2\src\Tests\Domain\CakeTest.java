package Tests.Domain;

import Domain.Cake;

import static org.junit.jupiter.api.Assertions.*;

class CakeTest {

    @org.junit.jupiter.api.Test
    void getIdShouldReturnCorrectId() {
        Cake cake = new Cake("1", "test", "test", 100, 100, true);
        assertEquals("1", cake.getId(), String.format("Returned %s, expected=%s", cake.getId(), "1"));
        Cake cake2 = new Cake("2", "test", "test", 100, 100, true);
        assertEquals("2", cake2.getId(), String.format("Returned %s, expected=%s", cake.getId(), "2"));
    }

    @org.junit.jupiter.api.Test
    void setIdShouldSetTheGivenId() {
        Cake cake = new Cake("1", "test", "test", 100, 100, true);
        String setId = "7";
        cake.setId(setId);
        assertEquals(setId, cake.getId(), String.format("Returned=%s, Expected=%s", cake.getId(), setId));
    }

    @org.junit.jupiter.api.Test
    void constructorShouldSetAllFieldsCorrectly() {
        Cake cake = new Cake("1", "test", "test", 100, 100, true);
        assertEquals("1", cake.getId());
        assertEquals("test", cake.getName());
        assertEquals("test", cake.getIngredients());
        assertEquals(100, cake.getCalories());
        assertEquals(100, cake.getPrice());
        assertTrue(cake.isSugarFree());
    }

    @org.junit.jupiter.api.Test
    void settersShouldSetFieldsCorrectly() {
        Cake cake = new Cake("1", "test", "test", 100, 100, true);

        cake.setId("2");
        cake.setName("test2");
        cake.setIngredients("test2");
        cake.setCalories(200);
        cake.setPrice(200);
        cake.setSugarFree(false);

        assertEquals("2", cake.getId());
        assertEquals("test2", cake.getName());
        assertEquals("test2", cake.getIngredients());
        assertEquals(200, cake.getCalories());
        assertEquals(200, cake.getPrice());
        assertFalse(cake.isSugarFree());
    }

    @org.junit.jupiter.api.Test
    void equalityShouldWorkCorrectly() {
        Cake cake1 = new Cake("1", "test", "test", 100, 100, true);
        Cake cake2 = new Cake("1", "test", "test", 100, 100, true);
        Cake cake3 = new Cake("3", "test", "test", 100, 100, true);

        assertNotEquals(cake1, cake3);
        assertNotEquals(cake3, cake1);
        assertNotEquals(cake3, cake2);
        assertNotEquals(cake2, cake3);
        assertEquals(cake1, cake2);
        assertEquals(cake2, cake1);
    }


    @org.junit.jupiter.api.Test
    void toStringShouldReturnALongEnoughString() {
        Cake cake1 = new Cake("1", "test", "test", 100, 100, true);

        assertTrue(cake1.toString().length() > 10);
    }
}