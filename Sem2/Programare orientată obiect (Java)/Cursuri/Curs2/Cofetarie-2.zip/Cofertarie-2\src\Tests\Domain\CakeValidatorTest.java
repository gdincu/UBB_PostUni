package Tests.Domain;

import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

class CakeValidatorTest {

    @Test
    void validateShouldThrowExceptionsCorrectly() {

    }
}