package Tests;

import Domain.Cake;
import Domain.CakeValidator;
import Repository.CakeRepository;

import static org.junit.jupiter.api.Assertions.*;

class CakeRepositoryTest {

    @org.junit.jupiter.api.Test
    void findByIdWithExistingIdShouldReturnCorrectCake() {

        CakeRepository repo = new CakeRepository(new CakeValidator());
        Cake added = new Cake("1", "test", "test", 100,100,true);
        repo.upsert(added);
        Cake found = repo.findById("1");
        assertNotNull(found, "Returned null for existing id!");
        assertEquals(found.getId(), "1", String.format("Returned id %s instead of correct id=1!", found.getId()));
        assertEquals(found.getName(), "test", String.format("Returned name instead of %s", found.getName(), added.getName()));
        // ... so on
    }

    @org.junit.jupiter.api.Test
    void upsert() {
    }

    @org.junit.jupiter.api.Test
    void remove() {
    }

    @org.junit.jupiter.api.Test
    void getAll() {
    }
}