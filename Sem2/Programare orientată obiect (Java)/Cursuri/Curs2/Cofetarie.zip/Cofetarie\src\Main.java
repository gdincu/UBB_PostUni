import Domain.CakeValidator;
import Domain.Client;
import Domain.ClientValidator;
import Domain.TransactionValidator;
import Repository.CakeRepository;
import Repository.ClientRepository;
import Repository.TransactionRepository;
import Service.CakeService;
import Service.ClientService;
import Service.TransactionService;
import UI.Console;

public class Main {

    public static void main(String[] args) {

        CakeValidator cakeValidator = new CakeValidator();
        ClientValidator clientValidator = new ClientValidator();
        TransactionValidator transactionValidator = new TransactionValidator();

        CakeRepository cakeRepository = new CakeRepository(cakeValidator);
        ClientRepository clientRepository = new ClientRepository(clientValidator);
        TransactionRepository transactionRepository = new TransactionRepository(transactionValidator);

        CakeService cakeService = new CakeService(cakeRepository);
        ClientService clientService = new ClientService(clientRepository);
        TransactionService transactionService = new TransactionService(transactionRepository, cakeRepository);

        Console console = new Console(cakeService, clientService, transactionService);
        console.run();
    }
}
