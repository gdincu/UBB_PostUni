package Repository;

import Domain.Cake;
import Domain.CakeValidator;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class CakeRepository {

    private Map<String, Cake> storage = new HashMap<>();
    private CakeValidator validator;

    public CakeRepository(CakeValidator validator) {
        this.validator = validator;
    }

    public Cake findById(String id) {
        return storage.get(id);
    }

    /**
     * Adds or updates a cake if it already exists.
     * @param cake the cake to add or update.
     */
    public void upsert(Cake cake) {
        validator.validate(cake);
        storage.put(cake.getId(), cake);
    }

    /**
     * Removes a cake with a given id.
     * @param id the id.
     * @throws RuntimeException if there is no cake with the given id.
     */
    public void remove(String id) {
        if (!storage.containsKey(id)) {
            throw new RuntimeException("There is no cake with the given id to remove.");
        }

        storage.remove(id);
    }

    public List<Cake> getAll() {
        return new ArrayList<>(storage.values());
    }
}
