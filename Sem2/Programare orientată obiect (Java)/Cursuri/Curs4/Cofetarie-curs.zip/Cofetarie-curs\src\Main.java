import Domain.*;
import Repository.IRepository;
import Repository.InMemoryRepository;
import Service.CakeService;
import Service.ClientService;
import Service.TransactionService;
import UI.Console;
import UI.MainController;
import javafx.application.Application;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.stage.Stage;


public class Main extends Application {

    @Override
    public void start(Stage primaryStage) throws Exception{

        FXMLLoader fxmlLoader = new FXMLLoader(getClass().getResource("UI/mainWindow.fxml"));
        Parent root = fxmlLoader.load();

        IValidator<Cake> cakeValidator = new CakeValidator();
        IValidator<Client> clientValidator = new ClientValidator();
        IValidator<Transaction> transactionValidator = new TransactionValidator();

        IRepository<Cake> cakeRepository = new InMemoryRepository<>(cakeValidator);
        IRepository<Client> clientRepository = new InMemoryRepository<>(clientValidator);
        IRepository<Transaction> transactionRepository = new InMemoryRepository<>(transactionValidator);

        CakeService cakeService = new CakeService(cakeRepository);
        cakeService.addOrUpdate("1", "cake 1", "ing 1, ing2", 200, 100, true);
        cakeService.addOrUpdate("2", "cake 2", "ing 21, ing22", 400, 200, false);
        cakeService.addOrUpdate("3", "cake 3", "ing 31, ing32", 700, 300, true);

        ClientService clientService = new ClientService(clientRepository);
        TransactionService transactionService = new TransactionService(transactionRepository, cakeRepository);

        MainController mainController =  fxmlLoader.getController();
        mainController.setServices(cakeService, clientService, transactionService);

        primaryStage.setTitle("Cakes manager");
        primaryStage.setScene(new Scene(root, 600, 475));
        primaryStage.show();
    }


    public static void main(String[] args) {

        launch(args);
    }
}


