package UI;

import Domain.Cake;
import Service.CakeService;
import Service.ClientService;
import Service.TransactionService;
import javafx.application.Platform;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.*;
import javafx.scene.control.cell.TextFieldTableCell;
import javafx.util.converter.DoubleStringConverter;

public class MainController {
    public TableView tblCakes;
    public TableColumn colIdCake;
    public TableColumn colNameCake;
    public TableColumn colIngredientsCake;
    public TableColumn colCaloriesCake;
    public TableColumn colPriceCake;
    public TableColumn colSugarFreeCake;
    public TextField txtCakeID;
    public CheckBox chkSugarFree;
    public TextField txtCakeName;
    public TextField txtCakeIngredients;
    public TextField txtCakeCalories;
    public TextField txtCakePrice;
    public Button btnAddCake;

    private CakeService cakeService;
    private ClientService clientService;
    private TransactionService transactionService;

    private ObservableList<Cake> cakes = FXCollections.observableArrayList();

    public void setServices(CakeService cakeService, ClientService clientService, TransactionService transactionService) {
        this.cakeService = cakeService;
        this.clientService = clientService;
        this.transactionService = transactionService;
    }

    @FXML
    private void initialize() {

        Platform.runLater(() -> {
            cakes.addAll(cakeService.getAll());
            tblCakes.setItems(cakes);
        });
    }

    public void btnAddCakeClick(ActionEvent actionEvent) {
        try {
            String id = txtCakeID.getText();
            String name = txtCakeName.getText();
            String ingredients = txtCakeIngredients.getText();
            double calories = Double.parseDouble(txtCakeCalories.getText());
            double price = Double.parseDouble(txtCakePrice.getText());
            boolean sugarFree = chkSugarFree.isSelected();

            cakeService.addOrUpdate(id,name,ingredients,calories,price,sugarFree);

            cakes.clear();
            cakes.addAll(cakeService.getAll());
        } catch ( RuntimeException rex ){
            Common.showValidationError(rex.getMessage());
        }
    }
}
