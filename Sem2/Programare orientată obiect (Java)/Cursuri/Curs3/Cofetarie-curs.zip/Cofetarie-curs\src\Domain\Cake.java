package Domain;

import java.util.Objects;

public class Cake extends Entity {

    private String name, ingredients;
    private double calories, price;
    private boolean sugarFree;

    public Cake(String id, String name, String ingredients, double calories, double price, boolean sugarFree) {
        super(id);
        this.name = name;
        this.ingredients = ingredients;
        this.calories = calories;
        this.price = price;
        this.sugarFree = sugarFree;
    }

    @Override
    public String toString() {
        return "Cake{" +
                "id='" + getId() + '\'' +
                ", name='" + name + '\'' +
                ", ingredients='" + ingredients + '\'' +
                ", calories=" + calories +
                ", price=" + price +
                ", sugarFree=" + sugarFree +
                '}';
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getIngredients() {
        return ingredients;
    }

    public void setIngredients(String ingredients) {
        this.ingredients = ingredients;
    }

    public double getCalories() {
        return calories;
    }

    public void setCalories(double calories) {
        this.calories = calories;
    }

    public double getPrice() {
        return price;
    }

    public void setPrice(double price) {
        this.price = price;
    }

    public boolean isSugarFree() {
        return sugarFree;
    }

    public void setSugarFree(boolean sugarFree) {
        this.sugarFree = sugarFree;
    }
}
