package Domain;

import java.util.Objects;

public class Transaction extends Entity {

    private String idCake, idClientCard, date, time;
    private int numberOfItems;
    private double basePrice;
    private double discount;

    public Transaction(String id, String idCake, String idClientCard, int numberOfItems, String date, String time, double basePrice, double discount) {
        super(id);
        this.idCake = idCake;
        this.idClientCard = idClientCard;
        this.numberOfItems = numberOfItems;
        this.date = date;
        this.time = time;
        this.basePrice = basePrice;
        this.discount = discount;
    }

    /**
     * Custom getter for the discounted price.
     * @return the price after applying the discount.
     */
    public double getDiscountedPrice() {
        return basePrice*numberOfItems - discount * basePrice*numberOfItems;
    }

    @Override
    public String toString() {
        return "Transaction{" +
                "id='" + getId() + '\'' +
                ", idCake='" + idCake + '\'' +
                ", idClientCard='" + idClientCard + '\'' +
                ", numberOfItems='" + numberOfItems + '\'' +
                ", date='" + date + '\'' +
                ", time='" + time + '\'' +
                ", basePrice=" + basePrice +
                ", discount=" + discount +
                '}';
    }

    public String getIdCake() {
        return idCake;
    }

    public void setIdCake(String idCake) {
        this.idCake = idCake;
    }

    public String getIdClientCard() {
        return idClientCard;
    }

    public void setIdClientCard(String idClientCard) {
        this.idClientCard = idClientCard;
    }

    public int getNumberOfItems() {
        return numberOfItems;
    }

    public void setNumberOfItems(int numberOfItems) {
        this.numberOfItems = numberOfItems;
    }

    public String getDate() {
        return date;
    }

    public void setDate(String date) {
        this.date = date;
    }

    public String getTime() {
        return time;
    }

    public void setTime(String time) {
        this.time = time;
    }

    public double getBasePrice() {
        return basePrice;
    }

    public void setBasePrice(double basePrice) {
        this.basePrice = basePrice;
    }

    public double getDiscount() {
        return discount;
    }

    public void setDiscount(double discount) {
        this.discount = discount;
    }
}
