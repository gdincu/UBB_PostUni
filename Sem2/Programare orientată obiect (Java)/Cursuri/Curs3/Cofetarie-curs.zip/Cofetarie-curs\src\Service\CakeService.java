package Service;

import Domain.Cake;
import Repository.IRepository;

import java.util.List;

public class CakeService {

    private IRepository<Cake> repository;

    public CakeService(IRepository<Cake> repository) {
        this.repository = repository;
    }

    public void addOrUpdate(String id, String name, String ingredients, double calories, double price, boolean sugarFree) {
        Cake existing = repository.findById(id);
        if (existing != null) {
            // keep unchanged fields as they were
            if (name.isEmpty()) {
                name = existing.getName();
            }
            if (ingredients.isEmpty()) {
                ingredients = existing.getIngredients();
            }
            if (calories == 0) {
                calories = existing.getCalories();
            }
            if (price == 0) {
                price = existing.getPrice();
            }
        }
        Cake cake = new Cake(id, name, ingredients, calories, price, sugarFree);
        repository.upsert(cake);
    }

    public void remove(String id) {
        repository.remove(id);
    }

    public List<Cake> getAll() {
        return repository.getAll();
    }
}
