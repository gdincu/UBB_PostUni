import Domain.*;
import Repository.IRepository;
import Repository.InMemoryRepository;
import Service.CakeService;
import Service.ClientService;
import Service.TransactionService;
import UI.Console;

// AddCake,1,tiramisu,ingredient1 ingredient 2,200,100,true
public class Main {

    public static void main(String[] args) {

        IValidator<Cake> cakeValidator = new CakeValidator();
        IValidator<Client> clientValidator = new ClientValidator();
        IValidator<Transaction> transactionValidator = new TransactionValidator();

        IRepository<Cake> cakeRepository = new InMemoryRepository<>(cakeValidator);
        IRepository<Client> clientRepository = new InMemoryRepository<>(clientValidator);
        IRepository<Transaction> transactionRepository = new InMemoryRepository<>(transactionValidator);

        CakeService cakeService = new CakeService(cakeRepository);
        ClientService clientService = new ClientService(clientRepository);
        TransactionService transactionService = new TransactionService(transactionRepository, cakeRepository);

        Console console = new Console(cakeService, clientService, transactionService);
        console.run();
    }
}
