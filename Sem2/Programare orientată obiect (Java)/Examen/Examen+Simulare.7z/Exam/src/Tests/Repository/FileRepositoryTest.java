package Tests.Repository;

import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

class FileRepositoryTest {

    @Test
    void findById() {
    }

    @Test
    void upsert() {
    }

    @Test
    void remove() {
    }

    @Test
    void getAll() {
    }
}