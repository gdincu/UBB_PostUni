package Tests.Service;

import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

class BookingServiceTest {

    @Test
    void getAll() {
    }

    @Test
    void addOrUpdate() {
    }
}