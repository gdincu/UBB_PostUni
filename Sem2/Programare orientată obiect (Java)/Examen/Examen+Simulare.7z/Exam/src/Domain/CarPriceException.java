package Domain;

public class CarPriceException extends RuntimeException {
    public CarPriceException(String message) {
        super(message);
    }
}
