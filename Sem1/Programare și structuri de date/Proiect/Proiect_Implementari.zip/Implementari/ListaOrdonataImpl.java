import java.util.ArrayList;
import java.util.Comparator;
import java.util.Iterator;
import java.util.List;


public class ListaOrdonataImpl<T> implements ListaOrdonata<T> {

	private Comparator<T> comparator;
	private List<T> elemente;
	
	public ListaOrdonataImpl(Comparator<T> comp) {
		this.comparator = comp;
		this.elemente = new ArrayList<T>();
	}
	
	public void adauga(T elem) {
		if (this.elemente.size() == 0) {
			this.elemente.add(elem);
		} else if (this.comparator.compare(elem, this.elemente.get(this.elemente.size()-1))>= 0) {
			this.elemente.add(elem);
		} else {
			int index = 0;
			while(index < this.elemente.size() && this.comparator.compare(elem, this.elemente.get(index)) > 0) {
				index++;
			}
			this.elemente.add(index, elem);
		}
	}

	public boolean cauta(T elem) {
		return this.elemente.contains(elem);
	}

	public int dim() {
		return this.elemente.size();		
	}

	public T stergePoz(int pozitie) {
		if (pozitie < 0 || pozitie >= this.elemente.size()) {
			throw new RuntimeException("Pozitie invalida!");
		}
		T elem = this.elemente.remove(pozitie);
		return elem;
	}

	public void sterge(T elem) {
		boolean b = this.elemente.remove(elem);
		
	}

	public T element(int pozitie) {
		if (pozitie < 0 || pozitie >= this.elemente.size()) {
			throw new RuntimeException("Pozitie invalida!");
		}
		return this.elemente.get(pozitie);
	}

	public boolean vida() {
		return this.elemente.isEmpty();
	}

	public int pozitie(T elem) {
		return this.elemente.indexOf(elem);
	}

	public Iterator<T> iterator() {
		return new IteratorListaOrdonata<T>(this);
	}
	
	public class IteratorListaOrdonata<T> implements Iterator<T> {

		private ListaOrdonataImpl<T> lista;
		private int pozitieCurenta;
		
		public IteratorListaOrdonata(ListaOrdonataImpl<T> list) {
			this.lista = list;
			this.pozitieCurenta = 0;			
		}
		
		public boolean hasNext() {
			return this.pozitieCurenta < this.lista.dim();			
		}

		public T next() {
			T elem = this.lista.element(this.pozitieCurenta);
			this.pozitieCurenta++;
			return elem;			
		}
		
	}

}
