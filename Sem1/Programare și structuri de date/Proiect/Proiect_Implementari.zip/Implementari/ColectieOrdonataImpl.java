import java.util.ArrayList;
import java.util.Comparator;
import java.util.Iterator;
import java.util.List;


public class ColectieOrdonataImpl<T> implements ColectieOrdonata<T>{

	private Comparator<T> comparator;
	private List<T> elemente;

	public ColectieOrdonataImpl(Comparator<T> comparator) {
		this.comparator = comparator;
		this.elemente = new ArrayList<T>();
	}
	
	public void adauga(T elem) {
		//daca nu avem elemente
		if (this.elemente.size() == 0) {
			this.elemente.add(elem);
			//verificam daca trebuie adaugat dupa ultimul element
		} else if (this.comparator.compare(elem, elemente.get(elemente.size()-1)) >= 0) {
			this.elemente.add(elem);
		} else {
			//cautam elementul dupa care adaugam
			int index = 0;
			while (index < this.elemente.size() && this.comparator.compare(elem, elemente.get(index))> 0) {
				index ++;
			}
			this.elemente.add(index, elem);
		}		
	}

	@Override
	public void sterge(T element) {
		boolean b = this.elemente.remove(element);
	}

	public int dim() {
		return this.elemente.size();
	}

	public boolean cauta(T element) {
		return this.elemente.contains(element);
	}

	@Override
	public Iterator<T> iterator() {
		return new IteratorColectieOrdonata<T>(this);
	}
	
	public class IteratorColectieOrdonata<T> implements Iterator<T>{

		private int pozitieCurenta;
		private ColectieOrdonataImpl<T> col;
		
		public IteratorColectieOrdonata(ColectieOrdonataImpl<T> co) {
			this.col = co;
			this.pozitieCurenta = 0;
		}
		
		public boolean hasNext() {
			if (this.pozitieCurenta < this.col.elemente.size()) {
				return true;
			} else {
				return false;
			}
		}
		
		public T next() {
			T currentElem = this.col.elemente.get(this.pozitieCurenta);
			this.pozitieCurenta++;
			return currentElem;
		}
		
	}
}
