import java.util.Iterator;


public interface ListaOrdonata<T> {

	public void adauga(T elem);
	
	public boolean cauta(T elem);
	
	public int dim();
	
	public T stergePoz(int pozitie);
	
	public void sterge(T elem);
	
	public T element(int pozitie);
	
	public boolean vida();
	
	public int pozitie(T elem);
	
	public Iterator<T> iterator();
	
}
