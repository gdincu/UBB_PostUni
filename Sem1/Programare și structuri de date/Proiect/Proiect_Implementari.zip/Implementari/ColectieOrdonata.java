import java.util.Iterator;


public interface ColectieOrdonata<T> {

	public void adauga(T elem);
	
	public void sterge(T element);
	
	public int dim();
	
	public boolean cauta(T element);
	
	Iterator<T> iterator();
	
}
