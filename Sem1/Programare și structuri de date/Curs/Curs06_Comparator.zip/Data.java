import java.util.Comparator;

/*
 * Clasa Data reprezinta o data calendaristica (zi, luna, an).
 * "implements Comparable<Data>" semnifica ca aceasta clasa are implementata functia
 * compareTo(Data arg0), care poate fi folosita de Java pentru a compara/ordona 
 * elementele. 
 */
public class Data implements Comparable<Data>{

	/*
	 *Campurile/atributele pentru o data calendaristica, un intreg pentru an, unul pentru unul
	 *si unul pentru zi
	 */
	private int an;
	private int luna;
	private int zi;

	/*
	 * Constructorul clasei Data. Cand in cod scriem:
	 * Data d = new Data(1990, 5, 19) - aceasta functie se apeleaza automat
	 */
	public Data(int a, int l, int z) {
		this.an = a;
		this.luna = l;
		this.zi = z;
	}
	
	/*
	 * Daca o clasa are functia toString() definita, Stringul returnat de functie
	 * va fi afisat daca folosim System.out.println() pentru a afisa o Data.
	 */
	public String toString() {
		return this.an + "." + this.luna + "." + this.zi;
	}
	
	/*
	 * Din moment ce mai sus, campul an este declarat "private", ceea ce inseamna 
	 * ca nu este acesibil din afara clasei Data (din clasele Elevi, Main, etc.).
	 * Daca vrem sa avem acces la an, implementam functia getAn() care il returneaza.
	 */
	public int getAn(){
		return this.an;
	}
	
	/*
	 * Similar ca la getAn()
	 */
	public int getLuna(){
		return this.luna;
	}
	
	/*
	 * Similar ca la getAn()
	 */
	public int getZi(){
		return this.zi;
	}
	
	/*
	 * La Fundamentele Programarii probabil ati discutat si despre "setteri", functii
	 * care se folosesc sa schimbam valoarea campurilor. De exemplu, un setZi, ca 
	 * sa schimbam valoarea campului zi. In acest exemplu nu am implementat setteri
	 * pentru ca nu am avut nevoie de ei. 
	 */
	
	/*
	 * Functie care vine din interfata Comparable<Data> (adica daca avem "implements 
	 * Comparable<Data>" scris dupa numele clasei, e musai sa avem aceasta functie 
	 * implementata. Scopul functiei este sa compare elementul "this" (cel reprezentat 
	 * de aceasta clasa) cu un element dat ca parametru (arg0). 
	 * Functia trebuie sa returneze:
	 * 	 0 daca "this" este egal cu arg0
	 * 	 numar negativ daca "this" este mai mic decat arg0 (mai mic inseamna ca la ordonare, vrem ca "this" sa vina primul)
	 * 	 numar pozitiv daca "this" este mai mare decat arg0
	 */
	public int compareTo(Data arg0) {
	
		//verificam egalitatea
		if (this.an == arg0.an && this.luna == arg0.luna && this.zi == arg0.zi) {
			return 0;
		}
		//verificam daca "this" este mai mic
		if (arg0.an > this.an || 
			(arg0.an == this.an && arg0.luna > this.luna) ||
			(arg0.an == this.an && arg0.luna == this.luna && arg0.zi > this.zi)) {
			return -1;
		}
		//daca nu este egal si nu e nici mai mic, atunci e mai mare
		return 1;		
	}
		
}
