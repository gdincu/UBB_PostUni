/*
 * Reprezinta un Elev. Are nume si prenume, medie si o data a nasterii.
 */
public class Elev {

	/*
	 * Campurile/atributele pentru clasa Elev. 
	 */
	private String nume;
	private String prenume;
	private double medie;
	private Data dataNasterii;
	
	/*
	 * Constructorul clasei Elev. Cand in cod se scrie 
	 * Elev e = new Elev("abc", "def", 5.5, new Data(2010, 4, 5)), aceasta functie se
	 * apeleaza.
	 */
	public Elev(String n, String p, double m, Data d) {
		this.nume = n;
		this.prenume = p;
		this.medie = m;
		this.dataNasterii = d;
	}
		 
	/*
	 * Cand apelam System.out.println() pentru un elev, se apeleaza functia toString()
	 * si se afiseaza stringul returnat de aceasta functie.
	 */
	public String toString(){
		return this.nume + " " + this.prenume + " " + 
				this.medie + " " + this.dataNasterii.toString();
	}
	
	/*
	 * Din moment ce campul nume mai sus este declarat "private", nu avem acces la el
	 * din afara clasei Elev (de ex. in clasa Data, Main, etc.). Daca vrem sa accesam
	 * numele, apelam aceasta functie getter.
	 */
	public String getNume(){
		return this.nume;
	}
	
	/*
	 * Similar cu getNume()
	 */
	public String getPrenume(){
		return this.prenume;
	}
	
	/*
	 * Similar cu getNume()
	 */
	public double getMedie(){
		return this.medie;
	}
	
	/*
	 * Similar cu getNume()
	 */
	public Data getDataNasterii(){
		return this.dataNasterii;
	}
	
	/*
	 * La Fundamentele Programarii probabil ati discutat si despre "setteri", functii
	 * care se folosesc sa schimbam valoarea campurilor. De exemplu, un setMedie, ca 
	 * sa schimbam valoarea campului medie. In acest exemplu nu am implementat setteri
	 * pentru ca nu am avut nevoie de ei. 
	 */
}
