import java.util.Comparator;

/*
 * Clasa comparator, care stie sa compare 2 elemente de tip Elev dupa medie.
 * Elevul "mai mic" este cel care are media mai mare.
 * "implements Comparator<Elev>" inseamna ca este o clasa care se foloseste pentru
 * a compara variabile de tip Elev. 
 * Trebuie sa aiba o operatie/functie numita "compare" care sa primeasca ca parametru
 * 2 variabile de tip Elev.
 */
public class ComparatorMedie implements Comparator<Elev>{

	/*
	 * Functie care e musai sa fie in clasa daca avem "implements Comparator<Elev>"
	 * Functia compara 2 variabile de tip elev, o1 si o2, considerand media lor. Vrem 
	 * ordonare descrescatoare, deci elevul "mai mic" este cel cu media mai mare.
	 * Returneaza:
	 * 		0 - daca o1 si o2 au aceeasi medie
	 * 		numar negativ, daca o1 are medie mai mare decat o2
	 * 		numar pozitiv, daca o2 are medie mai mare decat o1
	 */
	public int compare(Elev o1, Elev o2) {
		
		if (o1.getMedie() == o2.getMedie()) {
			return 0;
		} else if (o1.getMedie() > o2.getMedie()) {
			//vrem sa ordonam descrescator, deci media mare vine prima
			return -1;
		} else {
			return 1;
		}
	}

	
	
}
