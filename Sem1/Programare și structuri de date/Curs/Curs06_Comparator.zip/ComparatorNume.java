import java.util.Comparator;

/*
 * Clasa comparator, care stie sa compare 2 elemente de tip Elev dupa nume si prenume
 * folosind ordinea alfabetica.
 * "implements Comparator<Elev>" inseamna ca este o clasa care se foloseste pentru
 * a compara variabile de tip Elev. 
 * Trebuie sa aiba o operatie/functie numita "compare" care sa primeasca ca parametru
 * 2 variabile de tip Elev.
 */
public class ComparatorNume implements Comparator<Elev>{

	/*
	 * Functie care e musai sa fie in clasa daca avem "implements Comparator<Elev>"
	 * Functia compara 2 variabile de tip elev, o1 si o2, considerand numele si prenumele. 
	 * Vrem ordonare in ordine alfabetica.
	 * Returneaza:
	 * 		0 - daca o1 si o2 au acelasi nume si prenume
	 * 		numar negativ, daca combinatia (nume, prenume) pentru o1 e alfabetic mai mic decat (nume, prenume) o2
	 * 		numar pozitiv, altfel
	 */
	public int compare(Elev o1, Elev o2) {
		
		//verificam daca au acelasi nume si prenume (atunci sunt egale)
		if (o1.getNume().equals(o2.getNume()) && o1.getPrenume().equals(o2.getPrenume())) {
			return 0;
		}
		//daca au acelasi nume, comparam prenumele
		if (o1.getNume().equals(o2.getNume())) {
			//String in Java are functia compareTo implementata, care stie sa compare
			//stringuri dupa ordine alfabetica.
			return o1.getPrenume().compareTo(o2.getNume());
		} 
		//altfel comparam doar numele		
		return o1.getNume().compareTo(o2.getNume());
	}

}
