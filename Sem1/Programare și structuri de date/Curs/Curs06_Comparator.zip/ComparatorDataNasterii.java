import java.util.Comparator;

/*
 * Clasa comparator, care stie sa compare 2 elemente de tip Elev dupa data nasterii.
 * Elevul "mai mic" este cel care s-a nascut primul (este mai batran).
 * "implements Comparator<Elev>" inseamna ca este o clasa care se foloseste pentru
 * a compara variabile de tip Elev. 
 * Trebuie sa aiba o operatie/functie numita "compare" care sa primeasca ca parametru
 * 2 variabile de tip Elev.
 */
public class ComparatorDataNasterii implements Comparator<Elev>{

	/*
	 * Functie care e musai sa fie in clasa daca avem "implements Comparator<Elev>"
	 * Functia compara 2 variabile de tip elev, o1 si o2, considerand data lor de 
	 * nastere.
	 * Returneaza:
	 * 		0 - daca o1 si o2 au aceeasi data de nastere
	 * 		numar negativ, daca o1 s-a nascut mai repede
	 * 		numar pozitiv, daca o2 s-a nascut mai repede
	 */
	public int compare(Elev o1, Elev o2) {
		//retinem data nasterii de la fiecare elev
		Data d1 = o1.getDataNasterii();
		Data d2 = o2.getDataNasterii();
		//Data are functia compareTo, apelam aceasta functie pentru comparatie
		return d1.compareTo(d2);
	}
	
	

}
