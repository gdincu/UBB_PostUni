import java.util.Arrays;
import java.util.Iterator;
import java.util.SortedSet;


public class Main {

	public static void main(String[] args) {
		
		int i1 = 15;
		int i2 = 7;
		
		System.out.println(i1 < i2); // pentru int se poate folosi <
		
		double d1 = 4.1;
		double d2 = 11.0;
		
		System.out.println(d1 < d2); // pentru double se poate folosi <
		
		//System.out.println("abc" < "def"); //pentru String nu se poate folosi <
		System.out.println("abc".compareTo("def")); //pentru String ne trebuie compareTo
		
		//definim niste variabile de tip Data
		Data data1 = new Data(1990, 6, 30);
		Data data2 = new Data(1991, 1, 5);
		Data data3 = new Data(2002, 7, 10);
		Data data4 = new Data(2018, 12, 6);
		Data data5 = new Data(1991, 1, 1);
		
		//System.out.println(data1 < data2); //eroare, nu se poate folosi "<" pentru Data 
		
		System.out.println(data1.compareTo(data2));
		System.out.println(data2.compareTo(data1));
		
		//definim un vector cu cele 5 date
		Data[] date = new Data[5];
		date[0] = data1;
		date[1] = data2;
		date[2] = data3;
		date[3] = data4;
		date[4] = data5;
		
		//Arrays.sort este functie predefinita in Java care sorteaza un vector
		//foloseste implicit operatia compareTo. Daca elementele sunt de un tip care nu 
		//are compareTo definit, vom avea o eroare (Java nu stie cum sa compare elementele).
		Arrays.sort(date);
		
		//afisam vectorul dupa sortare
		for (int i = 0; i < date.length; i++) {
			System.out.println(date[i]);
		}
		
		//definim niste elevi, pentru data de nastere reforlosim datele de mai sus
		Elev e1 = new Elev("Nemes", "Tania", 9.43, data1);
		Elev e2 = new Elev("Coman", "Andrei", 9.67, data2);
		Elev e3 = new Elev("Iova", "Oana", 8.91, data3);
		Elev e4 = new Elev("Chelemen", "Roxana", 9.01, data4);
		
		System.out.println(e1); //cand facem System.out.println(e1), se apeleaza functia
		//toString() din clasa Elev si se afiseaza stringul returnat de functie.
		
		//definim un vector cu cei 4 elevi
		Elev[] elevi = new Elev[4];
		elevi[0] = e1;
		elevi[1] = e2;
		elevi[2] = e3;
		elevi[3] = e4;
		
		//Ne va da o eroare, pentru ca elementele nu sunt comparabile, nu au functia
		//compareTo si partea cu "implements Comparable<Elev>"
		//Arrays.sort(elevi);
		
		ComparatorNume cn = new ComparatorNume();
		ComparatorMedie cm = new ComparatorMedie();
		ComparatorDataNasterii cdn = new ComparatorDataNasterii();
		ComparatorZiNastere czn = new ComparatorZiNastere();
		
		Arrays.sort(elevi, czn);
		//Se foloseste functia compare din Comparatorul dat ca parametru, pentru a 
		//compara elementele din vector
		//daca schimbam parametrul 2 (comparatorul) cu cn, cm, cdn, folosim alt comparator
		//si vom avea o alta ordine de elemente.
		
		//afisam vectorul sa vedem rezultatul sortarii
		for (int i = 0; i < elevi.length; i++) {
			System.out.println(elevi[i]);
		}
		
	}
	

}
