import java.util.Comparator;

/*
 * Clasa comparator, care stie sa compare 2 elemente de tip Elev dupa ziua si luna nasterii.
 * "implements Comparator<Elev>" inseamna ca este o clasa care se foloseste pentru
 * a compara variabile de tip Elev. 
 * Trebuie sa aiba o operatie/functie numita "compare" care sa primeasca ca parametru
 * 2 variabile de tip Elev.
 */
public class ComparatorZiNastere implements Comparator<Elev>{

	/*
	 * Functie care e musai sa fie in clasa daca avem "implements Comparator<Elev>"
	 * Functia compara 2 variabile de tip elev, o1 si o2, luna si ziua nasterii (ignorand anul) 
	 * Returneaza:
	 * 		0 - daca o1 si o2 au acelasi zi si luna de nastere
	 * 		numar negativ, daca luna si ziua de nastere pt. o1 e intaintea lunii si zilei de nastere pt o2.
	 * 		numar pozitiv, altfel
	 */
	public int compare(Elev o1, Elev o2) {
		//accesam si retine data nasterii pentru cei 2 elevi.
		Data d1 = o1.getDataNasterii();
		Data d2 = o2.getDataNasterii();
		
		//accesam luna din data nasterii
		int luna1 = d1.getLuna();
		int luna2 = d2.getLuna();
		
		//daca luna pentru o1 e mai mic, toata data e mai "mica"
		if (luna1 < luna2) {
			return -1;
		} else if (luna1 > luna2) { //daca luna pentru o1 e mai mare, toata data e mai "mare"
			return 1;
		} else { // lunile sunt egale, ne uitam la zi
			int zi1 = d1.getZi();
			int zi2 = d2.getZi();
			
			if (zi1 < zi2) {
				return -1;
			} else if (zi1 > zi2) {
				return 1;
			} else {
				//si luna si ziua sunt egale
				return 0;
			}
		}
	}

}
