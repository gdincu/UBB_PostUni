import java.io.*;
import java.util.Formatter;
import java.util.Scanner;
public class Aplicatie {
	public static int CitIntreg(String sir){
		try{
			System.out.print(sir);
			Scanner S= new Scanner(System.in);
			int I=S.nextInt();
			return I;			
		}
		catch(Exception E){
			System.out.println("Ai gresit, mai incearca");
			return CitIntreg(sir);
		}	
	}
	public static void capTabel(){
		String sir="Denumire\t|Tip\t\t |StocInit  |Vandute   |PretUnit  |";
		String linii="-------------------------------------------------------------------";
		System.out.println(linii);
		System.out.println(sir);
		System.out.println(linii);
	}
	public static void capTabel1(){
		String sir="Denumire\t|Tip\t\t |Disponibile| PretUnit  |";
		String linii="----------------------------------------------------------";
		System.out.println(linii);
		System.out.println(sir);
		System.out.println(linii);
	}
	public static void Formatari(int n,int i, Anvelopa A[] )
	{
		Formatter f=new Formatter();
		Formatter f1=new Formatter();
        String []s=new String[2];
		s[0]=A[i].getNume();
		s[1]=A[i].getTip();
		f.format("%-16s|%-16s|",s);
		System.out.print(f);
		String []sInt=new String[3];
		sInt[0]="";
		sInt[0]+=A[i].getStocI();
		sInt[1]="";
		sInt[1]+=A[i].getVandut();
		sInt[2]="";
		sInt[2]+=A[i].getPretUnit();
		f1.format("%10s|%10s|%10s|",sInt);
		System.out.println(f1);
	}
	public static void Formatari1(int n,int i, Anvelopa A[] )
	{
		Formatter f=new Formatter();
		Formatter f1=new Formatter();
        String []s=new String[2];
		s[0]=A[i].getNume();
		s[1]=A[i].getTip();
		f.format("%-16s|%-16s|",s);
		System.out.print(f);
		String []sInt=new String[2];
		int disponibil=A[i].getStocI()-A[i].getVandut();
		sInt[0]="";
		sInt[0]+=disponibil; //System.out.format("%2d %10s",i,sir);
		sInt[1]="";
		sInt[1]+=A[i].getPretUnit();
		f1.format("%11s|%11s|",sInt);
		System.out.println(f1);
	}
	public static void AfisTot(int n, Anvelopa A[]){
		capTabel();
		for(int i=0;i<n;i++){
			Formatari(n,i,A);
		   }
		String linii="-------------------------------------------------------------------";
		System.out.println(linii);
	}
	public static void AfisEpuizate(int n, Anvelopa A[]){
		capTabel();
		for(int i=0;i<n;i++)
			  if(A[i].getStocI()==A[i].getVandut()){
				  Formatari(n,i,A);  
			  }
		String linii="-------------------------------------------------------------------";
		System.out.println(linii);
				
	}
	public static void AfisDisponibile(int n, Anvelopa A[]){
		capTabel1();
		for(int i=0;i<n;i++)
			if(A[i].getStocI()>A[i].getVandut()){   
			   Formatari1(n,i,A);
			  
		   }
		String linii="----------------------------------------------------------";
		System.out.println(linii);
	}
	
	public static int CitireDinFisier(Anvelopa A[]){
		int n=0;
		try {
		      BufferedReader fisIn = 
			  new BufferedReader(new FileReader("d:\\Cioban\\workspace\\MagazinAnvelope\\src\\Magazin.txt"));
		  String s;
		  while((s = fisIn.readLine())!= null){
			  String felii[]=s.split(",");
			  String nume=felii[0];
			  String tip=felii[1];
			  int stocI=Integer.parseInt(felii[2]);
			  int vandute=Integer.parseInt(felii[3]);
			  int pretU=Integer.parseInt(felii[4]);	  
			  A[n]=new Anvelopa();
			  A[n].setNume(nume);
			  A[n].setTip(tip);
			  A[n].setStocI(stocI);
			  A[n].setVandut(vandute);
			  A[n].setPretUnit(pretU);
			  n++;
		  }
		  fisIn.close();
		} // try
	   catch(Exception e) {
	     System.out.println(e.getMessage());
	     e.printStackTrace();
	     return 0;
	   } // catch									//citiri valorile vectorului
	  return n;
	
	}
	public static void AfisTip(int n, Anvelopa A[]){
		
	}
	public static int Meniu(){
		System.out.println();
		System.out.println("1.Citire date din fisier");
		System.out.println("2.Afisare toata marfa");
		System.out.println("3.Afisare disponibile");
		System.out.println("4.Afisare epuizate");
		System.out.println("5.Afisare dupa tip si procent vanzare");
		System.out.println("0.Terminare program");
		int Opt=CitIntreg ("da optiunea ta:");
		return Opt;
	}

	
	
public static void main(String[] args) {
		int opt=Meniu();
		Anvelopa A[] = new Anvelopa[10];
		int lung=0;	   //numarul de elemente al vectorului A
	
		while(opt!=0){
			switch(opt){
			case 1:lung=CitireDinFisier(A);
			       if(lung>0) System.out.println("am citit corect datele din fisier");
			       else       System.out.println("exista erori in fisier");
				   break;
			case 2:AfisTot(lung,A); 		//Afiseaza tot tabelul
				   break;
			case 3:AfisDisponibile(lung,A);	//Afiseaza marfa existenta
			       break;
			case 4:AfisEpuizate(lung,A);	//Afisare marfa epuizata
			       break;
			case 5:AfisTip(lung,A);
				   break;
			default:
				   System.out.println("ai gresit optiunea, mai incearca!!!");
			}
			opt=Meniu();
		}
		System.out.println("Program terminat");
	}	
}
