//import java.lang.String.*;

public class Student {
    private String nume=null;
    private String materie=null;
    private Natural nota=null;
    private double MG;
    
    public Student(){	//constructor implicit
    }
    
    public Student(String nume, String materie, int nota){ //constr. cu parametri
    	this.nume=nume;
    	this.materie=materie;
    	this.nota=new Natural(nota); //legatura de tip compozitie
    }
    								//accesori (getari si setari)
    public double getMG() {
		return MG;
	}
	public void setMG(double d) {
		this.MG = d;
	}
	public String getNume() {
		return nume;
	}
	public void setNume(String nume) {
		this.nume = nume;
	}
	public String getMaterie() {
		return materie;
	}
	public void setMaterie(String materie) {
		this.materie = materie;
	}
	public int getNota() {
		return nota.getN();
	}
	public void setNota(int nota) {
		this.nota = new Natural(nota);
	}
	
	public boolean maiMicNume(Student s){
		if(nume.compareTo(s.nume)<0) return true;
		return false;
	}
	public boolean maiMicNota(Student s){
		if(this.nota.maiMic(s.nota)) return true;
		return false;
	}
    
    
}
