import java.util.Scanner;

public class SelectSort {
		
	public static int CitIntreg(String sir){
			try{
				System.out.print(sir);
				Scanner S= new Scanner(System.in);
				int I=S.nextInt();
				return I;			
			}
			catch(Exception E){
				System.out.println("Ai gresit, mai incearca");
				return CitIntreg(sir);
			}
			
		}
	public static void Citeste(int v[]){
		  for(int i=0;i<v.length;i++){
				v[i]=CitIntreg("mai da un element:");
			}		
		}
	public static void Selectie(int v[]){ // sortarea vectorului
        int aux, n=v.length;
        for(int i=0;i<n-1;i++)
		  {for (int j=i+1;j<n;j++)
				   if ( v[i] > v[j] )
						{ aux    = v[i];			
						  v[i]   = v[j];			
						  v[j] 	 = aux;				
						} 
			  afisVector(v);
			  System.out.println();
		   }
		}

		
	public static int Meniu(){
			System.out.println();
			System.out.println("1.Citire vector");
			System.out.println("2.Sortare prin selectie");
			System.out.println("3.Afisare vector");
			System.out.println("0.Terminare program");
			int Opt=CitIntreg("da optiunea ta(1,2,3,0):");
			return Opt;
		}
	public static void afisVector(int v[]){
			System.out.print("Elemente vector:");
			for(int i=0;i<v.length;i++){
				System.out.print(v[i]+" ");
			}
		}	
			
	public static void main(String[] args) {
			int opt=Meniu();
			int v[]=null;		//v este referinta spre un vector
			int lung;			//numarul de elemente al vectorului
		
			while(opt!=0){
				switch(opt){
				  case 1: lung=0;									//citiri valorile vectorului
						  while(lung<=0){
							  lung=CitIntreg("da lungime vect:");	//citirea numarului de elemente
						  }
						  v=new int [lung];					//instantierea lui v
						  Citeste(v);
					      break;
				  case 2: 									//citire val de cautare
					      Selectie(v);
					      break;
				  case 3: afisVector(v);	//afisare vector
				          break;
				  default:
					     System.out.println("ai gresit optiunea, mai incearca!!!");
				}
				opt=Meniu();
			}
			System.out.println("Program terminat");
		}	
	}



