import java.util.Scanner;
public class Probl3Proc {
	public static int Citire(String sir){
		System.out.print(sir);
		try {
			Scanner scn = new Scanner(System.in);		//citire sir si parsare
			int Nr=scn.nextInt();						//in long
			return Nr;
		}
		catch(Exception exp) {
			System.out.println("Ai gresit!! Da numar intreg!");
			return Citire(sir);							//apel recursiv pe orice eroare
		}
				        
	} 
	public static int Ordinal(int Z, int L, int A){
	    int Luni[]={0,31,28,31,30,31,30,31,31,30,31,30};///pentru decembrie nu trebuie retinut
	    if(A%4==0) Luni[2]=29;
	    int Ord=0;
	    for(int i=1;i<L;i++)
	        Ord+=Luni[i];
	    Ord+=Z;
	    return Ord;
	}
	public static int Zile(int nz, int nl, int na, int cz, int cl, int ca  ){
	    int zile=0;
	    if(na==ca)  return(Ordinal(cz,cl,ca)-Ordinal(nz,nl,na)); //daca anii coincid
	    else {                                                   //ani diferiti
	           if(na%4==0) zile=366-Ordinal(nz,nl,na);     //adaugare nr de zile din anul nasterii
	           else        zile=365-Ordinal(nz,nl,na);

	          for(int i=na+1;i<=ca-1;i++)                 //adunare pentru anii intregi
	           {   zile+=365;
	               if(i%4==0) zile++;
	          }
	          zile+=Ordinal(cz,cl,ca);                    //adaugare nr de zile din anul curent

	    }
	    return zile;

	}
	public static int AfisMeniu(){
		  System.out.println();
		  System.out.println("1.Data nasterii");
		  System.out.println("2.Data curenta");
		  System.out.println("3.Numar zile");
		  System.out.println("0.Terminare program");
		  return Citire("Optiunea ta:");
	  } 
	  public static void main(String aa[])
	  {int Opt =AfisMeniu();
	   int zc=0,lc=0,ac=0;
	   int zn=0,ln=0,an=0;
	   int nrZile=0;
	   
	   while(Opt!=0){
		   switch(Opt){
		    case 1: zn=Citire("ziua nastere:");
		    		ln=Citire("luna nastere:");
		    		an=Citire("anul nastere:");
		    		break;	    		
		    case 2: zc=Citire("ziua curenta:");
    				lc=Citire("luna curenta:");
    				ac=Citire("anul curenta:");
		            break;
		    case 3: nrZile=Zile(zn,ln,an,zc,lc,ac);
		            System.out.println("zile traite bine:"+nrZile);
		            
		    default:System.out.println("Da optiune valida!!");        
		   }
		   Opt=AfisMeniu();
	   }
	   System.out.println("Program terminat");
	   }
}
