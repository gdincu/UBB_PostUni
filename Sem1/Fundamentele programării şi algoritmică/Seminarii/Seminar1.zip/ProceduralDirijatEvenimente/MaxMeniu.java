import java.util.Scanner;

public class MaxMeniu {
	
	public static long Citire(String sir){
		System.out.print(sir);
		try {
			Scanner scn = new Scanner(System.in);		//citire sir si parsare
			long l=scn.nextLong();				//in long
			return l;
		}
		catch(Exception exp) {
			System.out.println("Ai gresit!! Da numar intreg!");
			return Citire(sir);				//apel recursiv pe orice eroare
		}
			        
	  } 
	

	public static long AfisMeniu(){
	        System.out.println();
	        System.out.println("1.Introducere primul numar");
	        System.out.println("2.Introducere al doilea numar");
	        System.out.println("3.Determinare maxim");
	        System.out.println("0.terminare program");
	        long Opt=   Citire("optiunea dvs:");
	        return Opt;
	} 

        public static void main(String args[]){
	        long a=0,b=0;
		long Op= AfisMeniu();
	        while(Op!=0){
	          switch((int)Op) {
	            case 1: a=Citire("primul numar:");
	            	    break;
	            case 2: b=Citire("al doilea numar:");
	            	    break;
	            case 3:
	            	    if(a>b)   System.out.println("Maximul dintre "+a+" si "+b+" este: "+a);
		                else  System.out.println("Maximul dintre "+a+" si "+b+" este: "+b);
	            	    break;
	            default:
	            	  System.out.println("Ai gresit optiunea, mai incearca");
	          }
	          Op=AfisMeniu();
	        }
	      System.out.println("Program terminat");  
	 }              
}
