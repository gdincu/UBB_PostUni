import java.util.Scanner;

public class CautBinAplic {

	public static int CitIntreg(String sir){
		try{
			System.out.print(sir);
			Scanner S= new Scanner(System.in);
			int I=S.nextInt();
			return I;			
		}
		catch(Exception E){
			System.out.println("Ai gresit, mai incearca");
			return CitIntreg(sir);
		}
		
	}

	
	public static int Citeste(int v[]){
		
		for(int i=0;i<v.length;i++){
			v[i]=CitIntreg("mai da un element:");
		}
		return CitIntreg("da valoarea de cautare:");

	}
	public static int Caut(int v[], int val){
		int st,dr,m,ind;
		st=0;
		dr=v.length-1;
		m=(st+dr)/2;
		while(st<=dr && val!=v[m]){
			if(val<v[m]) dr=m-1;
			else         st=m+1;
			m=(st+dr)/2;
		}
		if(st>dr) return-1;
		else      return m;
	}
	public static void Afisare(int ind, int val){
		if(ind==-1)System.out.println(val+" nu exista printre elem. vectorului");
		else       System.out.println(val+" e pe poz:"+ind);
	}
	public static void main(String[] args) {
		int v[];		//v este referinta spre un vector
		int lung;
		lung=CitIntreg("da lungime vect:");
		v=new int [lung];
		int val;
		val=Citeste(v);
		int ind=Caut(v,val);
		Afisare(ind,val);
		System.out.println("program terminat");
	
	}

}
