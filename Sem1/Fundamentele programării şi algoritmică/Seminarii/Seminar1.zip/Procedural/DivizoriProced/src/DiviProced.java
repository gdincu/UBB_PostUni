import java.util.Scanner;

public class DiviProced
	{ public static int CitInt(String sir){
		try{
			System.out.print(sir);
			Scanner S= new Scanner(System.in);
			int I=S.nextInt();			//parsare (analiza si conversie) la intreg(int)
			return I;			
		}
		catch(Exception E){
			System.out.println("Ai gresit, mai incearca");
			return CitInt(sir);
		}
	}  
	public static int Citire(){
		int N; 
		N=CitInt("da un natural:");
		while(N<=0)
			N=CitInt("da pozitiv:");
		return N;
		 
	  }
	  public static int  Divizori(int NUMAR, int div[]){
		   int n = 0;				//contor pentru divizori, n alocat in zona de program
		   int d = 1;				//d parcurge {1,2,...rad(n)}, d alocat in zona de program
		   while(d*d<NUMAR) {
		      if(NUMAR%d == 0) { 
	 		     div[n++] = d;
	 		     div[n++] = NUMAR/d;
		      }
		      d++;
		   }
	       if(d*d==NUMAR)   div[n++]=d;	//daca NUMAR e patrat perfect
	       return n;
	  }
	  public static void Afisare(int NUMAR,int n, int div[]){
		  int d = 0; 					//afisare divizori
		  System.out.print("\nDivizorii lui "+NUMAR+ " sunt:");
		  while(d<n) {
		       System.out.print(div[d]+" ");
		       d++;
		  }
	  
	  }
	  public static void main(String[] args) {
	  	   int div[]=new int [100];
	  	   int NUMAR;
	  	   NUMAR=Citire();
	  	   int n =Divizori(NUMAR, div);
	  	   Afisare(NUMAR,n,div);
	  	   System.out.println("\nprogram terminat");
	 }
}
		




