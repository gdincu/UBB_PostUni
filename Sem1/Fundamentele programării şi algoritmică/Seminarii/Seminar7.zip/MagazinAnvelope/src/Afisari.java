import java.util.Formatter;

public class Afisari {

	public static void AfisTot(int n, Anvelopa A[]){
		FormatariT.capTabel();
		for(int i=0;i<n;i++){
			FormatariT.Formatari(n,i,A);
		   }
		FormatariT.Linii(61,'-');
	}
	public static void AfisEpuizate(int n, Anvelopa A[]){
		FormatariT.capTabel();
		for(int i=0;i<n;i++)
			  if(A[i].getStocI()==A[i].getVandut()){
				  FormatariT.Formatari(n,i,A);  
			  }
		FormatariT.Linii(61,'-');			
	}
	public static void AfisDisponibile(int n, Anvelopa A[]){
		FormatariT.capTabel1();
		for(int i=0;i<n;i++)
			if(A[i].getStocI()>A[i].getVandut()){   
				FormatariT.Formatari1(n,i,A);		  
		   }
		FormatariT.Linii(58,'-');
	}
	public static void AfisProcTotal(int n, Anvelopa A[]){
		FormatariT.capTabel2();
		long Suma=0;
		for(int i=0;i<n;i++)
			Suma+=A[i].getVandut()*A[i].getPretUnit();
		for(int i=0;i<n;i++){
			FormatariT.Formatari3(n,i,A,Suma);
		}
		FormatariT.Linii(67,'=');
		System.out.println("\t\t\tValoare totala marfa vanduta:"+Suma);
	}
    public static void AfisSlab(int n, Anvelopa A[], int procent){	
		//se parcurge tablouri anvelope si se
		//afiseaza cele care au vandute/stocinit*100<=procent
    	FormatariT.capTabel2();
		for(int i=0;i<n;i++){
			FormatariT.Formatari2(n,i,A,procent);
		   }
		FormatariT.Linii(67,'-');
	}
}
