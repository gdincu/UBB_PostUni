import java.util.Formatter;

public class FormatariT {
	public static void capTabel(){
		String sir="Denumire\t|Tip\t\t |StocInit|Vandute |PretUnit|";
		Linii(61,'=');
		System.out.println(sir);
		Linii(61,'=');
	}
	public static void capTabel1(){
		String sir="Denumire\t|Tip\t\t |Disponibile| PretUnit  |";
		Linii(58,'=');
		System.out.println(sir);
		Linii(58,'=');
	}
	public static void capTabel2(){
		String sir="Denumire\t|Tip\t\t |StocInit|Vandute |PretUnit|  %  |";
		Linii(67,'=');
		System.out.println(sir);
		Linii(67,'=');
	}
	public static void Formatari(int n,int i, Anvelopa A[] )
	{
		Formatter f=new Formatter();
		Formatter f1=new Formatter();
        String []s=new String[2];
		s[0]=A[i].getNume();
		s[1]=A[i].getTip();
		f.format("%-16s|%-16s|",s);
		System.out.print(f);
		String []sInt=new String[3];
		sInt[0]="";
		sInt[0]+=A[i].getStocI();
		sInt[1]="";
		sInt[1]+=A[i].getVandut();
		sInt[2]="";
		sInt[2]+=A[i].getPretUnit();
		f1.format("%8s|%8s|%8s|",sInt);
		System.out.println(f1);
	}
	public static void Formatari1(int n,int i, Anvelopa A[] )
	{
		Formatter f=new Formatter();
		Formatter f1=new Formatter();
        String []s=new String[2];
		s[0]=A[i].getNume();
		s[1]=A[i].getTip();
		f.format("%-16s|%-16s|",s);
		System.out.print(f);
		String []sInt=new String[2];
		int disponibil=A[i].getStocI()-A[i].getVandut();
		sInt[0]="";
		sInt[0]+=disponibil; //System.out.format("%2d %10s",i,sir);
		sInt[1]="";
		sInt[1]+=A[i].getPretUnit();
		f1.format("%11s|%11s|",sInt);
		System.out.println(f1);
	}
	public static void Formatari2(int n,int i, Anvelopa A[], int procent )
	{
		Formatter f=new Formatter();
		Formatter f1=new Formatter();
		double proc=1.0*A[i].getVandut()/A[i].getStocI()*100;
		if(proc<=procent){
			String []s=new String[2];
			s[0]=A[i].getNume();
			s[1]=A[i].getTip();
			f.format("%-16s|%-16s|",s);
			System.out.print(f);
			String []sInt=new String[4];
			sInt[0]="";
			sInt[0]+=A[i].getStocI();
			sInt[1]="";
			sInt[1]+=A[i].getVandut();
			sInt[2]="";
			sInt[2]+=A[i].getPretUnit();
			long p=(long)(proc*100);
			proc=p/100.0;
			sInt[3]="";
			sInt[3]+=proc;
			f1.format("%8s|%8s|%8s|%5s|",sInt);
			System.out.println(f1);
		} 
		
	}
	public static void Formatari3(int n,int i, Anvelopa A[], long Suma )
	{
		Formatter f=new Formatter();
		Formatter f1=new Formatter();
		double proc=1.0*A[i].getVandut()*A[i].getPretUnit()/Suma*100;
		String []s=new String[2];
		s[0]=A[i].getNume();
		s[1]=A[i].getTip();
		f.format("%-16s|%-16s|",s);
		System.out.print(f);
		String []sInt=new String[4];
		sInt[0]="";
		sInt[0]+=A[i].getStocI();
		sInt[1]="";
		sInt[1]+=A[i].getVandut();
		sInt[2]="";
		sInt[2]+=A[i].getPretUnit();
		long p=(long)(proc*100);
		proc=p/100.0;
		sInt[3]="";
		sInt[3]+=proc;
		f1.format("%8s|%8s|%8s|%5s|",sInt);
		System.out.println(f1);
		} 
	
	public static void Linii (int nrLinii,char c){
		for(int i=0;i<nrLinii;i++){
			System.out.print(c);
		}
		System.out.println();
	}
}
