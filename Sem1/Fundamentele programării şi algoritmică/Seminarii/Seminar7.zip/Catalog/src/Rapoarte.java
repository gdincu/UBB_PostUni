import java.io.BufferedReader;
import java.io.FileReader;
import java.util.Formatter;
import java.util.Scanner;
//import java.lang.*;

import java.io.*;


public class Rapoarte {
	public static String CitString(String sir){
		try{
			System.out.print(sir);
			Scanner S= new Scanner(System.in);
			return S.nextLine();			
		}
		catch(Exception E){
			System.out.println("Ai gresit, mai incearca");
			return CitString(sir);
		}	
	}
	
	public static int CitIntreg(String sir){
		try{
			System.out.print(sir);
			Scanner S= new Scanner(System.in);
			int I=S.nextInt();
			return I;			
		}
		catch(Exception E){
			System.out.println("Ai gresit, mai incearca");
			return CitIntreg(sir);
		}	
	}
	public static Student[] CitireDinFisier(){
		int n;
		Student St[]=null;
		try { BufferedReader fisIn = 
			  new BufferedReader(new FileReader("d:\\Cioban\\workspace\\Catalog\\src\\Student.txt"));
		      String s;
		      s=fisIn.readLine();
		      n=Integer.parseInt(s);
		      
		      
		      St=new Student[n];				//aloca n referinte pentru fiecare
		      									//Student
		      System.out.println("n="+St.length);
		      
		      int i=0;
		      while((s = fisIn.readLine())!= null){
			    String felii[]=s.split(",");	    
			    String nume=felii[0];
			    String materie=felii[1];
			    int nota=Integer.parseInt(felii[2]);
			    
			    St[i]=new Student();			//alocarea efectiva pentru comp. Student
			    St[i].setNume(nume);			//se atribiue valori lui Nume, Materie
			    St[i].setMaterie(materie);		//si Nota
			    St[i].setNota(nota);
			    
			    i++;
		     }
		      System.out.println("lungimea tabelului="+St.length);
		  fisIn.close();
		  
		} // try
	   catch(Exception e) {
	     System.out.println(e.getMessage());
	     e.printStackTrace();
	   } // catch //citiri valorile vectorului
	   return St;
    }
	public static void capTabel1(){
		String sir="|Student   |Materie\t | Nota |";
		String linii="=================================";
		System.out.println(linii);
		System.out.println(sir);
		System.out.println(linii);
	}
	public static void AfisTot(Student St[]){
		capTabel1();
		int i=0;
		while(i<St.length){
			//Formatter f=new Formatter();
			String []s=new String[3];
			s[0]=St[i].getNume();
			s[1]=St[i].getMaterie();
			int nota=St[i].getNota();
			s[2]=Integer.toString(nota);
			//f.format("|%-10s|%-13s|%6s|",s);
			//System.out.println(f);
			System.out.printf("|%-10s|%-13s|%6s|\n",s);
			i++;
		}	
	}
	public static void capTabel2(){
		String sir="|Student   | Nota |";
		String linii="===================";
		System.out.println(linii);
		System.out.println(sir);
		System.out.println(linii);
	}
	public static void AfisMaterie(Student St[]){
		String materie= CitString("Da materia:");
		System.out.println(materie);
		capTabel2();
		for(int i=0; i<St.length;i++){
			String mat=St[i].getMaterie();
			if(materie.equals(mat)){
				String []s=new String[2];
				s[0]=St[i].getNume();
				int nota=St[i].getNota();
				s[1]=Integer.toString(nota);
				System.out.printf("|%-10s|%6s|\n",s);
				
			}
		}	

	}
	
	public static void AfisStudent(Student []St){
		String nume= CitString("Da nume student:");
		System.out.println(nume);
		capTabel3();
		for(int i=0; i<St.length;i++){
			String numeS=St[i].getNume();
			if(nume.equals(numeS)){
				String []s=new String[2];
				s[0]=St[i].getMaterie();
				int nota=St[i].getNota();
				s[1]=Integer.toString(nota);
				System.out.printf("|%-10s|%6s|\n",s);
				
			}
		}	
		
	}
	public static void Sortare(Student[] St){
		boolean flag;				 // sortarea vectorului
		  int i,poz,pozInter;
		  poz    = pozInter = St.length-1;  
		  do
			{ flag=true;
			  for (i=0;i<poz;i++)
				   if (St[i+1].maiMicNume(St[i]))
						{ Student aux=St[i];
					      St[i]		 =St[i+1];			
						  St[i+1]	 =aux;			
						  pozInter = i;
						  flag     = false;
						}
			  poz=pozInter;
			}
		  while (!flag);

	}
	public static void AfisAlfabet(Student St[]){
		Sortare(St);
		AfisTot(St);
	}
	public static void AfisMedGen(Student St[]){
		Sortare(St);
		Student []MedGen=new Student[20];//acest tabel se va sorta supa medie generala
		String nume=new String();	//in nume se va retine numele primului student
		nume=St[0].getNume();		//pentru comparare, cand trec la student se 
									//seteaza pe noul nume
		int contorMG=0;				//contor pentru numarul de studenti(nume diferite)
		double media=0;				//media generala
		int i=0;					//contor pentru tabloul studenti
		while(i<St.length){
		   int nrNote=0;			//contor pt notele unui student
		   while(i<St.length && nume.equals(St[i].getNume())){
			  media+=St[i].getNota();
			  nrNote++; i++;
		   }						//s-a termint un student
		   media=media/nrNote;		//se calc. media si apoi se pune in MedGen
		   //System.out.println(nume+" "+media+" "+contorMG);
		   MedGen[contorMG]=new Student();
		   MedGen[contorMG].setNume(nume);
		   MedGen[contorMG].setMG(media);
		   contorMG++;
		   media=0;					//se reseteaza media si nrNote pe 0.
		   if(i<St.length) nume=St[i].getNume();
		}
		
		//for(i=0;i<contorMG;i++)
		//	System.out.println(MedGen[i].getNume()+" "+ MedGen[i].getMG());
		
		SortareMG(MedGen,contorMG-1);
		
		capTabel4();
		for(i=0; i<contorMG;i++){
			String []s=new String[2];
			s[0] =MedGen[i].getNume();
			media=MedGen[i].getMG()*100;
			int m=(int)(media);
			media=m/100.0;
			s[1]=Double.toString(media);
			System.out.printf("|%-10s| %6s |\n",s);
				
			}
		}	

	public static void capTabel4(){
		String sir="|Student   | MedGen |";
		String linii="=====================";
		System.out.println(linii);
		System.out.println(sir);
		System.out.println(linii);
	}
	public static void capTabel3(){
		String sir="|Student   | Nota |";
		String linii="===================";
		System.out.println(linii);
		System.out.println(sir);
		System.out.println(linii);
	}
	
	public static void SortareMG(Student[] MedGen,int n){
		boolean flag;				 // sortarea vectorului 
		do
		 { flag=true;
		   for (int i=0;i<n;i++)
		     if (MedGen[i].getMG()<MedGen[i+1].getMG())
						{ Student aux=MedGen[i];
					      MedGen[i]	 =MedGen[i+1];			
						  MedGen[i+1]=aux;			
						  flag     = false;
						}
		}
	   while (!flag);

	}
	
	public static int Meniu(){

		System.out.println();
		System.out.println("1.Citire date din fisier");
		System.out.println("2.Afisare tot");
		System.out.println("3.Afisare note pe Materie");
		System.out.println("4.Afisare note pe Student");
		System.out.println("5.Afisare alfabetica");
		System.out.println("6.Afisare medii generale");
		System.out.println("0.Terminare program");
		int Opt=CitIntreg ("da optiunea ta:");
		return Opt;
	}

	public static void main(String[] args) {
		int opt=Meniu();
		Student St[] =null;

		while(opt!=0){
			switch(opt){
			case 1:St=CitireDinFisier();
			       System.out.println("am citit corect datele din fisier");
				   break;
			case 2:AfisTot(St); 		//Afiseaza tot tabelul
				   break;
			case 3:AfisMaterie(St);		//Afiseaza dupa o materie selectata
			       break;
			case 4:AfisStudent(St);		//Afisare notele unui student
			       break;
			case 5:AfisAlfabet(St);	    //Afisare alfbetica dupa nume student
		           break;
			case 6:AfisMedGen(St);	    //Afisare medie generala pe student
	           break;
			       
			default:
				   System.out.println("ai gresit optiunea, mai incearca!!!");
			}
			opt=Meniu();
		}
		System.out.println("Program terminat");
	}	

}

