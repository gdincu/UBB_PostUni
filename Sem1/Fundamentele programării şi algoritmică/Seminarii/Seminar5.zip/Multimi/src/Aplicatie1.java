
public class Aplicatie1 {

    public static void AfisMultime(String prompter, Multime A){
    	System.out.print(prompter);
    	for(int i=0;i<A.getCard();i++)
    		System.out.print(A.getM(i)+" ");
    	
    	
    }
	public static void main(String[] args) {
		int []V={1,2,3,1,2,1,2,1,2,11};
        Multime A=new Multime(V);
        System.out.println();
        AfisMultime("Multimea A=",A);
        System.out.println();
        A.setM(1,15);
        AfisMultime("Multimea A=",A);
        System.out.println();
        A.setM(2,15);
        AfisMultime("Multimea A=",A);
        System.out.println();
        
	}

}
