
public class Multime {
     int []M;				//referinta spre memoria cu elementele
     public Multime(){		//constructor implicit
    	 M=null;
     }
     /*public Multime(int v[]){		// v={1,2,3,1,2}
    	 M=new int[v.length];		// M=v; se poate, dar M si v refera aceeasi zona de memorie
    	 for(int i=0;i<v.length;i++)
    		 M[i]=v[i];  	 
     }
     */
     private boolean Exista(int S[], int e){	//metoda private care verifica
    	 for(int i=0;i<S.length;i++)			//daca elemntul e este in vectorul S
    		 if(S[i]==e) return true;
    	 return false;
     }
     public Multime(int v[]){
    	 int []A=new int[v.length];
    	 A[0]=v[0];
    	 int contor=1;
    	 for(int i=1;i<v.length;i++){			//daca v[i] nu e in A, atunci se aduaga in A
    		 if(!Exista(A,v[i])) A[contor++]=v[i];
    	 }
    	 M=new int [contor];
    	 for (int i=0;i<contor;i++)
    		 M[i]=A[i];
    	 for(int i=0;i<M.length;i++)
    		 System.out.print(M[i]+ " ");
    	 	 
     }
    public int getCard(){
    	return M.length;
    }
	public int getM(int i) {
		return M[i];
	}
	public void setM(int i, int Val) {
		if(!Exista(M,Val)) M[i]=Val;
	}
	public Multime Inter(Multime A, Multime B){   //this A inter cu B
		// to do
		
		return this;
	}
	public Multime Reunion(Multime A, Multime B){   //this A inter cu B
		// to do
		
		return this;
	}
	public Multime Diferenta(Multime A, Multime B){   //this A inter cu B
		// to do
		
		return this;
	}
	
}
