import java.io.BufferedReader;
import java.io.FileReader;
import java.util.Scanner;


public class Rapoarte {
	public static int CitIntreg(String sir){
		try{
			System.out.print(sir);
			Scanner S= new Scanner(System.in);
			int I=S.nextInt();
			return I;			
		}
		catch(Exception E){
			System.out.println("Ai gresit, mai incearca");
			return CitIntreg(sir);
		}	
	}
	public static Student[] CitireDinFisier(){
		int n;
		Student St[]=null;
		try { BufferedReader fisIn = 
			  new BufferedReader(new FileReader("d:\\Cioban\\workspace\\Catalog\\src\\Student.txt"));
		      String s;
		      s=fisIn.readLine();
		      n=Integer.parseInt(s);
		      St=new Student[n];
		      int i=0;
		      while((s = fisIn.readLine())!= null){
			    String felii[]=s.split(",");	    
			    String nume=felii[0];
			    String materie=felii[1];
			    int nota=Integer.parseInt(felii[2]);
			    St[i]=new Student();
			    St[i].setNume(nume);
			    St[i].setMaterie(materie);
			    St[i].setNota(nota);
			    i++;
		     }
		      System.out.println("lungimea tabelului="+St.length);
		  fisIn.close();
		  
		} // try
	   catch(Exception e) {
	     System.out.println(e.getMessage());
	     e.printStackTrace();
	   } // catch //citiri valorile vectorului
	   return St;
    }
	public static void capTabel(){
		String sir="|Student |Materie\t| Nota |";
		String linii="----------------------------------------";
		System.out.println(linii);
		System.out.println(sir);
		System.out.println(linii);
	}
	public static void AfisTot(Student St[]){
		capTabel();
		int i=0;
		while(i<St.length){
			System.out.print("|"+St[i].getNume()+"\t|");
			System.out.print(St[i].getMaterie()+"\t|");
			System.out.println(St[i].getNota()+"|");
			i++;
		}
		
		
	}
	
	
	public static int Meniu(){
		System.out.println();
		System.out.println("1.Citire date din fisier");
		System.out.println("2.Afisare bruta");
		System.out.println("3.Afisare note pe Materie");
		System.out.println("4.Afisare note pe Student");
		System.out.println("5.Afisare medie generala descrescator");
		System.out.println("0.Terminare program");
		int Opt=CitIntreg ("da optiunea ta:");
		return Opt;
	}

	public static void main(String[] args) {
		int opt=Meniu();
		Student St[] =null;

		while(opt!=0){
			switch(opt){
			case 1:St=CitireDinFisier();
			       System.out.println("am citit corect datele din fisier");
				   break;
			case 2:AfisTot(St); 		//Afiseaza tot tabelul
				   break;
			case 3://AfisMaterie(St);	//Afiseaza marfa existenta
			       break;
			case 4://AfisStudent(St);	//Afisare marfa epuizata
			       break;
			case 5://AfisMedie(St);	    //Afisare marfa epuizata
		       break;
			       
			default:
				   System.out.println("ai gresit optiunea, mai incearca!!!");
			}
			opt=Meniu();
		}
		System.out.println("Program terminat");
	}	

}

