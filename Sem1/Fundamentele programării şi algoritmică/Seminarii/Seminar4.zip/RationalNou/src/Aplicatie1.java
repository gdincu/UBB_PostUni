
public class Aplicatie1 {
	public static void afisRational(String s, Rational R){
		System.out.print(s);
		if(R.getNumit()==1) System.out.print(R.getNumar());
		else if(R.getNumar()==0) System.out.print(0);
		     else System.out.print(R.getNumar()+"/"+R.getNumit());
	}
	
	
	
	public static void main(String[] args) {
		Rational R1=new Rational(5);
		Rational R2=new Rational(100,-200);
		Rational R3=new Rational(R1);
		Rational R4=new Rational();
		Rational R5=new Rational(0.2);
		afisRational("R1=",R1);
		System.out.println();
		afisRational("R2=",R2);
		System.out.println();
		afisRational("R3=",R3);
		System.out.println();
		afisRational("R4=",R4);
		System.out.println();
		afisRational("R5=",R5);
		Rational R6=new Rational();
		R6.Aduna(R2,R5);
		afisRational("\nR2+R5=",R6);
		R6.Scade(R2,R5);
		afisRational("\nR2-R5=",R6);
		R6.Ori(R2,R5);
		afisRational("\nR2*R5=",R6);
		R6.Slash(R2,R5);
		afisRational("\nR2/R5=",R6);
		R6.Slash(R2,R4);
		afisRational("\nR2/R4=",R6);
		System.out.println("\nProgram terminat");
	  }
		
	}


