import java.util.Scanner;

public class SistemLiniar {

	/**
	 * @param args
	 */
	public static Rational CitRat(String sir){
	   System.out.println(sir);
	   long N,M;
	   N=Citire("numarator:");
	   M=Citire("numitor");
	   return (new Rational(N,M));
	
	}
	public static long Citire(String sir){
		System.out.print(sir);
		try {
			Scanner scn = new Scanner(System.in);		//citire sir si parsare
			int Nr=scn.nextInt();						//in long
			return Nr;
		}
		catch(Exception exp) {
			System.out.println("Ai gresit!! Da numar intreg!");
			return Citire(sir);							//apel recursiv pe orice eroare
		}
				        
	} 
	public static void Afiseaza(Rational r)
	 { if(r.esteZero())
		  System.out.print(0);
	   else
		   if (r.getNumit()==1)
			   System.out.print(r.getNumar());
		   else 
			   System.out.print(r.getNumar()+"/"+r.getNumit());
	 }	
	public static void AfisEcuatie(Rational A,Rational B, Rational C){
		  Afiseaza(A);
		  System.out.print("X+");
		  if(B.getNumit()<0)System.out.print("\b");
		  Afiseaza(B);         
		  System.out.print("Y=");
		  Afiseaza(C);System.out.println();
		  
	  }
	public static Rational Determinant(Rational A, Rational B, Rational C, Rational D){
		   Rational AOriD=new Rational();
		   AOriD.Ori(A,D);					//AOriD=A*D;
		   Rational BOriC=new Rational();	
		   BOriC.Ori(B,C);					//BOriC=B*C;
		   Rational Minor=new Rational();
		   Minor.Scade(AOriD,BOriC);		//Minor=A*D-B*C
		   return Minor;
	  }
	public static long AfisMeniu(){
		  System.out.println();
		  System.out.println("1.Citire coeficienti sistem");
		  System.out.println("2.Rezolvare sistem");
		  System.out.println("0.Terminare program");
		  return Citire("Optiunea ta:");
	  } 
	public static void main(String[] args) {
		long Opt =AfisMeniu();
		Rational a=null;
		Rational b=null;
		Rational c=null;
		Rational d=null;
		Rational e=null;
		Rational f=null;
		
 	    while(Opt!=0){
			   switch((int)Opt){
			    case 1: a=CitRat("coef a:");
			    		b=CitRat("coef b:");
			    		c=CitRat("coef c:");
			    		d=CitRat("coef d:");
			    		e=CitRat("coef e:");
			    		f=CitRat("coef f:");
			    		
			    		break;	    		
			    case 2: System.out.println("sistemul de 2 ecuatii cu 2 necunoscute:");
						AfisEcuatie(a,b,c);
						AfisEcuatie(d,e,f);
						System.out.println();
						
						Rational Delta=new Rational();	//instantiere Delta
						Delta=Determinant(a,b,d,e);		//Calcul Delta
						System.out.print("delta=");Afiseaza(Delta);System.out.println();
						
				   		Rational Dx=new Rational();		//instantiere Dx
				   		Dx=Determinant(c,b,f,e);		
				   		System.out.print("deltaX=");Afiseaza(Dx); System.out.println();
				   		
				   		Rational Dy=new Rational(a);	//instantiere Dy
				   		Dy=Determinant(a,c,d,f);
				   		System.out.print("deltaY=");Afiseaza(Dy); System.out.println();
				   		
				   		if (!Delta.esteZero())
				   			{ Rational x= new Rational(Dx);
				   			  x.Slash(Dx,Delta);
				   			  Rational y= new Rational(Dy);
				   			  y.Slash(Dy,Delta);
				   			  System.out.print("x=");Afiseaza(x);System.out.println();
				   			  System.out.print("y=");Afiseaza(y);System.out.println();
				   			}
				   		else if (Dx.esteZero() && Dy.esteZero())
				   				 System.out.println("sistem nedeterminat");
				   			 else System.out.println("sistem incompatibil");     	
	    				break;
			 
			            
			    default:System.out.println("Da optiune valida!!");        
			   }
			   Opt=AfisMeniu();
		   }
		   System.out.println("Program terminat");
	}
}

