
public class Rational {
   private long numar;		//un rational se retina ca 2 valori =numar si numit
   private long numit;
   public Rational(){		//constructor implicit initializare cu 0
	   numar=0;
	   numit=1;
   }
   public Rational(long a, long b){	//  numarul 100/-200 se retine ca -1/2
	   numar=a;
	   if(b!=0) numit=b;
	   else     numit=1;
	   Simplifica();
   }
   public Rational(Rational R){		//constructor rational din alt rational R
	   if(this!=R) { numar=R.numar;
	                 numit=R.numit;
	               }
   }
   public Rational(long I){
	   numar=I;
	   numit=1;
   }
   public Rational(double d){	//constructor din numar real
	 long p=(long)d;
	 long q=1;
	 while(p!=d){			//algoritmica??
		 	 d*=10;
		 	 p=(long)d;
		 	 q*=10;
	 }
	 numar=p;
	 numit=q;
	 Simplifica();		 
   }
   
   private void Simplifica(){
	   long Nu=Math.abs(numar);	//valori absolute pentru numar si numit
	   long Mu=Math.abs(numit);
	   if(numar*numit<0){
		                 numar=-Nu;
		                 numit=Mu;
	                    }
	   else {numar=Nu;
	         numit=Mu;
	   }
	   long CMMDC=Euclid(Nu, Mu);
	   numar/=CMMDC;
	   numit/=CMMDC;  
   }
   public static long Euclid(long x,long y)	//metoda statica
   {if(x==0 && y==0)  return 0;
    if(x==0 && y>0)   return y;
    if(x>0  && y==0)  return x;
    if(x==y) 		  return x;
    if (x>y) 		  return Euclid(x-y,y);
    				  return Euclid(x,y-x);
   }
   							//accesori
public long getNumar() {
	return numar;
}
public void setNumar(long numar) {
	this.numar = numar;
}
public long getNumit() {
	return numit;
}
public void setNumit(long numit) {
	this.numit = numit;
}

public boolean esteZero(){
    if(numar==0) return true;
    /*else*/	 return false;
}


public void Aduna(Rational R1, Rational R2){			//this=R1+R2
	this.numar=R1.numar*R2.numit+R1.numit*R2.numar;
	this.numit=R1.numit*R2.numit;
	this.Simplifica();
}
public void Scade(Rational R1, Rational R2){			//this=R1-R2
	this.numar=R1.numar*R2.numit-R1.numit*R2.numar;
	this.numit=R1.numit*R2.numit;
	this.Simplifica();
}
public void Ori(Rational R1, Rational R2){			//this=R1-R2
	this.numar=R1.numar*R2.numar;
	this.numit=R1.numit*R2.numit;
	this.Simplifica();
}  
public void Slash(Rational R1, Rational R2){			//this=R1-R2
	if(R2.esteZero()) {
						this.numar=R1.numar;
						this.numit=R1.numit;
	                   }
	else {this.numar=R1.numar*R2.numit;
	      this.numit=R1.numit*R2.numar;
	      this.Simplifica();  }
	
	}
	
}  

