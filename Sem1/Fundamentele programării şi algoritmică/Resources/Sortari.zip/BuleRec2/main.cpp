#include <iostream>
#include <iomanip>

using namespace std;


void Swap(int& x, int& y){
  int t=x;
      x=y;
      y=t;
}

void SortR(int x[],int n, int i, bool Ok)    //apel cu Sort(x,n,1,true)
{if (i<n){
   if (x[i]>x[i+1]){
       Ok=false;
       swap(x[i],x[i+1]);
    }
   SortR(x,n,i+1,Ok);
  }
 else if(Ok==false) SortR(x,n-1,1,true);
}



void ReadSir(int& n, int x[]){
  int i;
  cout<<"da dim:";
  cin>>n;
  for(i=1;i<=n;i++){
      cout << "x["<<i<<"]=";
      cin  >> x[i];
  }
}
void AfisSir(int n, int x[]){
  cout<<"\nsirul sortat:";
  for(int i=1;i<=n;i++)
     cout<<setw(5)<<x[i];

}

int main()
{   int x[100],n;
    bool Ok;
    ReadSir(n,x);
    Ok=false;
    SortR  (x,n,1,Ok);
    AfisSir(n,x);
    cout << endl << "Hello world!" << endl;
    return 0;
}
