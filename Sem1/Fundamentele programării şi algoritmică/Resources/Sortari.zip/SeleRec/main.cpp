#include <iostream>

using namespace std;
void Change (int &a, int &b)
{  int aux;
   aux=a;
   a=b;
   b=aux;
}

void SelectRec(int n, int x[],int i, int j)
{  if(i<n)
     if(j<=n){
            if(x[i]>x[j])   Change(x[i],x[j]);
            SelectRec(n,x,i,j+1);
     }
    else SelectRec(n,x,i+1,i+2);
}

void CitRecTab(int n,int x[11])
{ if(n>0)
    {   CitRecTab(n-1,x);
        cout<<"X["<<n<<"]=";
        cin>>x[n];
        }
}

void AfisRecTab(int n,int x[11])
{ if(n>0)
    {  AfisRecTab(n-1,x);
       cout<<x[n]<<" ";
    }
}
int main()
{
    int n,x[11];
    cout<<" da n: ";
    cin >>n;
    CitRecTab(n,x);
    SelectRec(n,x,1,2);

    AfisRecTab(n,x);

    return 0;
}
