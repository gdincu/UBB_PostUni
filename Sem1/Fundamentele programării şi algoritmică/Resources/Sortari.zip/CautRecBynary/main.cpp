#include <iostream>
#include <iomanip>
using namespace std;


int BinaryRec(int st, int dr, int x[], int val)         //apel cu InsertRec1(n,x)
{   int mij=(st+dr)/2;
    if(val==x[mij]) return mij;
    if(st<=dr)
          {if(val>x[mij]) return BinaryRec(mij+1,dr,x,val);
           else           return BinaryRec(st,mij-1,x,val);
          }
    else return -1;

}

void ReadSir(int n, int x[]){
  if(n>0){
        ReadSir(n-1,x);
        cout << "x["<<n<<"]=";
        cin  >> x[n];
  }
}

void AfisSir(int n, int x[]){
  if(n>0){
      AfisSir(n-1,x);
      cout<<setw(5)<<x[n];
  }
}
int main()
{   int X[100],n,val,poz;
    cout<<"da dim:";
    cin >>n;
    ReadSir(n,X);
    cout<<"da val de cautat:";
    cin >>val;
    cout<<endl;
    AfisSir(n,X);
    cout<<endl;
    poz=BinaryRec(1,n,X,val);
    cout<<poz<<endl;
    if(poz>0) cout<<"pe poz:"<<poz;
    else      cout<<"nu-i in tablou";


    cout << endl << "Program terminated" << endl;
    return 0;
}
