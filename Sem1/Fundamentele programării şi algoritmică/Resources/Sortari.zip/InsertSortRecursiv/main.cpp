#include <iostream>
#include <iomanip>
using namespace std;

void InserTotalRec(int n, int X[], int i, int j,int Aux) //apel InsertTotalRec(n,x,2,1,x[2])
{  if(i<=n){
     if(j==i-1) Aux=X[i];
     if(j>0 &&  Aux<X[j]){
         X[j+1]=X[j];
         InserTotalRec(n,X,i,j-1,Aux);
     }
     else {
          X[j+1]=Aux;
          InserTotalRec(n,X,i+1,i,Aux);

     }
   }
}

void InsertRec1(int n, int X[])         //apel cu InsertRec1(n,x)
{ if (n>2){                             //partial recursiv
       InsertRec1(n-1,X);
       int Aux=X[n];
       int j=n-1;
       while(j>0 && Aux<X[j]){
          X[j+1]=X[j];
          j--;
       }
       X[j+1]=Aux;
    }

}
void InsertRec2(int n, int X[],int j, int Aux)         	//apel cu InsertRec1(n,x,1,X[2])  nu merge!!!!
{ if (n>1){                             		        //total recursiv
       InsertRec2(n-1,X,j,X[n-1]);
       Aux=X[n];
       int j=n-1;
       if (j>0 && Aux<X[j]) {
            X[j+1]=X[j];
            InsertRec2 (n,X,j-1,Aux);
       }
       else {X[j+1]=Aux;
             //???
       }
    }

}


void ReadSir(int n, int x[]){
  if(n>0){
        ReadSir(n-1,x);
        cout << "x["<<n<<"]=";
        cin  >> x[n];
  }
}

void AfisSir(int n, int x[]){
  if(n>0){
      AfisSir(n-1,x);
      cout<<setw(5)<<x[n];
  }
}
int main()
{   int x[100],n;
    cout<<"da dim:";
    cin >>n;
    ReadSir(n,x);
    //InsertRec1  (n,x);
    InserTotalRec(n,x,2,1,x[2]);
    //InsertRec2  (n,x,1,x[2]);
    cout<<"\nsirul sortat:";
    AfisSir(n,x);
    cout << endl << "Program terminated" << endl;
    return 0;
}
