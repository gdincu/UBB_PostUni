for num in range(10,15): 	    # num va lua valori intre 10 si 14(inclusiv) 
    for i in range(2,num):          # i va itera intre 2 si num, si va fi primul factor (daca exista)
	if(num % i==0):
            j= num//i 	            # j va fi al 2-lea factor  
            print('%d = %d * %d' %(num,i,j))  # se tiparesc cei doi factori
            break 		            # se sare din ciclul dupa i in ciclul dupa num 
    else: 			            # else este parte a corpului primul ciclu for (dupa num) 
          print(num, ' este numar prim')
