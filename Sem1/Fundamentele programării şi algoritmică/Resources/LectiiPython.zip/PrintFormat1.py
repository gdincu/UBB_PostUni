count=1
win=100
loss=3.14
print("%i: %i win, %4.2f loss, %6.3f" % (count,win,loss,float(win)/loss))