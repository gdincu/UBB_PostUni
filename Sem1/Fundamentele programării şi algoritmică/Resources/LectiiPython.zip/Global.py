Money = 2000
def AddMoney(Money):
   # Uncomment the following line to fix the code:
   # global Money
   Money = Money + 1
   print('interior:',Money)
   return Money
   print(globals())
   print (locals())
print (Money)
Money=AddMoney(Money)
print (Money)
print(globals())
print (locals())

import math
print (dir(math))
