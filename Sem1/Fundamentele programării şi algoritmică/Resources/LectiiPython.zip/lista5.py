list=[4,5,16,6,8,7,6,700]
print(list.count(6))		#Returns count of how many times obj occurs in list

print(list.index(6))		#Returns the lowest index in list that obj appears
list.insert(4, 100)	#Inserts object obj into list at offset index
print(list);
l=list.pop()	#Removes and returns last object or obj from list
print(list);
print(l);
list.remove(6)	#Removes object obj from list
print(list)
list.reverse()		#Reverses objects of list in place
print(list)
list.sort()		#Sorts objects of list, use compare func if given
print(list)
