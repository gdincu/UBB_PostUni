def PrintInfo( arg1, *vartuple ): 
	
        print(arg1)
        for var in vartuple:
                print(var)
        return
        
# Apel
def Main():
    	PrintInfo(10)
    	PrintInfo(70, 60, 50 )
    	Lista=[100,101,102]
    	PrintInfo
    	arg="ion"
    	PrintInfo(arg,Lista)
    	Lista.append(99)
    	PrintInfo(arg,Lista)
    	
Main()
