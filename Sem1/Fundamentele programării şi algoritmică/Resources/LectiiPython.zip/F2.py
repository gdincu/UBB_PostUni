# Function definition is here 
def PrintInfo( name, age = 35 ): 
	"This prints a passed info into this function" 
	print ("Name: ", name)
	print ("Age ", age)
	return; 
# Now you can call PrintInfo function 
def Main():
	PrintInfo(age=50, name="miki")
	PrintInfo(name="miki" );
	PrintInfo(name="ion",age=10)
Main()
 
