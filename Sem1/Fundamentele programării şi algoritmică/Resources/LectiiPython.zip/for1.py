for litera in 'Python':   # primul exemplu
  print('litera curenta:'+ litera)

fructe = ['banana', 'mar', 'mango'] 
for fruct in fructe: 	# alt  exemplu 
  print('fructul curent :'+ fruct)

print("Good bye!") 
