''' program ce determina   oglinda unui numar   creat de Vasile Cioban
    11.10.2012
''' 
def Citeste():
   n=int(input("dati un numar natural:"))
   return n; 

def Oglinda(a):
  Og=0
  while (a>0):
    UltCifra=a % 10
    Og=Og*10+UltCifra
    a=a//10
  return Og;

def Main():    
  a=Citeste();
  d=Oglinda(a);
  print ("Oglinda="+str(d));
  if (d==a): print("numarul este si palindrom!")
  print ("program terminated");

Main()
