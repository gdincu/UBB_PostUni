import time; # This is required to include time module. 
import calendar

ticks = time.time() 
print ("Numarul de secunde din 12:00am, January 1, 1970:", ticks)

Localtime = time.localtime(time.time())
print ("t-uplul timp curent:", Localtime)

Localtime = time.asctime( time.localtime(time.time()) )
print ("Timpul curent local (inteligibil) :", Localtime)



Cal = calendar.month(2016, 2)
print ("Calendarul lunii:")
print (Cal)

print(time.altzone)

print(calendar.calendar(2016,w=2,l=2,c=6))

