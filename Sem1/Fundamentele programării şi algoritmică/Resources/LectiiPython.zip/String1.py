def Ex():
    str = 'Hello World!'    
    print (str) 		# Afiseaza stringul complet 
    print (str[0]) 	# Afiseaza primul caracter 
    print (str[2:5]) 	# Afiseaza al 3,4,5-lea caracter
    print (str[2:]) 	# Afiseaza incepand cu al 3-lea
    print (str[:5])     
    print (str * 2) 	# Afiseaza stringul de 2 ori 
    print (str + "TEST") # Afis. 2 siruri concatenate
    
Ex()
