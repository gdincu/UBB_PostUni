''' program ce determina   oglinda unui numar   creat de Vasile Cioban
    19.11.2015
''' 
def Citeste():
   n=int(input("dati un numar natural:"))
   return n; 

def OglRec(n,Og):
	if(n==0): return Og
	else: return OglRec(n//10,Og*10+n%10)

def Main():    
  a=Citeste();
  d=OglRec(a,0);
  print ("Oglinda="+str(d));
  if (d==a): print("numarul este si palindrom!")
  print ("program terminated");

Main()

#OgRec(127,0)->OgRec(12,7)->Og(1,72)->Og(0,721)->721
