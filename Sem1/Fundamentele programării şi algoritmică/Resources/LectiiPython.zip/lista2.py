list1 = ['physics', 'chemistry', 1997, 2000]
list2 = [11, 12, 13, 14, 15, 16, 17 ]
print ("list1[0]: ", list1[0])
print ("list2[1:5]: ", list2[1:5])
print ("list2[o:]:",list2[0:])
print ("list2[o:7]:",list2[0:7])
print ("list2[o:6]:",list2[0:6])
print ("list2[o:10]:",list2[0:10])
print ("list2[-10:10]:",list2[0:10])
print ("list2[-1]:",list2[-1])
print ("list2[-2]:",list2[-2])
print ("list2[-3]:",list2[-3])