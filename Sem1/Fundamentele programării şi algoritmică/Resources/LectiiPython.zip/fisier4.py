fo = open("f2.txt", "r+") 
str = fo.read(5); 
print ("Sirul citit este: ", str)
pos = fo.tell()	        # verifica pozitia curenta
print ("Pozitia curenta:", pos)
pos = fo.seek(0, 0);    # repozitionarea cursorului la inceput de fisier
str = fo.read(11); 
print ("din nou citire:", str)
fo.close() 
