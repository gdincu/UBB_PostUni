fo = open("f2.txt", "w") 
fo.write ("Python is a great language.\nYeah its great!!\n")
fo.close()

