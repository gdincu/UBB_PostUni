tup1 = ('physics', 'chemistry', 1997, 2000);
tup2 = (1, 2, 6, 10, 8 );
tup3 = "z", "a", "c", "d";
tup4 = ();
print (tup1);
print (tup1[0:])
print (tup2[2:3])
print (tup3[-4])
print (tup4) 
print ("maximul este:", max(tup2))
print ("minimul este:", min(tup3))
