fructe = ['banana', 'mar', 'mango'] 
print("ungimea listei de fructe",len(fructe))
for index in range(len(fructe)):
        print(index," fructul curent:" + fructe[index]) 
        print("Good bye!")

