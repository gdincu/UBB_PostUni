str = input("Enter your input: "); 
print ("Received input is : ", str) 