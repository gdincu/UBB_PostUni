def Conv():
  print (set("ababab"))
  for i in range(32,65):
    print(chr(i)+" ")

Conv()
