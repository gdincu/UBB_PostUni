fo = open("f2.txt", "r") 
str = fo.read(11); 
print ("Sirul este citit: ", str)
fo.close() 

fo = open("f2.txt", "r") 
str = fo.read();
print ("Sirul este citit:\n", str)
fo.close() 
