list1 = ['physics', 'chemistry', 1997, 2000]
print("Value available at index 2: " + str(list1[2]))
list1[2] = 2013
print("New value available at index 2: " +str(list1[2]))
list1.append(2014)
print(list1[0:])
list1=list1	+ [10] +[11]
print(list1[0:])