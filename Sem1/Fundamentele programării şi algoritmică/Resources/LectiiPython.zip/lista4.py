list1=["Fizica","Chimie"]
list2=["Chimie","Fizica"]
#if (cmp(list1, list2)):		#Compara  elementele a doua liste
#   print("listele sunt congruente");
print(len(list1))		#Returneaza numarul de elemente din lista
print("maximul"+ max(list1))		#Returneaza elementul de valoare maxima din lista
print("minimul"+min(list2))		#Returneaza elementul de valoare minima din lista
list3=[10,9,8,12,17,13]
print("maximul:"+ str(max(list3)))		#Returneaza elementul de valoare maxima din lista
print("minimul:"+ str(min(list3)))		#Returneaza elementul de valoare minima din lista


list('1,2,3')		#Converteste un tuplu intr-o lista
print(list)