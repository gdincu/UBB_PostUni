for litera in 'Python': 			# First Example 
    if (litera == 'h'):
        break 
    print('litera curenta :', litera)
var = 10 				# Second Example 
while (var > 0):
    print('valoarea curenta :', var)
    var = var -1 
    if (var == 5):
        break
print('Good Bye');
