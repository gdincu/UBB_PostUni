def Lista6():
    L1 = [ 'abcd', 786 , 2.23, 'john', 70.2 ]
    L2 = [123, 'john'] 
    print(L1) 		# Afiseaza lista L1 
    print(L1[0])	 	# Afiseaza primul element al liste L1 
    print(L1[1:3])		# Afiseaza elementele al-2,3-lea
    print(L1[2:])		# Afiseaza incepand cu al 3-lea element
    print(L1[:3])               # Afiseaz de la inceput la L1[2]
    print(L2 * 2)		# Afiseaza L2 de 2 ori 
    print(L1+L2)		# Afiseaza listele L1 si L2 concatenate

Lista6()
