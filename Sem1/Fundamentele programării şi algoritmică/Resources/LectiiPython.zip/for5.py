for litera in 'Python': 		# First Example 
    if (litera == 'h'):
        continue
    print('litera curenta:',litera)
var = 6                                 # Second Example 
while (var > 0):
    var = var -1
    if (var == 3):
        continue 
    print ("valoarea curenta:", var)

print ("Good bye!") 
