
# Function definition is here 
def PrintInfo( Name, Age ): 
	"This prints a passed info into this function" 
	print ("Name: ", Name)
	print ("Age ", Age)
	return
# Now you can call PrintInfo function 

def Main():
	PrintInfo( Age=50, Name="miki" );
	PrintInfo( Name="miki", Age=20 );
	Name="ion"
	Age=25
	PrintInfo( Name, Age)
	#PrintInfo( Name="miki")
	PrintInfo( )

Main()
