import java.io.*;
import java.util.Formatter;
import java.util.Scanner;
public class Aplicatie {
	public static int CitIntreg(String sir){
		try{
			System.out.print(sir);
			Scanner S= new Scanner(System.in);
			int I=S.nextInt();
			return I;			
		}
		catch(Exception E){
			System.out.println("Ai gresit, mai incearca");
			return CitIntreg(sir);
		}	
	}
	public static void capTabel(){
		String sir="Denumire\tTip\tStocInit\tVandute\tPretUnit";
		String linii="--------------------------------------------------------";
		System.out.println(linii);
		System.out.println(sir);
		System.out.println(linii);
	}
	public static void capTabel1(){
		String sir="Denumire\tTip\tDisponibile\tPretUnit";
		String linii="------------------------------------------------";
		System.out.println(linii);
		System.out.println(sir);
		System.out.println(linii);
	}
	public static void AfisTot(int n, Anvelopa A[]){
		capTabel();
		for(int i=0;i<n;i++){
			   String sir=new String();
			   String tip=new String();
			   String tab="\t ";
			   sir=A[i].getNume()+tab+A[i].getTip();
			   tip=A[i].getTip();
			   if(tip.length()>0)sir=sir+tab;
			   else              sir=sir+tab+tab;
			   sir=sir+A[i].getStocI()+tab+A[i].getVandut()+tab+
			       A[i].getPretUnit();
			   System.out.println(sir);
		   }
	}
	public static void AfisEpuizate(int n, Anvelopa A[]){
		capTabel();
		for(int i=0;i<n;i++){
			  if(A[i].getStocI()==A[i].getVandut()){
				  String sir=new String();
				   String tip=new String();
				   String tab="\t ";
				   sir=A[i].getNume()+tab+A[i].getTip();
				   tip=A[i].getTip();
				   if(tip.length()>0)sir=sir+tab;
				   else              sir=sir+tab+tab;
				   sir=sir+A[i].getStocI()+tab+A[i].getVandut()+tab+
				       A[i].getPretUnit();
				   System.out.println(sir);  
			  }
		   }
	}
	public static void AfisDisponibile(int n, Anvelopa A[]){
		capTabel1();
		for(int j=0;j<n;j++){
			if(A[j].getStocI()>A[j].getVandut()){   
			   String sir=new String();
			   int disp=A[j].getStocI()- A[j].getVandut();
			   sir=A[j].getNume()+"\t"+A[j].getTip()+"\t"+
			       disp+"\t"+A[j].getPretUnit();
			   System.out.println(sir);
			}  
		   }
	}
	
	public static int CitireDinFisier(Anvelopa A[]){
		int n=0;
		try {
		      BufferedReader fisIn = 
			  new BufferedReader(new FileReader("d:\\Cioban\\workspace\\MagazinAnvelope\\src\\Magazin.txt"));
		  String s;
		  while((s = fisIn.readLine())!= null){
			  String felii[]=s.split(",");
			  String nume=felii[0];
			  String tip=felii[1];
			  int stocI=Integer.parseInt(felii[2]);
			  int vandute=Integer.parseInt(felii[3]);
			  int pretU=Integer.parseInt(felii[4]);	  
			  A[n]=new Anvelopa();
			  A[n].setNume(nume);
			  A[n].setTip(tip);
			  A[n].setStocI(stocI);
			  A[n].setVandut(vandute);
			  A[n].setPretUnit(pretU);
			  n++;
		  }
		  fisIn.close();
		} // try
	   catch(Exception e) {
	     System.out.println(e.getMessage());
	     e.printStackTrace();
	   } // catch									//citiri valorile vectorului
	  return n;
	
	}
	public static int Meniu(){
		System.out.println();
		System.out.println("1.Citire date din fisier");
		System.out.println("2.Afisare toata marfa");
		System.out.println("3.Afisare disponibile");
		System.out.println("4.Afisare epuizate");
		System.out.println("0.Terminare program");
		int Opt=CitIntreg("da optiunea ta:");
		return Opt;
	}

	
	
public static void main(String[] args) {
		int opt=Meniu();
		Anvelopa A[] = new Anvelopa[10];
		int lung=0;	   //numarul de elemente al vectorului A
	
		while(opt!=0){
			switch(opt){
			case 1:lung=CitireDinFisier(A);
			       System.out.println("am citit corect datele din fisier");
				   break;
			case 2:AfisTot(lung,A); 		//Afiseaza tot tabelul
				   break;
			case 3:AfisDisponibile(lung,A);	//Afiseaza marfa existenta
			       break;
			case 4:AfisEpuizate(lung,A);	//Afisare marfa epuizata
			       break;
			default:
				   System.out.println("ai gresit optiunea, mai incearca!!!");
			}
			opt=Meniu();
		}
		System.out.println("Program terminat");
	}	
}
