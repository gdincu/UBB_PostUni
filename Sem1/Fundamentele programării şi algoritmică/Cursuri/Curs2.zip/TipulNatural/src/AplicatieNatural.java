
public class AplicatieNatural {
    
	public static void main(String[] args) {
	   Natural x=new Natural(3);
	   Natural y=new Natural(2);
       x.Aduna(y);
	}

}
