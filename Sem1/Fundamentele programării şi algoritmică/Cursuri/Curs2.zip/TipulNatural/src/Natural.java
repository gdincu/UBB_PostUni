
public class Natural {
   private long n;
   public Natural(){		//constructor implicit
      n=0;
   }
   public Natural(long m){
	   if(m>0) n=m;
	   else    n=0;
   }
   public Natural(Natural N){
	   if(this!=N) n=N.n;
	   else {System.out.println("nu-l copiem in el insusi");
	         n=0;
	        }
	   } 
   public static Natural Aduna(Natural n1, Natural n2){
	   Natural N=new Natural(n1.n+n2.n);
	   return N;
   }
   public void Aduna(Natural N1){
	   n+=N1.n;
   }
   
   
}


   //Natural n1=new Natural();
   //Natural n2=new Natural(10);