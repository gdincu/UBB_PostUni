import java.util.Scanner;
	public class Bule {
		public static int CitIntreg(String sir){
			try{
				System.out.print(sir);
				Scanner S= new Scanner(System.in);
				int I=S.nextInt();
				return I;			
			}
			catch(Exception E){
				System.out.println("Ai gresit, mai incearca");
				return CitIntreg(sir);
			}
			
		}
	public static void Citeste(int v[]){
		  for(int i=0;i<v.length;i++){
				v[i]=CitIntreg("mai da un element:");
			}		
		}
	public static void tehnicaBule(int v[]){
          boolean flag;				 // sortarea vectorului
		  int i,aux,poz,pozInter;
		  poz    = pozInter = v.length-2;  
		  do
			{ flag=true;
			  for (i=0;i<=poz;i++)
				   if ( v[i] > v[i+1] )
						{ aux    = v[i];			
						  v[i]   = v[i+1];			
						  v[i+1] = aux;				
						  pozInter = i;
						  flag     = false;
						}
			  poz=pozInter;
			  afisVector(v);
			  System.out.println("\nultima poz. interschimbare "+poz);
			}
		  while (!flag);
		}

		
	public static int Meniu(){
			System.out.println();
			System.out.println("1.Citire vector");
			System.out.println("2.Sortare bule");
			System.out.println("3.Afisare vector");
			System.out.println("0.Terminare program");
			int Opt=CitIntreg("da optiunae ta:");
			return Opt;
		}
	public static void afisVector(int v[]){
			System.out.print("Elemente vector:");
			for(int i=0;i<v.length;i++){
				System.out.print(v[i]+" ");
			}
		}	
			
	public static void main(String[] args) {
			int opt=Meniu();
			int v[]=null;		//v este referinta spre un vector
			int lung;			//numarul de elemente al vectorului
		
			while(opt!=0){
				switch(opt){
				case 1: 									//citiri valorile vectorului
						lung=CitIntreg("da lungime vect:");	//citirea numarului de elemente
						v=new int [lung];					//instantierea lui v
						Citeste(v);
					    break;
				case 2: 									//citire val de cautare
					    tehnicaBule(v);
					    break;
				case 3: afisVector(v);	//afisare vector
				        break;
				default:
					   System.out.println("ai gresit optiunea, mai incearca!!!");
				}
				opt=Meniu();
			}
			System.out.println("Program terminat");
		}	
	}



