public class Exceptie1 {

	public static void main(String[] args) throws Exc {
		RationalIred r = new RationalIred(0,1);
		System.out.println(r.toString());
		
	}

}