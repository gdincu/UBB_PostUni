public class Rational{			//clasa Rational
    private long m,n;
    
    public Rational(){			//constr. implicit
      this(0,1);
    }
    public Rational(long m,long n){	//constr. de initializare
      setM(m);
      setN(n);
    }
    public Rational(long m){		//constr. din intreg
       this(m,1);
     }
    
    public void setM(long m){		//accesori
       this.m=m;
     }
    public long getM(){
       return m;
     }
    public void setN(long n){
       this.n=n;
     }
    public long getN(){
      return n;
    }

   public Rational produs(Rational r){	//this*r
      return new Rational(m*r.m,n*r.n);
     }
   public String toString(){		//return sir construit
       return m+"/"+n;
    }
 }
