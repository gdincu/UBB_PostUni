public class RationalIred extends Rational { //clasa mostenita din Rational
   
   public RationalIred(){		//constr. implicit, apel c. implicit din
           super();			//clasa Rational
    }
   public RationalIred(long m,long n) throws Exc{  //Metoda arunca except la clasa Exc
           setM(m);
           try{
              setIn(n);
            }
           catch(Exc  e) {throw  e;}
    }
   public void setIn(long n) throws Exc{
        if (n!=0)
            super.setN(n);
        else
           throw new Exc();
     }

   private void simplifica(){
       long x=getM(), y=getM();
       while(x!=y){
     	  if(x>y) x-=y;
         else    y-=x;
        }
       setM(getM()/x);
       setN(getN()/x);
     }
   public RationalIred produs(RationalIred r){
   	RationalIred p=new RationalIred();
	p.setM(getM()*r.getM());
	p.setN(getN()*r.getN()); 
    p.simplifica();
    return p;
 }
}

