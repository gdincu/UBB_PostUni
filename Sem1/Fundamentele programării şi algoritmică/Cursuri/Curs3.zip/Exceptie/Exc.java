public class Exc extends Exception{	//clasa Exc creata de utilizator
    public Exc(){
      super();
      System.out.println("Numitor 0");
      }
}