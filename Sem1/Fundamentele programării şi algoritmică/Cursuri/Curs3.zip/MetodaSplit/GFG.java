public class GFG { 
    public static void main(String args[]) 
    { 
        String str = "geekss@for@geekss"; 
        String[] arrOfStr = str.split("s", 0);
        System.out.println(arrOfStr.length); 
  
        for (String a : arrOfStr) 
            System.out.println(a); 
    } 
} 
