public class RegExSplit { 
    public static void main(String args[]) 
    { 
        String str = "word1,, word2 word3@word4?word5.word6"; 
        String[] arrOfStr = str.split("[, ?.@]+"); 
        System.out.println(arrOfStr.length);
        for (String a : arrOfStr) 
            System.out.println(a); 
    } 
} 
