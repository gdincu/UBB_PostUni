public class SplitNumere { 
    public static void main(String args[]) 
    { 
        String str = "123,12,-12,13"; 
        String[] arrOfStr = str.split(","); 
        System.out.println(arrOfStr.length);
        for (String a : arrOfStr) 
            System.out.println(a); 
        int v[]=new int[100];
        for(int i=0;i<arrOfStr.length;i++)
            v[i]=Integer.parseInt(arrOfStr[i]);
        for(int i=0;i<arrOfStr.length;i++)
           System.out.println(v[i]+" ");
        
    } 
} 
