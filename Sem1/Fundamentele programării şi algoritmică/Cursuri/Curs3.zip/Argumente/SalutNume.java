public class SalutNume
{public static void main(String a[]) 
  { for (int i=0; i<a.length; i++) 
     System.out.println("Salut "+ a[i]);
  
  } // Salutmain
}   // Salutnume