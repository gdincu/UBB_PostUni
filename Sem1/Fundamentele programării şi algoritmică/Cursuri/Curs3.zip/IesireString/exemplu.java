import java.io.*;
class Demo
{
 public String toString()
  { return "eu sunt 'Demo'.";
  }
}

public class exemplu
{ public static void main (String args[])
  { PrintWriter pw = new PrintWriter(System.out,true);
    pw.println("acesta este un string");
    int i=-10;
    pw.println(i);
    pw.println(new Demo());
   }
}