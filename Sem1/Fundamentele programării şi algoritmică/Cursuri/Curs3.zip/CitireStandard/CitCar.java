import java.io.*;
class CitCar
{ public static void main (String arg[]) throws IOException
    { char c;
      BufferedReader br = new BufferedReader(new InputStreamReader(System.in));

      System.out.println("Introduceti caracterul,'z'pt terminare");
      do {
          c= (char) br.read();
          System.out.print(c);
         }
      while (c != 'z');
      System.out.println("\nProgram terminat");
    }
}