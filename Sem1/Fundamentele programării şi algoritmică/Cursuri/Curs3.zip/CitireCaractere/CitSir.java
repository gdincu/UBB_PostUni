import java.io.*;
class CitSir{ 
   public static String citString() throws IOException{
      char c;
      String  s = new String();
      do {
          c= (char) System.in.read();
          s = s + c;
      }
      while (c != '\n');

      //return s.substring(0, s.length()-1);
      return s;
    }

   public static void main (String arg[]) throws IOException{ 
      System.out.print  ("Introduceti un sir:");
      System.out.println("Sirul introdus este:"+citString());
   }
}