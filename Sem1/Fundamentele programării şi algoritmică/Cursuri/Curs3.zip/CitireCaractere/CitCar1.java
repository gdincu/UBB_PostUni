class CitCar1 {
 public static void main(String args[]) {
   StringBuffer s=new StringBuffer();
   char c;
   try {
      while( (c=(char)System.in.read()) != '\n')
      s.append(c);
     }
    catch(Exception e) {
    System.out.println("Error:"+e.getMessage());
   }
  System.out.println("Sirul este:"+s);
 }
}