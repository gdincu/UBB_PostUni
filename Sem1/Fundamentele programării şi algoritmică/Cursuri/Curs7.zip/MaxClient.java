import java.net.*;
import java.io.*;
public class MaxClient	// clasa principla a aplicatiei
 { 								// trimite date catre server
   public static void trimiteDateCatreServer (DataOutputStream out, String sir) throws IOException
	{ out.writeUTF(sir);					// trimite la server stringul sir
       	  out.flush();						// goleste fluxul
	  System.out.println("Am trimis la server:"+sir);
        }
   public static String primesteDateDeLaServer (DataInputStream in) throws IOException
        { String sir=in.readUTF();			     // obtine raspunsul de la server
 	  System.out.println("Am primit de la server:"+sir); // afis. mesaj la consola
	  return sir;
        }
   public static void main (String []args)
	{ DataInputStream   in = null;		     // declararea variabilelor
	  DataOutputStream out = null;
	  Socket   	      s= null;
	  try { s = new Socket("127.0.0.1",2016); // stab. unei conex cu serverul local la port 2016
	        System.out.println("ne-am conectat la server"); // afis. mesaj de succes       
		in = new DataInputStream
                   (new BufferedInputStream(s.getInputStream()));  // obtinerea unui flux de intrare
		out = new DataOutputStream
                   (new BufferedOutputStream(s.getOutputStream()));// obtinerea unui flux de iesire
              }
          catch (IOException e)
 	      { System.err.println("eroare la conectare:"+e);	// tratare exceptie
                System.exit(1);
	      }	
	  double nr1=0.0, nr2=0.0;				// declararea altor variabile 
	  BufferedReader tastatura;
	  String linie;
	  try { tastatura = new BufferedReader(new InputStreamReader(System.in));
		System.out.flush();
		System.out.print("dati primul numar:");
		linie=tastatura.readLine();
	        Double tmp = Double.valueOf(linie); 
		nr1 = tmp.doubleValue();
		System.out.flush();                
		System.out.print("dati celalalt numar:");
		linie=tastatura.readLine();
	        tmp = Double.valueOf(linie); 
		nr2 = tmp.doubleValue();
                tastatura.close(); 		// inchiderea intrarii standard
 	      }
          catch (IOException e)
 	      { System.err.println("citire gresita de la tastatura:"+e);// tratare exceptie
	      }	
          String rezultat="";
	  try { trimiteDateCatreServer(out,Double.toString(nr1));   // comunicare cu serverul
		trimiteDateCatreServer(out,Double.toString(nr2));
		rezultat = primesteDateDeLaServer(in);
 	      }
          catch (IOException e)
 	      { System.err.println("eroare la trimitere/primire date:"+e);// tratare exceptie
	      }	
          System.out.println("maximul="+rezultat);  
	}// main
 }// MaxClient
