import java.net.*;
import java.io.*;
public class MaxServer	// clasa principla a aplicatiei
 { 			// trimite date la client
   public static void trimiteDateLaClient (DataOutputStream out, String sir) throws IOException
	{ out.writeUTF(sir);	// trimite la client stringul sir
       	  out.flush();		// goleste fluxul
	  System.out.println("Am trimis la client:"+sir);
        }
   public static String primesteDateDeLaClient (DataInputStream in) throws IOException
        { String sir=in.readUTF();				// obtine raspunsul de la client
 	  System.out.println("Am primit de la client:"+sir);	// afis. mesaj de la consola
	  return sir;
        }
   public static void main (String []args)
	{ DataInputStream   in = null;			  // declararea variabilelor
	  DataOutputStream out = null;
	  ServerSocket   server= null;
	  Socket   	      s= null;
	  try { server = new ServerSocket(2016);	  // creare socket pentru server la port 2016
	        System.out.println("Asteptam un client"); // afis. mesaj de la consola       
	        s = server.accept();			  // acceptarea unei conexiuni cu un client
	        System.out.println("S-a stabilit conexiunea cu clientul");
		in = new DataInputStream
                   (new BufferedInputStream(s.getInputStream()));  // obtinerea unui flux de intrare
		out = new DataOutputStream
                   (new BufferedOutputStream(s.getOutputStream()));// obtinerea unui flux de iesire
              }
          catch (IOException e)
 	      { System.err.println("eroare la conectare:"+e);	// tratare exceptie
	      }	
	  String sirNumere="";				 // declararea altor variabile 
          double nr1=0.0, nr2=0.0;
	  double max=0.0;
	  try { sirNumere = primesteDateDeLaClient(in);  // primirea unui numar
	        Double tmp = Double.valueOf(sirNumere); 
		nr1 = tmp.doubleValue();
                sirNumere = primesteDateDeLaClient(in);  // primirea celuilalt numar
	        tmp = Double.valueOf(sirNumere); 
		nr2 = tmp.doubleValue();
                max = (nr1>nr2)?nr1:nr2;		// determina maxim
	        trimiteDateLaClient(out, Double.toString(max));// trimite rezultat
 	      }
          catch (IOException e)
 	      { System.err.println("eroare la trimitere/primiredate:"+e);// tratare exceptie
	      }	
	            
	}// main
 }// MaxServer
