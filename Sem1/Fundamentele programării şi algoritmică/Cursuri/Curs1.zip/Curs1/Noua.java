class Noua {
  static void test(Integer i){
    i=10;
  }

  public static void main(String[] args) {
    Integer i=0;
    test(i);
    System.out.println(i);
  }
}
