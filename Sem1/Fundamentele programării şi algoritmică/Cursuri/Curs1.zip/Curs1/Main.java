class Numar{
  int i;
}

public class Main {
   public static void test(Numar nr){
   	nr.i=10;
   }

   public static void main(String[] args){
         Numar nr = new Numar();
         nr.i=0;
         test(nr);
         System.out.println(nr.i); //nr.i=10;
   }
}
