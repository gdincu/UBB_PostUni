import java.awt.*;
import javax.swing.*;

import java.lang.*;

class Oglinda  extends JFrame 
            implements java.awt.event.ActionListener
{ JTextField nr;
  JTextField rez;
  
  public Oglinda ()
     {super("Oglinda unui numar");
      JPanel p=new JPanel();
      p.setLayout(new GridLayout(10,1));
      
      JPanel p1=new JPanel();
      
      JLabel n =new JLabel("Dati numarul:");
      nr=new JTextField(15);
      JLabel n1=new JLabel("Eticheta Alexandra");
      
      p1.add(n);
      p1.add(nr);
      p1.add(n1);
      p.add(p1);
      
      JPanel p2=new JPanel();
      JButton but=new JButton("Oglinda nr");
      but.addActionListener(this);
      p2.add(but);
      p.add(p2);
      
      JPanel p3=new JPanel();
      JLabel et=new JLabel("Numarul Oglindit este:");
      String zero=new String("0");

      rez=new JTextField(zero,15);
      rez.setEditable(false);

      p3.add(et);
      p3.add(rez);
      p.add(p3);
      getContentPane().add(p);
     }
     
   public void actionPerformed(java.awt.event.ActionEvent e)
	{if(e.getActionCommand()=="Oglinda nr")
		{try {long i=Long.parseLong(nr.getText());
		            long inv=0;
		            long r;
		            while (i>0)  
		                { r=i%10;
		                  inv=inv*10+r;
		                  i=i/10;
		                 } 
		           rez.setText(""+inv);
		        }
		catch(NumberFormatException a)
		{JOptionPane.showMessageDialog(nr,"Numar incorect","EROARE",JOptionPane.ERROR_MESSAGE);}
		}
	}
} 