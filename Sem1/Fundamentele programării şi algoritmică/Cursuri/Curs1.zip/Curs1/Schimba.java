public class Schimba{
  public static

}