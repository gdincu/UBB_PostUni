/**
 * @author Vasile Cioban
 */
public class Numar {
	private long Val;			//valoarea numarului 
	public  Numar(){			//constructor implicit
		Val=0;
	}
	public Numar(long Val){			//constructor cu parametru
		this.Val=Val;			//de initializare
	}
	public Numar(Numar n){			//constructor de copiere
		if(this!=n) Val=n.Val;		//de obicei nu se face in Java
	}					//exista clonare sau "="
	public long getVal() {
		return Val;
	}
	public void setVal(long val) {
		Val = val;
	}
	public boolean Prim(){				//determina primalitatea numarului Val
		if(Val<2)	       return false;	//return true daca Val e prim, altfel return false
		if(Val!=2 && Val%2==0) return false;	//daca Val e diferit de 2 dar e multiplu de 2 nu e prim
							//dupa if, Val e in multimea {2,3,5,7,...}
		for(long d=3;d*d<=Val;d+=2){		//pentru Val=2 nu intra in ciclare => 2 e prim
                   if(Val%d==0)	       return false;	//Val e divizibil cu d, nu e prim
		}
		return true;				//Val nu e divizil cu nici o valoare din multimea de mai sus	
	}						//=> Val e prim
}
