public class Divizori
{    public static void main(String[] args) {
  	   final int numar = 120;		//divizorii lui 120
	   int[] div = new int[100];		//un vector pentru divizori
	   int n = 0;			//contor pentru divizori
	   int d = 1;			//d parcurge {1,2,...rad(n)}
	   while(d*d<numar) {
	           if(numar%d == 0) { 
 		div[n++] = d;
 		div[n++] = numar/d;
	          }
	          d++;
	   }
         if(d*d==numar)   div[n++]=d;	//daca numar e patrat perfect
	   d = 0; 			//afisare divizori
	   while(d<n) {
	       System.out.print(div[d]+" ");
	       d++;
	   }
       }
}
