/**
 * @author Vasile Cioban
 */
import java.util.Scanner;
public class GoldBach {

	public static long CitLong(String sir){
		try{
			System.out.print(sir);
			Scanner S= new Scanner(System.in);
			long l=S.nextLong();
			return l;			
		}
		catch(Exception E){
			System.out.println("Ai gresit, mai incearca");
			return CitLong(sir);
		}
		
	}
	public static long AfisMeniu(){
		System.out.println();
		System.out.println("1.Introducere numar");
		System.out.println("2.Descomp in suma prime");
		System.out.println("0.Terminare program");
		long l=CitLong("Optinuea ta:");
		return l;
		
	}
	public static void main(String[] args) {
	    int Opt=(int)AfisMeniu();
	    Numar n=new Numar();
	    while(Opt!=0){
	    	switch(Opt){
	    		case 1: long L=CitLong("da un numar par:");
	    			    while(L%2!=0) L=CitLong("da un numar par:");
	    			    n.setVal(L);
	    			break;
	    		case 2: //trebuie rezolvata problema
	    			for(long i=3;i<n.getVal()/2;i++){
	    				Numar I=new Numar(i);
	    				Numar N_I=new Numar(n.getVal()-i);
	    				if(I.Prim() && N_I.Prim()) System.out.println(i+"+"+(n.getVal()-i));
	    			}
	    				
	    			break;
	    		default:System.out.println("Optiune inexistenta");
	    	}
	    	Opt=(int)AfisMeniu();
	    }
	    System.out.println("Program terminat");
	    

	}

}
