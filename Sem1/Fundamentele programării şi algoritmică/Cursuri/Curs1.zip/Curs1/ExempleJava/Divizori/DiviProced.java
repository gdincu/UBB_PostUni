public class DiviProced
{    public static void main(String[] args) {
  	   final int NUMAR = 120;		//divizorii lui 120, alocata in zona de program
	   int[] div = new int[100];		//un vector pentru divizori, alocat in Heap
	   int n = 0;				//contor pentru divizori, n alocat in zona de program
	   int d = 1;				//d parcurge {1,2,...rad(n)}, d aocat in zona de program
	   while(d*d<NUMAR) {
	      if(NUMAR%d == 0) { 
 		div[n++] = d;
 		div[n++] = NUMAR/d;
	      }
	      d++;
	   }
           if(d*d==NUMAR)   div[n++]=d;	//daca numar e patrat perfect
	     d = 0; 			//afisare divizori
	     while(d<n) {
	       System.out.print(div[d]+" ");
	       d++;
	     }
        				//NUMAR=0;  da eroare de compilare
        System.out.println("\n"+NUMAR);
       }
}
