
public class MinimVector{
  public static void main(String args[]){
    int a[]={2,1,-4,7,3};
    int min=a[0];
    for(int i=0; i<a.length; i++)
       if (a[i]<min) min=a[i];
    System.out.println("Minimul este ="+min);  	
  }
}
