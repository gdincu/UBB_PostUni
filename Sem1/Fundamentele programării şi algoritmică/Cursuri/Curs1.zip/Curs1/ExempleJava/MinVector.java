
import java.util.Scanner;
public class MinVector {
   public static long CitLong(String sir){
	try{
		System.out.print(sir);
		Scanner s= new Scanner(System.in);
		long    L=s.nextLong();
		return  L;			
	}
	catch(Exception e){
		System.out.println("Ai gresit, mai incearca");
		return CitLong(sir);
	}
		
   }
   
   public static long AfisMeniu(){
	System.out.println();
	System.out.println("1.Introducere elemente vector");
	System.out.println("2.Determinare minim");
	System.out.println("0.Terminare program");
	long   L=CitLong("Optinuea ta:");
	return L;
   }

   public static void main(String[] args) {
        int Opt=(int)AfisMeniu();
        int x[]=new int[10];
        int lung=0;
        int min;
	while(Opt!=0){
      	  switch(Opt){
	    case 1: lung=(int)CitLong("da lungime vector:");
	    	    for(int i=0;i<lung;i++){
                      System.out.print("a["+i+"]=");
		      x[i]=(int)CitLong("");
		    }
		    break;
	    case 2: 				//trebuie rezolvata problema
	    	    min=x[0];
		    for (int i=0;i<lung;i++)
			 if(x[i]<min) min=x[i];
	    	    System.out.println ("Minim="+min);		
	    	    break;
          }
          Opt=(int)AfisMeniu();
	}
	System.out.println("Program terminat");
  }
}
