
interface Cititor{ 
	public void citeste(); 
} 
interface Scriitor{ 
	public void scrie(); 
} 
interface Ganditor{ 
	public void gandeste(); 
} 
interface Profesor extends Cititor, Scriitor{ 
	int NOTA_MAX=10; 
	int NOTA_MIN=1; 
	public void daNota(); 
} 

interface Diver { 
	int h=10; 
	public void dive(); 
} 

class Inotator implements Diver{ 
	static final int L=50; 
	public void dive(){ 
		System.out.println(" - se scufunda " + h +" metri"); 
    } 
	public void inoata(){ 
		System.out.println(" - inoata " + L +" metri"); 
	} 
}
class ProfesorInot extends Inotator 
  				implements Profesor, Ganditor{ 
	public void citeste(){ 
		System.out.println(" - citeste \"Gazeta Sporturilor\".."); 
	} 
	public void scrie(){ 
		System.out.println(" - scrie articole sportive pe teme de inot"); 
	} 
	public void daNota(){ 
		System.out.println(" - esti pregatit ai nota "+NOTA_MAX); 
	} 
	public void gandeste(){ 
		System.out.println(" - te pot invata sa inoti mai bine"); 
	} 
} 


class Programator implements Cititor, Scriitor, Ganditor{ 
	public void citeste(){ 
		System.out.println(" - citesc tutorial Java"); 
	} 
	public void scrie(){ 
		System.out.println(" - proiectez si scriu soft OOP"); 
	} 
	public void gandeste(){ 
		System.out.println(" - Java este un limbaj super.."); 
	} 
}
public class TestInterfete { 
	public static void ceCitesc(Cititor c){ 
		c.citeste(); 
	} 
	public static void ceScriu(Scriitor s){ 
		s.scrie(); 
	} 
	public static void ceGandesc(Ganditor g){ 
		g.gandeste(); 
	} 
	public static void apreciaza(ProfesorInot pi){
		pi.daNota();
	}
	public static void ceFaceInotator(Inotator i){
		i.inoata();
		i.dive();
	}
	
	public static void main(String arg[]){ 
		ProfesorInot prof=new ProfesorInot(); 
		Programator  prog=new Programator(); 
		Inotator     inot=new Inotator();
		
		System.out.println("Ce face un prof de inot:");
		ceCitesc (prof); 
		ceScriu  (prof); 
		ceGandesc(prof);
		apreciaza(prof);
		
		System.out.println("\nCe face un programator:");
		ceCitesc (prog); 
		ceScriu  (prog); 
		ceGandesc(prog); 
		
		System.out.println("\nCe face un inotator:");
		ceFaceInotator(inot);
	} 
} 

