
class MyThread extends Thread{ 
	public void run(){ 
		int nrPasi=5; 
		System.out.println("run are " + nrPasi+ " de realizat"); 
		for(int i=1;i<=nrPasi;i++) 
			System.out.println("Pasul:"+i); 
		System.out.println("run si-a terminat sarcina"); 
	} 
} 

public class FirstThread{ 
	public static void main(String args[]){ 
		System.out.println("Crearea thread"); 
		MyThread thread = new MyThread(); 
		System.out.println("Start thread"); 
		thread.start(); 
		System.out.println("Revenire in main"); 
	} 
} 

