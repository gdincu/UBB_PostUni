class Afis{ 
	public void afis(String mesaj){ 
		System.out.println(mesaj); 
	} 
} 

class MyRunnable extends Afis implements Runnable{ 
	public void run(){ 
		int nrPasi=3; 
		afis("run are " + nrPasi+" de realizat"); 
		for(int i=1;i<=nrPasi;i++) 
			System.out.println("Pasul:"+i); 
		System.out.println("run si-a terminat sarcina"); 
	} 
} 

public class FirstRunnable{ 
	public static void main(String args[]){ 
		System.out.println("Creare obiect runnable"); 
		MyRunnable myRunnable = new MyRunnable(); 
		System.out.println("Creare thread"); 
		Thread thread = new Thread(myRunnable); 
		System.out.println("Start thread"); 
		thread.start(); 
		System.out.println("revenire in main"); 
	} 
} 


