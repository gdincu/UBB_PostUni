
	import java.awt.*;
	import java.awt.event.*;
	import java.awt.datatransfer.*;
	import java.text.DecimalFormat;
	import javax.swing.JOptionPane;

	public class Calculator extends Frame implements ActionListener
	{ private Button keys[];
	  private Panel keypad;
	  private TextField lcd;
	  private double op1;
	  private boolean first;
	  private boolean foundKey;
	  private boolean clearText;
	  private int lastOp;
	  private DecimalFormat calcPattern;
	  public Calculator()
	  {									//creaza un obiect de tip menuBar
		MenuBar meniuBar =new MenuBar();	
	    setMenuBar(meniuBar);
	    								//creaza si populeaza un meniu de tip File
	    Menu meniuFile = new Menu("File",true); 
	    meniuBar.add(meniuFile);
	    MenuItem meniuFileExit = new MenuItem("Exit");
	    meniuFile.add(meniuFileExit);
	    								//creaza si populeaza meniu de editare 
	    Menu meniuEdit = new Menu("Edit",true);
	    meniuBar.add(meniuEdit);
	    MenuItem meniuEditClear = new MenuItem("Clear");
	    meniuEdit.add(meniuEditClear);
	    meniuEdit.insertSeparator(2);
	    MenuItem meniuEditCopy = new MenuItem("Copy");
	    meniuEdit.add(meniuEditCopy);
	    MenuItem meniuEditPaste = new Menu("Paste");
	    meniuEdit.add(meniuEditPaste);
	    								//creaza si populeaza meniul About
	    Menu meniuAbout = new Menu("About",true);
	    meniuBar.add(meniuAbout);	
	    MenuItem meniuAboutCalculator = new MenuItem("About Calculator");
	    meniuAbout.add(meniuAboutCalculator);
	    								//adauga ActionListener la fiecare optiune din meniu
	    meniuFileExit.addActionListener(this);
	    meniuEditClear.addActionListener(this);
	    meniuEditCopy.addActionListener(this);
	    meniuEditPaste.addActionListener(this);
	    meniuAboutCalculator.addActionListener(this);
	    								//ataseaza cate o actiune la fiecare optiune
	    meniuFileExit.setActionCommand("Exit");
	    meniuEditClear.setActionCommand("Clear");
	    meniuEditCopy.setActionCommand("Copy");
	    meniuEditPaste.setActionCommand("Paste");
	    meniuAboutCalculator.setActionCommand("About");
	    							//initializarea componentelor constructorului
	    lcd  =new TextField(20);
	    lcd.setEditable(false);
	    keypad=new Panel();
	    keys=new Button[16];
	    first=true;
	    op1=0.0;
	    clearText=true;
	    lastOp=0;
	    calcPattern= new DecimalFormat("########.########");
	    							//setarea butoanelor
	    for(int i=0;i<=9;i++)
	    	keys[i]=new Button(String.valueOf(i));
	    
	    keys[10]=new Button("/");
	    keys[11]=new Button("*");
	    keys[12]=new Button("-");
	    keys[13]=new Button("+");
	    keys[14]=new Button("=");
	    keys[15]=new Button(".");
	    							//setare Cadru si dimensiuni
	    setLayout(new BorderLayout());
	    keypad.setLayout(new GridLayout(4,4,10,10));
	    
	    for(int i=7;i<=10;i++) //7,8,9,10 pentru divide
	    	keypad.add(keys[i]);
	    
	    for(int i=4;i<=6;i++) //4,5,6
	    	keypad.add(keys[i]);
	    keypad.add(keys[11]);	//multiply
	    
	    for(int i=1;i<=3;i++)   //1, 2 3
	    	keypad.add(keys[i]);
	    keypad.add(keys[12]);	//subtract
	    keypad.add(keys[0]);	//0 key
	    for(int i=15;i>=13;i--)  
	       keypad.add(keys[i]); //decimal point,=,add(+) keys
	    
	    for(int i=0; i<keys.length;i++)
	    	keys[i].addActionListener(this);
	    add(lcd,BorderLayout.NORTH);
	    add(keypad,BorderLayout.CENTER);
	    
	    addWindowListener(
	    	new WindowAdapter()
	    	{ public void windowClosing(WindowEvent e)
	    	{
	    		System.exit(0);
	    	}
	    		
	    	}
	    );

   }//end constructor
   
   public void actionPerformed(ActionEvent e){
	   						//test pentru optiuni (clic)
	  String arg =e.getActionCommand();
	  if(arg=="Exit") System.exit(0);
	  if(arg=="Clear"){
		  clearText = true;
		  first = true;
		  op1 =0.0;
		  lcd.setText("");
		  lcd.requestFocus();
	  }
	  if(arg=="Copy"){
		  Clipboard cb = Toolkit.getDefaultToolkit().getSystemClipboard();
		  StringSelection contents=new StringSelection(lcd.getText());
		  cb.setContents(contents, null);
	  }
	  if(arg=="Paste"){
		  Clipboard cb = Toolkit.getDefaultToolkit().getSystemClipboard();
		  Transferable content= cb.getContents(this);
		  try {
			    String s=(String)content.getTransferData(DataFlavor.stringFlavor);
			    lcd.setText(calcPattern.format(Double.parseDouble(s)));
		  }
		  catch(Throwable exc){
			  lcd.setText("");
		  }
		  
	  }
	  if(arg=="About"){
		  String mesaj =
			  "Calculator ver 1.0\nOpen source";
		  //JOptionPane.showMessageDialog(null,mesaj,"About Calculator", JOptionPane.INFORMATION_MESSAGE);
		  
	  }
	   				//test clic pe butoane
	  foundKey=false;
	  				//cautare key apasata
	  for(int i=0;i<keys.length &&!foundKey;i++)
	  { if(e.getSource()==keys[i])
	     { foundKey=true;
	       switch(i){
	          case 0: case 1: case 2:
	          case 3: case 4: case 5:
	          case 6: case 7: case 8:
	          case 9: case 15:
	              if(clearText){
	            	  lcd.setText("");
	            	  clearText=false;
	              }
	        	  lcd.setText(lcd.getText()+keys[i].getLabel());
	        	  break;
	          case 10:case 11: case 12: case 13: case 14:
	        	  clearText=true;
	        	  if(first){
	        		  if(lcd.getText().length()==0) op1=0.0;
	        		  else op1=Double.parseDouble(lcd.getText());
	        		  first=false;
	        		  clearText=true;
	        		  lastOp=i;				//salveaza ultimul operator
	        	  }
	        	  else	//al doilea operator
	        	  {
	        		  switch(lastOp){
	        			case 10: op1/=Double.parseDouble(lcd.getText());
	        			         break;
	        			case 11: op1*=Double.parseDouble(lcd.getText());
   			                     break;
	        			case 12: op1-=Double.parseDouble(lcd.getText());
		                         break;
	        			case 13: op1+=Double.parseDouble(lcd.getText());
		                         break;
	        		  }
	        		  lcd.setText(calcPattern.format(op1));
	        		  clearText=true;
	        		  if(i==14) first=true;//butonul =
	        		  else      lastOp=i;   //salvare ultimul operator
	        	     }//end else
	        	     break;
	             } //end switch
	     }//end if
	  }//end for
	}//end actionPerformed	
   
   public static void main(String args[]){
	   					//set proprietati
	   Calculator f=new Calculator();
	   f.setTitle("Calculator Windows");
	   f.setBounds(100,100,500,500);
	   f.setVisible(true);
	   				//setare prop. imagine si adauga la cadru
	   Image icon = Toolkit.getDefaultToolkit().getImage("calcImage.gif");
	   f.setIconImage(icon);
   }
}
	
