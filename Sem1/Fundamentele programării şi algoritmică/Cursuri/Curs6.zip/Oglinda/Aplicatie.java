import javax.swing.*;
import java.*;
import java.awt.event.*;
import java.lang.*;

public class Aplicatie
  { public static void main(String args[])
     {Oglinda og=new Oglinda();
      og.addWindowListener(
	new WindowAdapter()
          {public void windowClosing(WindowEvent a)
               {System.exit(0);}
           }
        );
       og.pack();
       og.setVisible(true);
     }
   }   