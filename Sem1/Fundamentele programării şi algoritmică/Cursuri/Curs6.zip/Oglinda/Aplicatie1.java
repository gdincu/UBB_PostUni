import javax.swing.*;
import java.*;
import java.awt.event.*;
import java.lang.*;

public class Aplicatie1 extends WindowAdapter
{    public void windowClosing(WindowEvent a){
       System.exit(0);
     }
     
  public static void main(String args[])
     {Oglinda og=new Oglinda();
      og.addWindowListener(new WindowAdapter());
      og.pack();
      og.setVisible(true);
     }
}   