import java.awt.*;
import javax.swing.*;

import java.lang.*;

class Oglinda  extends JFrame 
            implements java.awt.event.ActionListener
{ JTextField nr;
  JTextField rez;
  
  public Oglinda ()
     {super("Oglinda unui numar");
      JPanel p=new JPanel();		//declararea panoului general p
      p.setLayout(new GridLayout(10,1));//setarea dimensiunilor lui p
      				//pe panoul p se vor "pune" 3 subpanouri
				//p1,p2 si p3, toate sunt de tipul JPanel

				//in p1 se pun: o ticheta si o caseta de text
      JPanel p1=new JPanel();	//declaratiile si instantieri pentru p1, etic1 si nr	
      JLabel etic1 =new JLabel("Dati numarul:");
      nr=new JTextField(15);
      p1.add(etic1);		//adaugarea etichetei etic1 la p1
      p1.add(nr);		//adaugarea casetei de text la p1
      p.add(p1);		//adaugarea panoului p1 la panoul general p
      				
				//in p2 se pune un buton;
      JPanel p2=new JPanel();	//declaratiile si instantieri pentru p2 si but
      JButton but=new JButton("Oglinda nr");
      but.addActionListener(this);//butonului but i se asociaza un eveniment 
				  //parametru este un obiect de tip oglinda, practic panoul p
      p2.add(but);		//adaugarea butonului but la p2
      p.add(p2);		//adaugarea panoului p2 la panoul general p
      
      				//in p3 se pun: o eticheta si o caseta de text
      JPanel p3=new JPanel();	//declaratiile si instantieri pentru p3, etic2 si rez(rezultatul)
      JLabel etic2=new JLabel("Numarul Oglindit este:");
      String zero=new String("0");
      rez=new JTextField(zero,15);//initial se seteaza cazeta pe '0'
      rez.setEditable(false);	  //proprietatea de editare a casetei se inhiba

      p3.add(etic2);		//adaugarea etichetei, etic2 la p3
      p3.add(rez);		//adaugarea casetei de text, rez la p3
      p.add(p3);		//adaugarea panoului p3 la panoul general p
      getContentPane().add(p);	//adaugarea panoului general la un container general 
     }
     
   public void actionPerformed(java.awt.event.ActionEvent e)
	{if(e.getActionCommand()=="Oglinda nr")
		{try {long i=Long.parseLong(nr.getText());
		            long inv=0;
		            long r;
		            while (i>0)  
		                { r=i%10;
		                  inv=inv*10+r;
		                  i=i/10;
		                 } 
		            rez.setText(""+inv);
		        }
		catch(NumberFormatException a)
		{JOptionPane.showMessageDialog(nr,"Numar incorect","EROARE",JOptionPane.ERROR_MESSAGE);}
		}
	}
} 