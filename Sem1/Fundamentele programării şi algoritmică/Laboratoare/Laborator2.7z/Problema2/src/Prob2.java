import java.util.Scanner;

public class Prob2 {
	public static int CitIntreg(String sir){
		System.out.print(sir);
		Scanner s=new Scanner(System.in);
		int I=s.nextInt();
		return I;
	}

	
	
	
	public static void main(String[] args) {
	  int n;		// i,j,k naturale si 3<=i<j<k<=n, (3,4,5()
	  n=CitIntreg("da un natural:");
	  int i;
	  int j;
	  int k;
	  for(i=3;i<=n-2;i++)
		  for(j=i+1;j<=n-1;j++)
			  for(k=j+1;k<=n;k++)
				  if(i*i+j*j==k*k)
					  System.out.println(i+","+j+","+k);
	}

}
