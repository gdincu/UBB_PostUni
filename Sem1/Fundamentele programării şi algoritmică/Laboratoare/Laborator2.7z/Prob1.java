import java.util.Scanner;

public class Prob1 {
	public static long CitLong(String sir){
		System.out.print(sir);
		Scanner scanner=new Scanner(System.in);
		return scanner.nextLong();
	}
	
	public static void main(String[] a) {
	  long k;				//numarul dupa care se det. restul
	  int  n;				//declaratii ale lui n si ale lui f
	  long [] f;			
	  n=(int)CitLong("da lungimea vector f:"); 	//apel met. citire pentru n
	  f=new long[n];							//instantierea(alocare de mem.) in Heap
	  for(int i=0;i<n;i++){						//citirea elemntelor vect.
		  f[i]=CitLong("f["+i+"]=");
	  }
	  k=CitLong("da k=");						//citire k
	  long R=1;
	  for(int i=0;i<n;i++)						//determinare rest
		  R=(R*(f[i]%k))%k;
	  System.out.println("Restul impartirii la "+k+"="+R);
	}
}
