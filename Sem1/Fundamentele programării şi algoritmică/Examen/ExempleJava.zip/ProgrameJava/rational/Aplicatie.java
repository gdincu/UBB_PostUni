class Rational
{ private int a;//Specificatie: Rational=a/b ireductibile, a,b intregi
  private int b;

 public Rational(int x,int y)	//constructor din 2 numere intregi
 {a=x;
  b=y;
  Simplifica();
 }

 public Rational(Rational x)	//constructor de copiere din alt rational
 {a=x.a;
  b=x.b;
 }

 public Rational(int x)		//constructor de numar ratinal din intreg
 {a=x;
  b=1;
 }

 public static int Cmmdc(int x,int y)
 {if(x==y) return x;
	else if (x>y) return Cmmdc(x-y,y);
		else  return Cmmdc(x,y-x);

 }

 private void Simplifica()
 {int x=Math.abs(a),y=Math.abs(b);
  int temp=Cmmdc(x,y);		//sau temp=Cmmdc(Math.abs(a),Math.abs(b))
  a/=temp;			//a=a/temp;
  b/=temp;
 }

 public void Aduna(Rational x)	// la implicit se aduna x  
 {int auxa=a*x.b+b*x.a;
  int auxb=b*x.b;
  a=auxa; b=auxb;
  Simplifica();
 }
 
 public void Scade(Rational x)	// la implicit se scade x
 {int auxa=a*x.b-b*x.a;
  int auxb=b*x.b;
  a=auxa; b=auxb;
  Simplifica();
 }

 public void Inmulteste(Rational x)	// la implicit se inmulteste x
 {a*=x.a;
  b*=x.b;
  Simplifica();
 }

 public Rational Invers()		// inversul unui rational
 {Rational aux=new Rational(b,a);
  return aux;
 }

 public void Imparte(Rational x)	// implicitul se imparte cu x
 {Inmulteste(x.Invers());
 }

//exemplu de operatie care apartine clasei...
 public static Rational suma(Rational x,Rational y)
 {Rational z=new Rational(x);
  z.Aduna(y);
  return z;
 }

 public boolean esteZero()
  { if (a==0) return true;
              return false;
  } 


public void Afiseaza()
 { if (b==1)
      System.out.print(a);
   else 
      System.out.print(a+"/"+b);	// se afiseaza a/b
 }
}

class Aplicatie
 { public static void main(String aa[])
   {Rational a=new Rational(1,2);
    Rational b=new Rational(1,3);
    Rational c=new Rational(1,4);
    Rational d=new Rational(1,5);
    Rational e=new Rational(1,6);
    Rational f=new Rational(1,7);

    System.out.println("sistemul de 2 ecuatii cu 2 nec=");
    a.Afiseaza();System.out.print("X+");b.Afiseaza();System.out.print("Y=");c.Afiseaza();System.out.println();
    d.Afiseaza();System.out.print("X+");e.Afiseaza();System.out.print("Y=");f.Afiseaza();System.out.println();
    Rational delta=new Rational(a);	//delta=a*e-b*d
    delta.Inmulteste(e);
    Rational temp =new Rational(b);
    temp.Inmulteste(d);
    delta.Scade(temp);			
    System.out.print("delta=");delta.Afiseaza();System.out.println();


    Rational delta1=new Rational(c);	//delta1=c*e-b*f
    delta1.Inmulteste(e);
    Rational temp1 =new Rational(b);
    temp1.Inmulteste(f);
    delta1.Scade(temp1);
    System.out.print("delta1=");delta1.Afiseaza(); System.out.println();
    
    Rational delta2=new Rational(a);	//delta2=a*f-c*d
    delta2.Inmulteste(f);
    Rational temp2 =new Rational(c);
    temp2.Inmulteste(d);
    delta2.Scade(temp2);
    System.out.print("delta2=");delta2.Afiseaza(); System.out.println();

    if (!delta.esteZero())
       { Rational x= new Rational(delta1);
         x.Imparte(delta);
         Rational y= new Rational(delta2);
         y.Imparte(delta);
         System.out.print("x=");x.Afiseaza();System.out.println();
         System.out.print("y=");y.Afiseaza();System.out.println();
        }
    else if (delta1.esteZero() && delta2.esteZero())
              System.out.println("sistem nedeterminat");
         else System.out.println("sistem incompatibil");  
         
 }
}