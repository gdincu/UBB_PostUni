public class RATIONAL
 { private long p; 		// numaratoru' p
   private long q;		// numitoru'   q

   public  RATIONAL (long p, long q) // constructor
	 { this.p=p;
	   this.q=q;
	   Simplifica();
	 }
   public RATIONAL(RATIONAL r)	//constructor de copiere din alt rational
   {p=r.p;
    q=r.q;
   }
   public RATIONAL(int I)		//constructor de numar ratinal din intreg
   {p=I;
    q=1;
   }
   public void setP(long p)   	// setare numarator
	 {this.p=p;
	  Simplifica();
     }
   public void setQ(long q)		// setare numitor
	 {this.q=q;
	  Simplifica();
     }
   public long  getP()       	// returnari p si q
	 {return p ;
     }
   public long   getQ()
	 {return q ;
     }
   public void Afisare()
	 {if (q==1)
          System.out.print(p);
      else 
          System.out.print(p+"/"+q);
     }
   private static long CMMDC(long x,long y)
     {while (x!=y)
       if (x>y) x=x-y;
	   else     y=y-x;
      return x;
     }
   private void Simplifica()
     {long divizor= CMMDC(Math.abs(p),Math.abs(q));
      p/=divizor;			// p=p/divizor;
      q/=divizor;
      if(p*q>=0)
        { p=Math.abs(p);
          q=Math.abs(q);
        }
      else 
        {p=-Math.abs(p);
         q= Math.abs(q);
        }
     }

   public void Aduna(RATIONAL r1)	//aduna la obiectul implicit r1
     { p=p*r1.q+q*r1.p;
       q=q*r1.q;
       Simplifica();  
     }
   public void Scade(RATIONAL r1)	//scade la obiectul implicit r1
   { p=p*r1.q-q*r1.p;
     q=q*r1.q;
     Simplifica();  
   }
   public void Multy(RATIONAL r1)	//inmultire la obiectul implicit r1
   { p=p*r1.p;
     q=q*r1.q;
     Simplifica();  
   }
   public void Divide(RATIONAL r1)	//impartire la obiectul implicit r1
   { p=p*r1.q;
     q=q*r1.p;
     Simplifica();  
   }
   public boolean esteZero()
   { if (p==0) return true;
               return false;
   } 
}

