public class TestRat
 {public static void main(String sir[])
   {RATIONAL a=new RATIONAL(1,2);
    RATIONAL b=new RATIONAL(1,3);
    RATIONAL c=new RATIONAL(1,4);
    RATIONAL d=new RATIONAL(2,4);
    RATIONAL e=new RATIONAL(3,9);
    RATIONAL f=new RATIONAL(10,40);
    System.out.println("sistemul de 2 ecuatii cu 2 nec=");
    a.Afisare();System.out.print("X+");b.Afisare();System.out.print("Y=");c.Afisare();System.out.println();
    d.Afisare();System.out.print("X+");e.Afisare();System.out.print("Y=");f.Afisare();System.out.println();
    RATIONAL delta=new RATIONAL(a);	//delta=a*e-b*d
    delta.Multy(e);
    RATIONAL temp =new RATIONAL(b);
    temp.Multy(d);
    delta.Scade(temp);			
    System.out.print("delta=");delta.Afisare();System.out.println();
    RATIONAL delta1=new RATIONAL(c);	//delta1=c*e-b*f
    delta1.Multy(e);
    RATIONAL temp1 =new RATIONAL(b);
    temp1.Multy(f);
    delta1.Scade(temp1);
    System.out.print("delta1=");delta1.Afisare(); System.out.println();
    RATIONAL delta2=new RATIONAL(a);	//delta2=a*f-c*d
    delta2.Multy(f);
    RATIONAL temp2 =new RATIONAL(c);
    temp2.Multy(d);
    delta2.Scade(temp2);
    System.out.print("delta2=");delta2.Afisare(); System.out.println();
    if (!delta.esteZero())
      { RATIONAL x= new RATIONAL(delta1);
        x.Divide(delta);
        RATIONAL y= new RATIONAL(delta2);
        y.Divide(delta);
        System.out.print("x=");x.Afisare();System.out.println();
        System.out.print("y=");y.Afisare();System.out.println();
       }
    else if (delta1.esteZero() && delta2.esteZero())
              System.out.println("sistem nedeterminat");
         else System.out.println("sistem incompatibil");  
    }
 }