public class Salut
{public static void main(String a[]) 
  { for (int i=1; i<=7; i++) 
     System.out.println("Salut "+ i);
  
  } // Salut.main
}   // Salut