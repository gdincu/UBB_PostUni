public class Oper{
  public static void main(String args[]){
  	int x=5, y=7;
	x++; // x primeste valoarea 6
	y--; // y primeste valoarea 6
  	System.out.println(x+" "+y);
        x=5;y=7;
	++x; // x primeste valoarea 6
	--y; // y primeste valoarea 6
        System.out.println(x+" "+y);
	x=5;y=7;
        y=x++; // y primeste valoarea 5, 
               // x primeste valoarea 6
	System.out.println(x+" "+y);
        x=5;y=0;  	
        y=x--;  // y primeste valoarea 5, 
                // x primeste valoarea 4
        System.out.println(x+" "+y);
        x=5;y=0;
	y=++x;  // x primeste valoarea 6, 
		// y primeste valoarea 6  	
        System.out.println(x+" "+y);
        x=5;y=0;
        y=--x;  // x primeste valoarea 4, 
                // y primeste valoarea 4
        System.out.println(x+" "+y);
  }
}
