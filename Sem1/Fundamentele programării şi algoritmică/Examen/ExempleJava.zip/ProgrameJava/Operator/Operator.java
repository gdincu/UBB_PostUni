public class Operator{
  public static void main(String args[]){
  	int a=2, b=3,c;
  	c=a+b;
  	System.out.println(a+" "+b+" "+c);
  	a++; --b; 
  	System.out.println(a+" "+b+" "+c);
  	c=++a+b++;
  	System.out.println(a+" "+b+" "+c);
  	a/=2;b*=2;
  	System.out.println(a+" "+b+" "+c);
  	c=a-- + --b;
  	System.out.println(a+" "+b+" "+c);
  	c=b=(a+=1);
  	System.out.println(a+" "+b+" "+c);
  }
}
