import java.io.*;
class p93
{ public static void main (String arg[]) throws IOException
    { char c;
      BufferedReader br = new BufferedReader(new InputStreamReader
                                             (System.in));
      System.out.println("Introduceti caractere,'z'pt terminare");
      do {
          c= (char) br.read();
          System.out.print(c);
         }
      while (c != 'z');

    }
}