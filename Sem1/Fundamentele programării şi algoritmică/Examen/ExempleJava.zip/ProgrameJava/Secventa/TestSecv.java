public class TestSecv
{ public static void main (String args[])
    {Secventa S1 = new Secventa(5);
    for (int i=0; i<S1.GetLung();i++)
        S1.SetPoz(i,i*i);
    Afisare(S1);
    S1.SetPoz(0,5);
    S1.SetPoz(1,4);
    S1.SetPoz(2,3);
    S1.SetPoz(3,2);
    S1.SetPoz(4,1);
    Afisare(S1);
    S1.Multime(); 
    Afisare(S1);
    S1.SortBuble();
    Afisare(S1);
   }
  public static void Afisare(Secventa S)
     {System.out.println();
      for (int i=0; i<S.GetLung();i++)
        System.out.print(S.GetPoz(i)+" ");
 
     }
}
