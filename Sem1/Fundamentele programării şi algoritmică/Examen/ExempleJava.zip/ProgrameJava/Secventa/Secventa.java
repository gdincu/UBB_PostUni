public class Secventa
 { private int lung; 			// lung este lungimea tabloului;
   private int [] s;		        // s este referinta spre spatiul elementelor
   public  Secventa(int lung) 		// constructor
	   { this.lung= lung;
	     s        = new int[lung];
	   }
   public void SetPoz(int poz, int val)  // setare elementul de pe poz cu val
	   { if ((poz>=0) && (poz<lung))
                s[poz]=val;
           }
   public int  GetPoz(int poz)       	 // returneaza elementul de pe poz
	   { if ((poz>=0) && (poz<lung))
                  return s[poz];
             else return -1;
           }
       
   public int GetLung()
           {  return lung; }
   public void Multime()
           {int k,i;
            boolean apartine;
            k=1;
            while (k<lung)
              {apartine=false;
               i=k-1;
               while (i>=0 && !apartine)
                 {if (s[k]==s[i]) apartine=true;
                  else            i=i-1;
                 }
               if (apartine) 
                 { for (i=k; i<lung-1; i++)
                     s[i]=s[i+1];
                   lung--;
                 }
               else k++; 
              }

           }
   public void SortBuble()
           {int i;
            boolean flag;
            do
              { flag = false;
                for(i=0; i<lung-1; i++)
                  if (s[i]>s[i+1])
                       { int aux=s[i];
                         s[i]   =s[i+1];
                         s[i+1] =aux;
                         flag   =true;
                       }         
              }
            while (flag);
           }
           
 }
