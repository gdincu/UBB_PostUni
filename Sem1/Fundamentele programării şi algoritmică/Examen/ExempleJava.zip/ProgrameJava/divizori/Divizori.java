public class Divizori

 {public static void main(String[] args) 
    {final int numar=120;
     
     int div[];
     div=new int[100];
     
     System.out.println("afisam divizorii lui "+numar);
     int n=0;
     int d=1;
     while (d<=numar/2)
       {if(numar%d==0) div[n++]=d;
        d++;
       }
     d=0;
     while(d<n)
       {System.out.print(div[d]+" ");
        d++;
       }
     System.out.println(numar);
    }
 }