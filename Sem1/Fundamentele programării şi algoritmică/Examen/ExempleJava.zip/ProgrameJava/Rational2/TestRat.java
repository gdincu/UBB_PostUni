
public class TestRat {
	public static void main(String[] args) {
	    RATIONAL A=new RATIONAL(1,2);
	    RATIONAL B=new RATIONAL(1,3);
	    System.out.print("A="); A.Afisare();System.out.println();
	    System.out.print("B="); B.Afisare();System.out.println();
	    RATIONAL suma=new RATIONAL (1);
	    suma.Aduna(A, B);
	    System.out.print("A+B=");suma.Afisare();System.out.println();
	    suma.Aduna(A, A);
	    System.out.print("A+A=");suma.Afisare();System.out.println();
	    suma.Scade(A,A);
	    System.out.print("A-A=");suma.Afisare();System.out.println();
	    suma.Multy(A,B);
	    System.out.print("A*B=");suma.Afisare();System.out.println();
	    suma.Divide(A,B);
	    System.out.print("A:B=");suma.Afisare();System.out.println();
	 
		
	    RATIONAL a=new RATIONAL(1,2);
	    RATIONAL b=new RATIONAL(1,3);
	    RATIONAL c=new RATIONAL(2,3);
	    RATIONAL d=new RATIONAL(1,2);
	    RATIONAL e=new RATIONAL(2,3);
	    RATIONAL f=new RATIONAL(5,6);
	    
	    
	    
	    
	    
	    System.out.println("sistemul de 2 ecuatii cu 2 nec:");
	    a.Afisare();System.out.print("X+");b.Afisare();System.out.print("Y=");c.Afisare();System.out.println();
	    d.Afisare();System.out.print("X+");e.Afisare();System.out.print("Y=");f.Afisare();System.out.println();
	    
	    RATIONAL  D=new RATIONAL(0,1);
	    RATIONAL Dx=new RATIONAL(0,1);
	    RATIONAL Dy=new RATIONAL(0,1);
	    RATIONAL r1=new RATIONAL(0,1);
	    RATIONAL r2=new RATIONAL(0,1);
	    r1.Multy(a,e);
	    //System.out.print("a*e=");r1.Afisare();System.out.println();
	    r2.Multy(b,d); 
	    //System.out.print("b*d=");r2.Afisare();System.out.println();
	    D.Scade(r1,r2);
	    System.out.print("delta=");D.Afisare();System.out.println();
	    r1.Multy(c,e);
	    //System.out.print("c*e=");r1.Afisare();System.out.println();
	    r2.Multy(b,f); 
	    //System.out.print("b*f=");r2.Afisare();System.out.println();
	    Dx.Scade(r1,r2);
	    System.out.print("deltaX=");Dx.Afisare();System.out.println();
	    r1.Multy(a,f);
	    //System.out.print("c*e=");r1.Afisare();System.out.println();
	    r2.Multy(c,d); 
	    //System.out.print("b*f=");r2.Afisare();System.out.println();
	    Dy.Scade(r1,r2);
	    System.out.print("deltaY=");Dy.Afisare();System.out.println();
	    if (!D.EsteZero())
	      { RATIONAL x= new RATIONAL(0,1);
	        x.Divide(Dx,D);
	        RATIONAL y= new RATIONAL(0,1);
	        y.Divide(Dy,D);
	        System.out.print("x=");x.Afisare();System.out.println();
	        System.out.print("y=");y.Afisare();System.out.println();
	       }
	    else if (Dx.EsteZero() && Dy.EsteZero())
	              System.out.println("sistem nedeterminat");
	         else System.out.println("sistem incompatibil"); 
	  RATIONAL t[]=new RATIONAL[10];
		t[0]=new RATIONAL (1,2);
		t[1]=new RATIONAL (1,3);
		t[2]=new RATIONAL (1,4);
		t[3]=new RATIONAL (1,5);
		t[4]=new RATIONAL (1,6);
		t[5]=new RATIONAL (1,7);
		t[6]=new RATIONAL (1,8);
		t[7]=new RATIONAL (1,9);
		t[8]=new RATIONAL (1,10);
		t[9]=new RATIONAL (1,11);
		System.out.println("Secventa inainte de sortare:");
		for(int i=0;i<10;i++)
		{t[i].Afisare();
		 System.out.print(" ");
		}
		System.out.println();
		boolean OK=true;
		while (OK){
			OK=false;
			for (int i=0;i<9;i++)
				if (t[i].MaiMareEgal(t[i+1])) {
					RATIONAL aux=new RATIONAL(t[i]);
					t[i].Assign(t[i+1]);
					t[i+1].Assign(aux);
					OK=true;
				}
						
		}
		for(int i=0;i<10;i++)
			{t[i].Afisare();
			 System.out.print(" ");
			}
		
	    }
	
	
 }


