
public class RATIONAL {		// implementare TAD RATIONAL (Abstract Data Type)
  private long p; 		// numaratoru' p
  private long q;		// numitoru'   q (q!=0)
  public  RATIONAL (long p, long q){ // constructor de alocare si initializare
    this.p=p;
	if (q==0) q     =1;
	else      this.q=q;
	Simplifica();
  }
  public RATIONAL(RATIONAL r){	//constructor de copiere din alt rational
	p=r.p;
	q=r.q;
	}
  public RATIONAL(int I){		//constructor de numar rational din intreg
	p=I;
	q=1;
  }
  public RATIONAL Assign(RATIONAL r){
	p=r.p;
	q=r.q;
	return this;
  }
  public RATIONAL Invers(RATIONAL r){
    if(r.p==0){
   	  p=0;
      q=1;
    }
    else{
      p=r.q;
      q=r.p;
    }   
    return this;
  }
  public void setP(long p){   	// setare numarator
	this.p=p;
	Simplifica();
  }
  public void setQ(long q){		// setare numitor
	if (q==0) this.q=1;
	else	  this.q=q;
	Simplifica();
  }
  public long  getP(){       	// returnari p si q
    return p ;
  }
  public long  getQ(){
	return q ;
  }
  public void Afisare(){
	if (q==1)
	   System.out.print(p);
	else 
	  if (p==0)              			//q<>1
	        System.out.print("0");
	  else  System.out.print(p+"/"+q);  //q<>1 si p<>0
  }
  private long CMMDC(long x,long y){
	while (x!=y)
	  if (x>y) x=x-y;
	  else     y=y-x;
	return x;
  }
  private void Simplifica(){
	long divizor=1;
	if (p!=0) divizor= CMMDC(Math.abs(p),Math.abs(q));
	p/=divizor;			// p=p/divizor;
	q/=divizor;
	if(p*q>=0){ 
	   p=Math.abs(p);
	   q=Math.abs(q);
	}
	else{
	   p=-Math.abs(p);
	   q= Math.abs(q);
	}
  }
  public void Aduna(RATIONAL r1, RATIONAL r2){	//adunare obiectul implicit = r1+r2
	p=r1.p*r2.q+r1.q*r2.p;
	q=r1.q*r2.q;
	Simplifica();  
  }
  public void Scade(RATIONAL r1, RATIONAL r2){	//scadere obiectul implicit = r1-r2
	p=r1.p*r2.q-r1.q*r2.p;
	q=r1.q*r2.q;
	Simplifica();  
  }
  public void Multy(RATIONAL r1, RATIONAL r2){	//inmultire obiectul implicit = r1*r2
	p=r1.p*r2.p;
	q=r1.q*r2.q;
	Simplifica();  
  }
  public void Divide(RATIONAL r1, RATIONAL r2){	//impartire obiectul implicit = r1 / r2
	RATIONAL Inv=new RATIONAL(r2);
	this.Multy(r1,Inv.Invers(r2));     //r1*inversul(r2)
	Simplifica();  
  }
  public boolean EsteZero(){
	if (p==0) return true;
	          return false;
  } 
  public boolean MaiMareEgal (RATIONAL r1){  //daca obiectul implicit mai mare egal ca r1 => true
	if(p*r1.q >= q*r1.p) return true;
	else			     return false;
  }
}


