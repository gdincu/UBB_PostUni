import java.util.LinkedList;
class StivaD implements IStiva
{
	private LinkedList l;
	public StivaD()
	{
	l=new LinkedList();
	}
	public void adauga(Object a)
	{
	l.add(0,a);
	}
	public boolean eVida()
	{
	return (l.size()==0);
	}
	public Object scoate()
	{
	return l.removeFirst();
	}
	public Object getCap()
	{
	return l.getFirst();
	}
}
