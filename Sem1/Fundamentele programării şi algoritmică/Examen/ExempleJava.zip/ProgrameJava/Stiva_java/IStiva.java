interface IStiva
{
	void adauga(Object a);
	Object scoate();
	boolean eVida();
	Object getCap();
}