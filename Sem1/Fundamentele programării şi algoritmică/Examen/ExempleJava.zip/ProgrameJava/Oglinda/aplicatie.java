import javax.swing.*;
import java.*;
import java.awt.event.*;
import java.lang.*;
class aplicatie
  { public static void main(String args[])
     {Oglinda i=new Oglinda();
      i.addWindowListener(new WindowAdapter()
          {public void windowClosing(WindowEvent a)
               {System.exit(0);}
           });
       i.pack();
       i.setVisible(true);
     }
   }   