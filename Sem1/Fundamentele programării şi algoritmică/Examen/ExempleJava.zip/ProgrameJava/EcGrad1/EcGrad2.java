public class EcGrad2
 { private double a; 		// coeficientii ec. aX^2+bx+c=0;
   private double b;
   private double c;
   public  EcGrad2 (double a, double b, double c) // constructor
	   { this.a=a;
	     this.b=b;
             this.c=c;
	   }
   public void setA(double a)   	// setari a b si c
	   {this.a=a;
           }
   public void setB(double b)
	   {this.b=b;
           }
   public void setC(double c)
	   {this.c=c;
           }
   public double   getA()       	// returnari a si b
	   {return a ;
           }
   public double   getB()
	   {return b ;
           }
   public double   getC()
	   {return c ;
           }
   public void afisare()
	   { EcGrad1 ec1 = new EcGrad1(b,c);
             System.out.print("ecuatia este:");
             if (a!=0)
                 { if (a!=1.0)
                     	System.out.print(getA()+"*X^2");
                   else
                     	System.out.print("X^2");
                  }
             if (b>=0) System.out.print("+");
             ec1.afisare1();
 	   }

   public void rezolva()
          {  //System.out.println();
             if (a!=0)
              { double d=b*b-4*a*c;
	        if(d<0) { System.out.println ("radacini complexe conjugate:");
		          System.out.println ("partea reala="+ (-b/(2*a)));
		          System.out.println (" coef p. imag="+Math.sqrt(-d)/(2*a));
		        }
	        else if (d>0)
		        { System.out.println("x1="+(-b-Math.sqrt(d))/(2*a));
		          System.out.println("x2="+(-b+Math.sqrt(d))/(2*a));
		        }
	             else System.out.println("x1=x2="+(-b/(2*a)));
               }
             else { EcGrad1 e = new EcGrad1(b,c);
	            //e.afisare1();
	            e.rezolva1();
	          }
            }
}
