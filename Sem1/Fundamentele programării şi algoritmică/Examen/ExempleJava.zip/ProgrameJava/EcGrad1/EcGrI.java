import java.io.*;
public class EcGrI
   { public static void main(String args[])
      {int a=0, b=0;
       String sir;
       InputStreamReader stdin = new InputStreamReader(System.in);
       BufferedReader console  = new BufferedReader(stdin);
       
       try { System.out.print("coef lui x: ");
	     sir = console.readLine();
	     a   = Integer.parseInt(sir);
	   }
       catch(IOException ioex)
	   { System.out.println("Eroare intrare sistem");
	     System.exit(1);
	   }
       catch(NumberFormatException nfex)
	   {System.out.println("\"" + nfex.getMessage() + 	"\" nu-i numeric");
            System.exit(1);
	  }

       try { System.out.print("coef liber: ");
	     sir = console.readLine();
	     b   = Integer.parseInt(sir);
	   }
       catch(IOException ioex)
	   { System.out.println("Eroare intrare sistem");
	     System.exit(1);
	   }
       catch(NumberFormatException nfex)
	   {System.out.println("\"" + nfex.getMessage() + 	"\" nu-i numeric");
            System.exit(1);
	  }

       System.out.print("Ecuatia: "+a+"x+"+b+"=0");
       if (a==0)
	         if (b==0)
	           System.out.println(" are o infinitate de solutii");
	         else
	           System.out.println("  nu are solutii");
       else { double x =-(double)b/a;
              System.out.println("  are solutia "+x);
	    }   
       }
   }
