public class TestEcGrad2
{ public static void main(String args[])
   {EcGrad2 e2 = new EcGrad2(1,1,1);
    e2.afisare();
    e2.rezolva();
    e2.setA(0);
    e2.afisare();
    e2.rezolva();
    e2.setA(1);
    e2.setB(2);
    e2.afisare();
    e2.rezolva();
    e2.setA(1);
    e2.setB(-3);
    e2.setC(2);
    e2.afisare();
    e2.rezolva();

   }
}