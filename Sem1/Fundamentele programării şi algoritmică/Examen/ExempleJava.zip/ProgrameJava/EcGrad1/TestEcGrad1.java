public class TestEcGrad1
{ public static void main(String args[])
   {EcGrad1 e1 = new EcGrad1(12,5);
    e1.afisare1();
    e1.rezolva1();
    e1.setA(0);
    e1.setB(0);
    e1.afisare1();
    e1.rezolva1();
    e1.setA(0);
    e1.setB(1);
    e1.afisare1();
    e1.rezolva1();
   }
}