
class EcGrad1
 { private double a; 		// coeficientii ec. aX+b=0;
   private double b;
   public  EcGrad1 (double a, double b) // constructor
	   { this.a=a;
	     this.b=b;
	   }
   public void setA(double a)   	// setari a si b
	   {this.a=a;
           }
   public void setB(double b)
	   {this.b=b;
           }
   public double   getA()       	// returnari a si b
	   {return a ;
           }
   public double   getB()
	   {return b ;
           }
   public void afisare1()
	   { if (a!=0)
                 { if (a!=1.0)
                     	System.out.print(getA()+"*X");
                   else
                     	System.out.print("X");
                  }
             if(getB()<0) System.out.print(getB()+"=0");
	     else         System.out.println("+"+getB()+"=0");
	   }

   public void rezolva1()			// rezolvare
       {  //System.out.println();
          if (a!=0) 		System.out.println("ec. are sol. unica:"+ -b/a);
          else if (b!=0) 	System.out.println("ec. nu are solutii");
	          else 		System.out.println("ec. are o inf. de solutii reale");
       }
	       		
  }

public class GradI
{ public static void main(String args[])
   {EcGrad1 e1 = new EcGrad1(12,5);
    e1.afisare1();
    e1.rezolva1();
    e1.setA(0);
    e1.setB(0);
    e1.afisare1();
    e1.rezolva1();
    e1.setA(0);
    e1.setB(1);
    e1.afisare1();
    e1.rezolva1();
   }
}