
import java.io.*;
import java.lang.Math.*;
public class Nzecimale 
{ public static void main(String args[])
  { int k=0,m=0,n=0,z,rest,i,c;
    String s1;
    InputStreamReader stdin = new InputStreamReader(System.in);
    BufferedReader console  = new BufferedReader(stdin);
    try 
    { System.out.print("numarator: ");
	  s1 = console.readLine();
	  k = Integer.parseInt(s1);
	}
    catch(IOException ioex)
	{ System.out.println("Input error");
	  System.exit(1);
	}
    catch(NumberFormatException nfex)
	{System.out.println("\"" + nfex.getMessage() + 	"\" is not numeric");
         System.exit(1);
	}
    try 
    { System.out.print("numitor: ");
	  s1 = console.readLine();
	  m = Integer.parseInt(s1);
	}
    catch(IOException ioex)
	{ System.out.println("Input error");
	  System.exit(1);
	}
    catch(NumberFormatException nfex)
	{System.out.println("\"" + nfex.getMessage() + 	"\" is not numeric");
         System.exit(1);
	}
    try { System.out.print("cate zecimale: ");
	  s1 = console.readLine();
	  n = Integer.parseInt(s1);
	}
    catch(IOException ioex)
	{ System.out.println("Input error");
	  System.exit(1);
	}
   catch(NumberFormatException nfex)
	{System.out.println("\"" + nfex.getMessage() + 	"\" is not numeric");
       System.exit(1);
	}
    i=0;
    z=k;
    System.out.print("0.");
    while (i<n) 
    {c=z*10 / m;
     rest = z*10 % m;
     System.out.print(c);
     z=rest;
     i++;
    }
    
    
    
   }
}