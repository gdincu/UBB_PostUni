public class AplicatieS
{
	public static void main(String a[])
	{
	try{	String a1=new String("abc");
		String a2=new String("def");
		String a3=new String("ghi");
		IStiva s2=new StivaS();
		s2.adauga(a1);
		s2.adauga(a2);
		s2.adauga(a3);	
		while (!s2.eVida())
			System.out.print(((String)s2.scoate()).toString()+" ");
		s2.scoate();}
	catch(ExceptieStivaVida e)
	{System.out.println(e);}
	
	try{    IStiva s1=new StivaD();
		Integer i1=new Integer(1);
		s1.adauga(i1);
        	Integer i2=new Integer(2);
		s1.adauga(i2);
        	Integer i3=new Integer(3);
		s1.adauga(i3);
		while (!s1.eVida())
          		  System.out.print(((Integer)s1.scoate()).toString()+" ");
		s1.scoate();}
	catch(ExceptieStivaVida e)
        {System.out.println(e);}
    }
}
