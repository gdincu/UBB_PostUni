import java.util.ArrayList;
class StivaS implements IStiva
{
	private ArrayList l;
	public StivaS()
	{
	l=new ArrayList();
	}
	public void adauga(Object a)
	{
	l.add(a);
	}
	public Object scoate() throws ExceptieStivaVida
    	{
	try{return l.remove(l.size()-1);}
	catch (IndexOutOfBoundsException e)
	{throw new ExceptieStivaVida("Stiva e vida!");}
	}	
	public boolean eVida()
	{
	return l.isEmpty();
	}
	public Object getCap() throws ExceptieStivaVida
	{
	try{return l.get(l.size()-1);}
        catch (IndexOutOfBoundsException e)
        {throw new ExceptieStivaVida("Stiva e vida!");}
	}
}
