import java.util.*;
class StivaD implements IStiva
{
	private LinkedList l;
	public StivaD()
	{
	l=new LinkedList();
	}
	public void adauga(Object a)
	{
	l.add(0,a);
	}
	public boolean eVida()
	{
	return (l.size()==0);
	}
	public Object scoate() throws ExceptieStivaVida
	{
	try{return l.removeFirst();}
	catch(NoSuchElementException e)
	{throw new ExceptieStivaVida("Stiva e vida!");
	}
	}
	public Object getCap() throws ExceptieStivaVida
	{
	try{return l.getFirst();}
        catch(NoSuchElementException e)
        {throw new ExceptieStivaVida("Stiva e vida!");
	}
	}
}
