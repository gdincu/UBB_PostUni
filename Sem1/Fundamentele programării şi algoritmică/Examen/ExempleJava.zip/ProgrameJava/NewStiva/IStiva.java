interface IStiva
{
	void adauga(Object a);
	Object scoate() throws ExceptieStivaVida;
	boolean eVida();
	Object getCap() throws ExceptieStivaVida;
}