import java.util.Scanner;

public class Oglinda {
  
  public static long Citire(String sir){
	System.out.print(sir);
	Scanner scn = new Scanner(System.in);
	long l=scn.nextLong();
	return l;
  }

  public static void main(String args[]){
       long n=Citire("da un numar natural:");
       System.out.println("numarul citit este "+n);
       long Og=0;
       while (n>0){
          Og=Og*10+ n % 10;
          n =n/10;
       }
       System.out.println("numarul oglindit "+Og);
       System.out.println("Program terminat");

  }


}