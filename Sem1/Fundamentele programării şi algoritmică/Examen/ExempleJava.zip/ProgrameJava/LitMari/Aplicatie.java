import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.lang.*;
class Aplicatie
{public static void main(String s[])
	{Mari c=new Mari(); 
	 c.addWindowListener(new WindowAdapter()
		{public void windowClosing(WindowEvent a)
			{System.exit(0);}
		});
	c.pack();
	c.setVisible(true);
	}
}