import javax.swing.*;
import java.awt.*;
import java.lang.*;

class Mari extends JFrame
	       implements java.awt.event.ActionListener
{ JLabel     litere;
  JTextField text;
  JTextField text1;
 public Mari()
	{ super("Schimbator");
	  JPanel p = new JPanel();
	  p.setLayout(new GridLayout(3,1));
	  JPanel p1 = new JPanel();
	  litere = new JLabel ("Baga Textul");
	  text= new JTextField(20);
	  p1.add(litere);
	  p1.add(text);
	  p.add(p1);
	  
	  JPanel p2 = new JPanel();
	  JButton  schimba = new JButton("LitereMari");
	  schimba.addActionListener(this);
	  p2.add(schimba);
	  p.add(p2);
	  
	  JPanel p3 = new JPanel();
	  JLabel litereMari = new JLabel ("OK");
	  //String zero = new String("0");
	  text1= new JTextField(20);
	  text1.setEditable(false);
	  p3.add(litereMari);
	  p3.add(text1);
	  p.add(p3);
	  getContentPane().add(p);
	  
    }

  

/*	JPanel p=new JPanel();
	p.setLayout(new GridLayout(5,1));
	JPanel p1=new JPanel();
	JLabel n=new JLabel("Dati numarul: ");
	numar=new JTextField(10);
	p1.add(n);
	p1.add(numar);
	p.add(p1);

	JPanel p2=new JPanel();
	JLabel pwr=new JLabel("La ce putere?");
	JRadioButton b1=new JRadioButton("unu");
	JRadioButton b2=new JRadioButton("doi");
	JRadioButton b3=new JRadioButton("trei");
	ButtonGroup buton=new ButtonGroup();
	buton.add(b1);
	buton.add(b2);
	buton.add(b3);
	b1.addActionListener(this);
	b2.addActionListener(this);
	b3.addActionListener(this);
	p2.add(pwr); 
	p2.add(b1);
	p2.add(b2);
	p2.add(b3);
	p.add(p2);
	
	JPanel p3=new JPanel();
	radical=new Checkbox("Radacina Patrata ");
//	radical.addActionListener(this);
    p3.add(radical);
    p.add(p3);

	JPanel p4=new JPanel();
	JButton C=new JButton("Calculeaza");
	C.addActionListener(this);
	p4.add(C);
	p.add(p4);
	
	JPanel p5=new JPanel();
	JLabel r=new JLabel("Rezultatul este ");
	String zero=new String("0");
	rezultat=new JTextField(zero,20);
	rezultat.setEditable(false);
	p5.add(r);
	p5.add(rezultat);
	p.add(p5);
	getContentPane().add(p);
	}
 
 */

 public void actionPerformed(java.awt.event.ActionEvent e)
	{if (e.getActionCommand()=="LitereMari")
	     { String VechiText = text.getText();
	       
	       String text2     = VechiText.toUpperCase();
	       text1.setText(""+text2);
	     }
	     
		
	}
}

