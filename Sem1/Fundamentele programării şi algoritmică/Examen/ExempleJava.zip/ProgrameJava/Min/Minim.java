

public class Minim

{ public static void main(String args[])
   { int a=0, b=8;
     System.out.println("a="+a+" b="+b);
     System.out.println("minimul este:"+min(a,b)); 
     System.out.println("minimul este:"+(a<b?a:b));
     if(a>b)  System.out.println("minimul este:"+b);
     else     System.out.println("minimul este:"+a);
   }

  public static int min (int a, int b)
  {
	return a<b?a:b;
  }


}
