//import javax.swing.*;
//import java.awt.*;
import java.awt.event.*;
//import java.lang.*;
class Aplicatie
 { public static void main(String s[])
	 {Ecgr2 ec=new Ecgr2(); 
	  ec.addWindowListener(new WindowAdapter()
	    {public void windowClosing(WindowEvent a)
			{System.exit(0);}
	 	 });
	ec.pack();
	ec.setVisible(true);
	}
 } 
 
 