import javax.swing.*;
import java.awt.*;
import java.lang.*;
class Ecgr2 extends JFrame implements java.awt.event.ActionListener
{float _a,_b,_c;
 JLabel La=new JLabel("Dati a: ");
 JLabel Lb=new JLabel("Dati b: ");
 JLabel Lc=new JLabel("Dati c: ");
 JTextField n_a;      
 JTextField n_b;
 JTextField n_c;
 float delta;
 JTextField rezultat;
 // JTextField rezultat;
 // Checkbox radical;
 JPanel p=new JPanel(); 
 // declarare panou
 public Ecgr2()
  { super("Rezolvarea Ecuatiei de Gr.2.");
    JPanel p=new JPanel();
    // declarare panou
       p.setLayout(new GridLayout(5,1));
       JPanel p1=new JPanel();
       p1.add(La);
       n_a=new JTextField(5);
       p1.add(n_a);
       p.add(p1);
       JPanel p2=new JPanel();
       p2.add(Lb);
       n_b=new JTextField(5);
       p2.add(n_b);
       p.add(p2);
       JPanel p3=new JPanel();
       p3.add(Lc);
       n_c=new JTextField(5);
       p3.add(n_c);
       p.add(p3);
       JPanel p4=new JPanel();
       JButton C=new JButton("Calculeaza");
       C.addActionListener(this);
       p4.add(C);
       p.add(p4);
       JPanel p5=new JPanel();
       String zero=new String("0");
       rezultat=new JTextField(zero,20);
       rezultat.setEditable(false);
       p5.add(rezultat);
       p.add(p5);
       getContentPane().add(p);
  }
  public void actionPerformed(java.awt.event.ActionEvent e)
   {if (e.getActionCommand()=="Calculeaza")
       {  _a=Float.parseFloat(n_a.getText());
          _b=Float.parseFloat(n_b.getText());
          _c=Float.parseFloat(n_c.getText());
           delta=_b*_b-4*_a*_c;
           rezultat.setText("delta="+delta);
       }
   /*	{try {int i=Integer.parseInt(numar.getText());
         int prod=1;
       	  for(int j=1;j<=5;j++) prod*=i;
	  double proddouble=prod;
	  if (radical.getState()) 
		    {   if (prod>=0)
  	    	          proddouble=Math.sqrt(prod);
		    	else JOptionPane.showMessageDialog(numar,"Numar negativ","EROARE",JOptionPane.ERROR_MESSAGE);
		    }
              rezultat.setText(""+proddouble);
        }
   catch(NumberFormatException a)
    {JOptionPane.showMessageDialog(numar,"Numar nu e intreg","EROARE",JOptionPane.ERROR_MESSAGE);}
    }
   }
*/
}
}