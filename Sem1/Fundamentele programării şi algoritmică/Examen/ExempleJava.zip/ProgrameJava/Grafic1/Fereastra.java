import javax.swing.JFrame;
import javax.swing.JList;


public class Fereastra extends JFrame{
  public Fereastra(){
   super ("Ferestra");
   String continut[]={"AWT","Swing","Accessibility",
		      "JAVA 2D", "Drag and Drop"};
   JList lista = new JList(continut);
   this.getContentPane().add(lista);
  }
}

