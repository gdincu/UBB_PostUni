import javax.swing.JFrame;
import javax.swing.JList;


public class Aplicatie{

  public static void main (String[] args){
    Fereastra f = new Fereastra();
    f.pack();
    f.setVisible(true);    

  }
}
