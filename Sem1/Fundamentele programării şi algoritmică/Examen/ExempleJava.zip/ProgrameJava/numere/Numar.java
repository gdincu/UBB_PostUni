
public class Numar {

    private int nr;

    // constructor
    public Numar(int nr) {
        this.nr = nr;
    }

    // getter
    public long getNr() {
        return nr;
    }

    // setter
    public void setNr(int nr) {
        this.nr = nr;
    }

    // returns true is the number can be devided to i, false otherwise
    public boolean isDevided(int i) {
        return (this.nr % i == 0);
    }

}
