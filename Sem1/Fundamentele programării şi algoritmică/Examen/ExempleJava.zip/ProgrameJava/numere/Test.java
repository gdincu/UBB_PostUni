import java.util.Scanner;

public class Test {

    private static Numar number;

    public static void main(String[] args) {
        // initializare numar
        number = new Numar(0);
        // rulare program
        long Opt;
        Opt = AfisMeniu();
        while (Opt != 0) {
            if (Opt == 1) CitireDate();
            else if (Opt == 2) AfisareDate();
            else System.out.println("Ai gresit optiune, mai incearca");
            Opt = AfisMeniu();
        }
        System.out.println("program terminat");
    }

    public static long AfisMeniu() {
        System.out.println();
        System.out.println("1.Citire date");
        System.out.println("2.Rulare program");
        System.out.println("0.Terminare Program");
        long Opt = CitLong("Optiuna ta(1,2,0):");
        return Opt;
    }

    public static long CitLong(String Sir) {
        System.out.print(Sir);
        Scanner scn = new Scanner(System.in);
        return scn.nextLong();
    }

    public static int CitInt(String sir){
        System.out.print(sir);
        Scanner scn = new Scanner(System.in);
        return scn.nextInt();
    }

    public static void CitireDate() {
        int n = CitInt("Inserati n:");
        number = new Numar(n);
    }

    public static void AfisareDate() {
        System.out.println("Numerele sunt:");
        for (int i = 1; i < number.getNr(); i++) {
            if (number.isDevided(i)) System.out.print(i + "; ");
        }
        // new line
        System.out.println();
    }
}
