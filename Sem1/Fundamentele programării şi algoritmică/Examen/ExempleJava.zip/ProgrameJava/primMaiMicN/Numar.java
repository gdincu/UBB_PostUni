
public class Numar {

    private long Val;    //reprezentarea clasei
    			//metodele (comportamentul clasei)
    public Numar(){    //constructor implicit
        Val=0;
    }
    public Numar(long L){  //constructor de alocare si initializare
        Val=L;
    }
    //accesori
    public long getN() {
        return Val;
    }
    public void setN(long V) {
        Val=V;
    }

    public boolean Prim(){			// Primeste un numar si returneaza daca este prim
        long div;

        div=2;
        while(div*div<=Val && Val % div !=0) {			// Algoritmul de determinare al numarului prim
            if(div==2)
                div++;			// Incrementeaza cu o unitate
            else
                div+=2;			// Incrementeaza cu doua unitati
        }
        if(div*div>Val)
            return true;		// Returneaza daca numarul este prim sau nu
        else
            return false;
    }


}