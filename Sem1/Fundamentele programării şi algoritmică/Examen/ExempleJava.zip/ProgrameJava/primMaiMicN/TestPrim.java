
import java.util.Scanner; 			// Importa libraria Scanner

public class TestPrim {

    public static long CitLong(String sir){			// Citeste un numar de tip long
        System.out.print(sir);					// Afiseaza mesajul primit
        Scanner scn = new Scanner(System.in);
        return scn.nextLong();					// Returneaza numarul introdus
    }

    public static long AfisMeniu(){			// Afiseaza meniul si returneaza optiunea primita
        System.out.println();
        System.out.println("1.Citire date");
        System.out.println("2.Rulare program");
        System.out.println("0.Terminare Program");
        long Opt=CitLong("Optiunea ta(1,2,0):");			// Retine optiunea primita
        return Opt;
    }
    public static void ExecutaProgram(Numar n){
        Numar i=new Numar();      
        boolean estePrim = false;
        long j=n.getN()-1;
        while(j >= 2){
            i.setN(j);
            if( (i.Prim()==true)) {	// Daca numarul este prim afiseaza si retine acest lucru
                System.out.println("Cel mai mare numar prim mai mic decat un numar " + n.getN() + " este: " + i.getN());
                estePrim = true;
                break;
            }
            else {
                j--;			// Decrementeaza cu o unitate
            }
        }
        if (estePrim == false)			// Daca nu a gasit un numar prim afiseaza mesajul
            System.out.println("Nu exista un numar prim mai mic decat numarul " + n.getN());
    }

    public static void main(String[] args) {

        Numar n = new Numar();      /* Instantiaza obiectul de tip numar */
        long opt = AfisMeniu();
        while(opt!=0) {
            if(opt==1)
                n.setN(CitLong("Introduceti numarul dorit:"));			// Retine numarul returnat
            else if(opt==2)
                ExecutaProgram(n);
            else
                System.out.println("Ai gresit optiunea, mai incearca" );
            opt=AfisMeniu();			// Afiseaza meniul cat timp optiunea e diferita de 0
        }


        System.out.println("Program terminat");
    }
}
