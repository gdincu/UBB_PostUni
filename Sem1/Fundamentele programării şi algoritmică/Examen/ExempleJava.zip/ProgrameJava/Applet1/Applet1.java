import javax.swing.*;
import java.awt.*;

public class Applet1 extends JApplet 
{ public void paint(Graphics g)
  { g.drawString("Alexandra",50,50);
  }
}
