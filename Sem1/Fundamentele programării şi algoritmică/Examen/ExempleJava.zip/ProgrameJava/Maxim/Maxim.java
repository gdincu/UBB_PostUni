import java.util.Scanner;

public class Maxim {
  
  public static long Citire(String sir){
	System.out.print(sir);
	Scanner scn = new Scanner(System.in);
	long l=scn.nextLong();
	return l;
		        
  } 
  public static void Afis(long  n){
	System.out.print(n);
  }


  public static long AfisMeniu(){
        System.out.println();
        System.out.println("1.introducere date si executie program");
        System.out.println("0.terminare program");
        long Opt=Citire("optiunea dvs:");
        return Opt;
  } 

  public static void main(String args[]){
        long Op=AfisMeniu();
        while(Op!=0){
          if(Op==1){
            long a=Citire("primul numar:");	//s-au declarat a,b de tip intreg lung
            long b=Citire("al doilea numar:");
            if(a>b)   System.out.println("Maximul dintre "+a+" si "+b+" este: "+a);
            else      System.out.println("Maximul dintre "+a+" si "+b+" este: "+b);
          }
          else   System.out.println("Ai gresit optiunea, mai incearca");
          Op=AfisMeniu();
        }
        System.out.println("Program terminat");
        
 }                           
}
