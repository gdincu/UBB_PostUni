class Aplicatie
{
 public static void main(String a[])
 {Rational x=new Rational(-2,4);
  Rational y=new Rational(1,3);
  x.Aduna(y);
  x.Afiseaza();
  Rational z=new Rational(5,3);
  y.Imparte(z);
  y.Afiseaza();
  Rational t=new Rational(Rational.suma(x,y));
  t.Afiseaza();
 }
}