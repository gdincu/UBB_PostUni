class Rational
{private int a;//Specificatie: Rational=a/b ireductibile, a,b intregi
 private int b;
 public Rational(int x,int y)
 {a=x;
  b=y;
  Simplifica();
 }

 public Rational(Rational x)
 {a=x.a;
  b=x.b;
 }

 public Rational(int x)
 {a=x;
  b=1;
 }

 public static int Cmmdc(int x,int y)
 {if(x==y) return x;
	else if (x>y) return Cmmdc(x-y,y);
		else return Cmmdc(x,y-x);
	
 }

 private void Simplifica()
 {int x=Math.abs(a),y=Math.abs(b);
  int aux=Cmmdc(x,y);
  a/=aux;
  b/=aux;
 }

 public void Aduna(Rational x)
 {int auxa=a*x.b+b*x.a;
  int auxb=b*x.b;
  a=auxa; b=auxb;
  Simplifica();
 }

 public void Inmulteste(Rational x)
 {a*=x.a;
  b*=x.b;
  Simplifica(); 
 }

 public Rational Invers()
 {Rational aux=new Rational(b,a);
  return aux;
 }

 public void Imparte(Rational x)
 {Inmulteste(x.Invers());
 }

//exemplu de operatie care apartine clasei...
 public static Rational suma(Rational x,Rational y)
 {Rational z=new Rational(x);
  z.Aduna(y);
  return z;
 }

 public void Afiseaza()
 {System.out.println(a);
  System.out.println(b);
 }
}
