
import javax.swing.*;
import java.awt.*;
import java.lang.*;

class MiciMari extends JFrame
	       implements java.awt.event.ActionListener
{ JLabel     litere;
  JTextField text;
  JTextField text1;
  JPanel p = new JPanel();
 public MiciMari()
	{ super("Schimbator");
	  p.setLayout(new GridLayout(3,1));
	  JPanel p1 = new JPanel();
	  litere = new JLabel ("Baga Textul");
	  text= new JTextField(20);
	  p1.add(litere);
	  p1.add(text);
	  p.add(p1);
	  
	  JPanel p2 = new JPanel();
	  JButton  schimba = new JButton("Mari<-->Mici");
	  schimba.addActionListener(this);
	  p2.add(schimba);
	  p.add(p2);
	  
	  JPanel p3 = new JPanel();
	  JLabel litereMari = new JLabel ("OK");
	  text1= new JTextField(20);
	  text1.setEditable(false);
	  p3.add(litereMari);
	  p3.add(text1);
	  p.add(p3);
	  getContentPane().add(p);  
	  
    }

 public void actionPerformed(java.awt.event.ActionEvent e)
	{if (e.getActionCommand()=="Mari<-->Mici")
	     { String text2     = text.getText();
	       String tt="";
	       for (int i=0; i<text2.length(); i++)
	        { String k=text2.charAt(i)="";
	          System.out.println("k="+k);
	          String j= text2.charAt(i)+"";

	          j.toUpperCase();
			j.toUpperCase();
			j.toUpperCase();
			j.toUpperCase();
			j.toUpperCase();
	          System.out.println("j="+j);
	          String jj=text2.charAt(i)+"";
	          jj.toLowerCase();
	          System.out.println("jj="+jj);
	          if (j.equals(k))  {tt+=(text2.charAt(i)+"").toLowerCase();
	                            System.out.println(i+tt); 
	                           }
	          else                  
	         if (jj.equals(k)) {tt+=(text2.charAt(i)+"").toUpperCase();
	                            System.out.println(i+tt); }
	        } 
	       text1.setText(""+tt);
	     }
	     
		
	}
}

