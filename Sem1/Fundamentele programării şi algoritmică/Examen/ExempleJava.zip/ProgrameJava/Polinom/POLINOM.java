import java.io.BufferedReader;
import java.io.InputStreamReader;

public class POLINOM {
        byte DIM = 100;	
	byte grad;
	int  coef[];					//spatiul de memorare al coef
	  						//2x^2-3x+1 => 1,-3,2
	public int GetCoefZero()
	{int i=0;			//returneaza primul coef nenul, daca coef[0] e nul
	 while (coef[i]==0) i++;
	 return coef[i];
	}
	public int GetCoefI (int i)			// returneza coef[i]
	{if(i>=0 && i<=grad)  return coef[i];
	 else                 return 0;
	}
	public void SetCoefI(int i,int c)		// seteaza coef[i]
	{if(i>=0 && i<=grad) coef[i]=c;
	 else                coef[i]=0;
	}
	
	public POLINOM()  {				//constructor implicit
	  this.grad=0;					//se initializeaza la 0
	  this.coef = new int[DIM];
	  this.coef[0]=0;
	}
	public POLINOM(POLINOM P){			//constructor de copiere
	  if (this!=P)
		 {grad=P.grad;
		  for(byte i=0;i<=grad;i++)
		     coef[i]=P.coef[i];
		 }
	}
	public int ValPol(int x)			//returneaza valoarea polinomului in x
	{int Val;
	 Val=coef[grad];
	 for(int i=grad-1; i>=0; i--)
	   Val=Val*x+coef[i];
	 return Val;	
	}
	
	public POLINOM(String sir){ 	//constructor creare din stringul de numere
	    int i=0;			//pe prima pozitie e gradul "3,2,3,-34,45"}
	    int j=i;
	    coef=new int[DIM];
	    System.out.println(sir);
	    String s=new String("");
	    while (j<sir.length()&& sir.charAt(j)!=',') j++;
	    				//System.out.println(i+" "+j);
	    s=sir.substring(i,j);
	    				//System.out.println(s);
	    
	    grad=(byte)Byte.parseByte(s);
	    				//System.out.println(grad);
	    
	    i=j+1;j++;
	    				//System.out.println("i="+i+" j="+j);
	    int lung=sir.length();
	    int k=0;
	    while (j<lung)
	    { while(j<lung && sir.charAt(j)!=',') j++;
	      if(j<lung) 
	        {			//System.out.println(i+" si "+j);
	         s=sir.substring(i,j);
	         			//System.out.println("sirul "+s+" ");
	         int ss=(int)Integer.parseInt(s);
	         coef[k++]=ss;
	         			//System.out.println("coef[" + (k-1) +"]="+coef[k-1]+" ");
	         i=j+1;j=i;
	         			//System.out.println("i="+i+" j="+j);
	        }
	      j++;
	    }
	    				// la sfarsit tre pus si ultimul coeficient
	       s=sir.substring(i,lung);
	       				//System.out.println("la sfarsit i="+i+" j="+j);
	       				//System.out.println("sirul "+s+" ");
	       int ss=(int)Integer.parseInt(s);
	       coef[k++]=ss;
	       				//System.out.println("coef[" + (k-1) +"]="+coef[k-1]+" ");
	       
    } 

	
	public void SetGrad(byte g)
	{	grad=g;
	}
	public byte GetGrad()
	{	return grad;
	}
	
	
	public void sumaPoly (POLINOM P1,POLINOM P2){
	 byte i,min,max;
	 if (P1.grad>P2.grad)
	     {max=P1.grad;
	      min=P2.grad;
	     }
	 else
	     {max=P2.grad;
	      min=P1.grad;
	     }
	  grad=max;
	  for (i=0; i<=min;i++)
	    coef[i]=P1.coef[i]+P2.coef[i];
	  if (P1.grad>P2.grad)
	     for (i=(byte) (min+1);i<=max;i++)
	          coef[i]=P1.coef[i];
	  else
	     for (i=(byte)(min+1); i<=max;i++)
	          coef[i]=P2.coef[i];
	  i=grad;
	  while (coef[i]==0) i--;
	  grad=i;
   }
}