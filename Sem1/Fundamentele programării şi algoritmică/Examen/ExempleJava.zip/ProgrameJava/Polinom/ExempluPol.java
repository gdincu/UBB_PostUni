import java.io.BufferedReader;
import java.io.InputStreamReader;


public class ExempluPol {
	public static void AfisPoly (POLINOM p){
		if(p.GetCoefI(0)!=0) System.out.print(p.GetCoefI(0));
		for(byte i=1;i<=p.GetGrad();i++)
		   {if(p.GetCoefI(i)==1)
			   System.out.print("+X");
		    else  if(p.GetCoefI(i)==-1)
			        System.out.print("-X");
		         else
			        if(p.GetCoefI(i)<0)
		        	 System.out.print(p.GetCoefI(i)+"X");
			        else
			            if(p.GetCoefI(i)>0) System.out.print("+"+p.GetCoefI(i)+"X");
		    if(i>1 && p.GetCoefI(i)!=0) System.out.print("^"+i);
     	   }

		System.out.println();
	}

	public static void CitPoly  (POLINOM p){
		int c;
		byte g;
		System.out.print("Introdu grad polinom = ");
		InputStreamReader reader = new InputStreamReader(System.in);
		BufferedReader bufReader = new BufferedReader(reader);
		try {
			String readText = bufReader.readLine();
			g = Byte.parseByte(readText);
			p.SetGrad(g);
		}
		catch(Exception e) {
			System.out.println("Nu ati introdus corect numarul intreg");
			System.exit(-1);
		}
		for (byte i=0;i<=p.GetGrad(); i++){
		    System.out.print("coef["+i+"]=");
			try {
				String readText = bufReader.readLine();
				c = Integer.parseInt(readText);
				p.SetCoefI(i,c);
			}
			catch(Exception e) {
				System.out.println("Nu ati introdus corect numarul intreg");
				System.exit(-1);
			}	
		}
	}
	
	public static void main(String[] args) {
	POLINOM Suma= new POLINOM();
	POLINOM P1  = new POLINOM();
	CitPoly(P1);
	System.out.println("primul polinom:");
	AfisPoly(P1);
	POLINOM P2  = new POLINOM("2,3,4,1");
	System.out.println("al doilea polinom:");
	AfisPoly(P2);
	int i=1;
	while (i<=P2.GetCoefZero())
		{if (Math.abs(P2.GetCoefZero()) % i==0)
			{if(P2.ValPol(i)==0)
				System.out.println(i+" este radacina");
		     if(P2.ValPol(-i)==0)
			   System.out.println((-i)+" este radacina");
			} 
		 i++;
		}
				/*POLINOM t[]=new POLINOM[10];
				for(int kk=0;kk<10;kk++)
				{CitPoly(t[kk]);
	 			System.out.println();
	 			AfisPoly(t[kk]);
		
				}*/
	
	Suma.sumaPoly(P1, P2);
	System.out.println("polinomul suma:");
	AfisPoly(Suma);
	
	}
}
