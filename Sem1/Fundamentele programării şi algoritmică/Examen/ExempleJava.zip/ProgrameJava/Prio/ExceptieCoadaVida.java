public class ExceptieCoadaVida extends Exception
{
	private String msg = " ";
	public ExceptieCoadaVida(String m)
	{
		 msg = m;
	}
	public String toString()
	{
		return "ExceptieCoadaVida["+msg+"]";
	}
}
