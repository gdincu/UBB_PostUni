public class Prioritate_Activit implements Compar
{
	public int compara(Object a,Object b)
	{
		if (((Student)a).gactivit()<((Student)b).gactivit())
			return 1;
		else	
	    if (((Student)a).gactivit()>((Student)b).gactivit())
			return -1;
		else 
		    return 0;
	}
}								 
