public class Prioritate_Social implements Compar
{
	public int compara(Object a,Object b)
	{
		if (((Student)a).gsocial()>((Student)b).gsocial())
			return 1;
		else	
	    if (((Student)a).gsocial()<((Student)b).gsocial())
			return -1;
		else 
		    return 0;
	}
}								 
