import java.io.*;
interface Compar extends Serializable
{
	public int compara(Object a,Object b);
}
	