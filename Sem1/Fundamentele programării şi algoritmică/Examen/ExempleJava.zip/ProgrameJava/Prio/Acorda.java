import javax.swing.*;
import java.awt.event.*;
import java.awt.*;
import java.*;
import java.io.*;
import java.lang.*;

public class Acorda extends JFrame
        implements java.awt.event.ActionListener
{ 
  static JTextField t1=new JTextField("",4);
  static JTextField t2=new JTextField("",8);   
  static JLabel l1=new JLabel("Nr. maxim de burse:");
  static JLabel l2=new JLabel("Valoarea unei burse"); 
  static DefaultListModel lm=new DefaultListModel();
  static JList lista=new JList(lm);
  static int nr;
  static int val;

 public Acorda()
 {super("Acorda burse");
  t1.setText(""+nr);
  setBounds(200,200,350,350);
  JPanel p=new JPanel();
  p.setLayout(new GridLayout(3,1));
  JPanel p1=new JPanel();
  p1.add(l1); p1.add(t1);
  p.add(p1);
  p1.add(l2); p1.add(t2);
  p.add(p1);
  JButton b=new JButton("Acorda burse");
  p.add(b);
  b.addActionListener(this);
  JScrollPane jp=new JScrollPane(lista);
  p.add(jp);
  getContentPane().add(p);    
  addWindowListener(new WindowAdapter()
                {public void windowClosing(WindowEvent a)
                 {setVisible(false);
		  dispose();
                 }
                });
  setVisible(true);
 }

 public void actionPerformed(ActionEvent e)
        {
        if (e.getActionCommand().equals("Acorda burse"))
	 {try
		{nr=Integer.parseInt(t1.getText());
 		 val=Integer.parseInt(t2.getText());
		 if ((nr<=0)||(val<=0))
			{JOptionPane.showMessageDialog(t1,"DATE INCORECTE","EROARE", JOptionPane.ERROR_MESSAGE);
			}
			else { int min;
			       if (Burse.c1.nr()<nr) min=Burse.c1.nr();
					else min=nr;
			       for(int i=0;i<min;i++)
				{Student aux;
				aux=(Student)Burse.c1.scoate_prio();
				lm.addElement(aux);
				Burse.c2.adauga(aux);
				}
				nr=nr-min;
			     }
		t1.setText(""+nr);
		}
	 catch (Exception er)
                 {JOptionPane.showMessageDialog(t1,"DATE INCORECTE","EROARE",
JOptionPane.ERROR_MESSAGE);
                 }
	 }	  
	}
}