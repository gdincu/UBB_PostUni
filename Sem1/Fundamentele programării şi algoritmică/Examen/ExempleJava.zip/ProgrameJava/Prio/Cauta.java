public abstract class Cauta
{
	public  abstract int cauta(Object a,Object o);
}
