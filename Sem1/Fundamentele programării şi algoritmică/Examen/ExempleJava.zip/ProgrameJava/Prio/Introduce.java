import javax.swing.*;
import java.awt.event.*;
import java.awt.*;
import java.*;
import java.io.*;
import java.lang.*;

public class Introduce extends JFrame
        implements java.awt.event.ActionListener
{ static String aux="";
  static JTextField nume=new JTextField(aux,20);
  static JTextField cod=new JTextField(aux,10);     
  static JTextField medie=new JTextField(aux,5);     
  static JTextField activit=new JTextField(aux,3); 
  static JTextField social=new JTextField(aux,10);
  static JLabel n=new JLabel("Nume si prenume: ");
  static JLabel c=new JLabel("Nr. matricol: ");
  static JLabel m=new JLabel("Medie: ");
  static JLabel a=new JLabel("Activitate stiintifica: ");
  static JLabel s=new JLabel("Stare sociala:");
  static Object o;

 public Introduce()
 {super("Introducere cerere");
  setBounds(200,200,400,400);
  JPanel p=new JPanel();
  p.setLayout(new GridLayout(6,1));
  JPanel p1=new JPanel(); 
  p1.add(n); p1.add(nume); p.add(p1);
  p1=new JPanel(); 
  p1.add(c); p1.add(cod);p.add(p1);
  p1=new JPanel(); 
  p1.add(m); p1.add(medie);p.add(p1);
  p1=new JPanel(); 
  p1.add(a); p1.add(activit);p.add(p1);
  p1=new JPanel(); 
  p1.add(s); p1.add(social);p.add(p1);
  p1=new JPanel(); 
  JButton b1=new JButton("Introdu");
  JButton b2=new JButton("Gata");
  p1.add(b1); p1.add(b2);p.add(p1);
  b1.addActionListener(this);
  b2.addActionListener(this);      
  getContentPane().add(p);    
  addWindowListener(new WindowAdapter()
                {public void windowClosing(WindowEvent a)
                 {setVisible(false);
		  dispose();
                 }
                });
  setVisible(true);
 }

 public void actionPerformed(ActionEvent e)
        {if (e.getActionCommand().equals("Introdu")) 
	 {
	  Cauta caut=new Cauta_Cod(Burse.c1);
	  int t1=caut.cauta(cod.getText(),o);

          caut=new Cauta_Cod(Burse.c2);
          int t2=caut.cauta(cod.getText(),o);

	  if ((t1==0)&&(t2==0))
		{try
			{Burse.c1.adauga(new Student(nume.getText(), cod.getText(),
			Double.parseDouble(medie.getText()),Integer.parseInt(activit.getText()),
			Integer.parseInt(social.getText())));
			nume.setText(aux);
 			cod.setText(aux);
			medie.setText(aux);
			activit.setText(aux);
			social.setText(aux);
			}
		catch(Exception er)
		 {JOptionPane.showMessageDialog(nume,"DATE INCORECTE","EROARE",JOptionPane.ERROR_MESSAGE);
 		 }
		}
	else {JOptionPane.showMessageDialog(nume,"Acest student a mai fost introdus o data anul acesta","EROARE",JOptionPane.ERROR_MESSAGE);
		nume.setText(aux);
                cod.setText(aux);
                medie.setText(aux);
                activit.setText(aux);
                social.setText(aux);
	     }
	 }
        if (e.getActionCommand().equals("Gata"))
	 {setVisible(false);
  	  dispose();
	 }
	}

}