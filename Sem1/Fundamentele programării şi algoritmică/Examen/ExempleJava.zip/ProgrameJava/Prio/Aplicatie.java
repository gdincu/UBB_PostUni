import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.lang.*;
class Aplicatie
{public static void main(String s[])
        {Burse c=new Burse();
        }
}
