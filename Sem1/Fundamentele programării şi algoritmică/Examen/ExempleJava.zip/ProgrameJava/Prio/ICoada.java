interface ICoada
 {
 	void adauga(Object o);
	Object scoate () throws ExceptieCoadaVida;
	Object elem(int p) throws ExceptieCoadaVida;
	boolean eVida();
	int nr();
	Object scoate_prio() throws ExceptieCoadaVida;
	void schimba_prio(Compar c);
 }
	
 
