import java.util.*;
import java.io.*;

public class CoadaP  implements Serializable,ICoada
{
	private Compar comp;
	private ArrayList l;
	static CoadaP aux;
	
	public CoadaP (Compar c)
	{
		l = new ArrayList();
		comp = c;
	}
	
	 public void adauga (Object o)
    {
		int n = 0;
		while ((n < l.size()) && (comp.compara(l.get(n),o)>0))
			n++;
		if (n == l.size()) l.add(l.size(),o);
		else l.add (n,o);
    }	
		

    public boolean eVida()	
	{
		return (l.size()==0);
	}
	
	public int nr ()
	{
		return l.size();
	}
	
    public Object scoate () throws ExceptieCoadaVida
	{
		try
		{
			return l.remove(0);
		}
		catch (Exception e)
		{
			throw new ExceptieCoadaVida("Nu este nici o cerere");
		}
	}
	
    public Object scoate_prio() throws ExceptieCoadaVida
	{
		try
		{
			return l.remove(l.size()-1);
		}
		catch (Exception e)
		{
			throw new ExceptieCoadaVida("Nu este nici o cerere");
		}
	}
	public Object elem(int p) throws ExceptieCoadaVida
	{
		try
		{
			 return l.get(p);
		}
		catch (Exception e)
		{
			throw new ExceptieCoadaVida("Nu sunt atatea elemente");
		}
	}
	public void schimba_prio(Compar c)
	    {aux=new CoadaP(c);
	    try{
	     while (this.eVida()==false)
	        {aux.adauga(this.scoate());
		}}
		catch (ExceptieCoadaVida e)
		    {}
	     l=aux.l;
	     comp=aux.comp;
	    }
}