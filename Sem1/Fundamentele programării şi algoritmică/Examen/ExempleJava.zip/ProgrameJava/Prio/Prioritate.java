import javax.swing.*;
import java.awt.event.*;
import java.awt.*;
import java.*;
import java.io.*;
import java.lang.*;

public class Prioritate extends JFrame
        implements java.awt.event.ActionListener
{ static String aux="";
  static JRadioButton b1=new JRadioButton("Dupa medie",true);
  static JRadioButton b2=new JRadioButton("Dupa activitate stiintifica");   
  static JRadioButton b3=new JRadioButton("Dupa starea sociala");   

 public Prioritate()
 {super("Alege Prioritatea");
  setBounds(300,300,350,350);
  JPanel p=new JPanel();
  p.setLayout(new GridLayout(4,1));
  ButtonGroup g=new ButtonGroup();
  g.add(b1);
  g.add(b2);
  g.add(b3);
  p.add(b1);
  p.add(b2);
  p.add(b3);
  JButton b=new JButton("Gata");
  p.add(b);
  b.addActionListener(this);
  getContentPane().add(p);    
  addWindowListener(new WindowAdapter()
                {public void windowClosing(WindowEvent a)
                 {sfarsit();
		  setVisible(false);
		  dispose();
                 }
                });
  setVisible(true);
 }

 public void actionPerformed(ActionEvent e)
        {
        if (e.getActionCommand().equals("Gata"))
	 {sfarsit();
	  setVisible(false);
  	  dispose();
	 }
	}

 private void sfarsit()
	{Compar p;
 	if (b1.isSelected())
		{p=new Prioritate_Medie();
		Burse.c1.schimba_prio(p);
		Burse.c2.schimba_prio(p);
		}
	if (b2.isSelected())
                {p=new Prioritate_Activit();
                Burse.c1.schimba_prio(p);
		Burse.c2.schimba_prio(p);
                }
	if (b3.isSelected())
                {p=new Prioritate_Social();
                Burse.c1.schimba_prio(p);
		Burse.c2.schimba_prio(p);
                }
	}

}