import java.io.*;
public class Student implements Serializable
{
	private String nume;
	private String cod;
	private double medie;
	private int activit;
	private int bursa_primita;
	private int social;
	public Student (String n,String c,double m,int a,int s)
	{
		nume = n;
		cod = c;
		medie = m;
		activit = a;
		social = s;
		bursa_primita = 0;
	}
	
	public String gcod()
	{
		return cod;
	}	
	
	public String gnume()
	{
		return nume;
	}
	
	public double gmedie()
	{
		return medie;
	}
	
	public int gactivit()
	{
		return activit;
	}
	
	public int gsocial()
	{
		return social;
	}
	
	public int gbursa_primita()
	{
		return bursa_primita;
	}
	
	public void modific_bursa(int s)	
	{
		bursa_primita = s;
	}
	public String toString()
	{return nume+" "+cod+" "+medie+" "+activit+" "+social;
	}
}

	
	
	

