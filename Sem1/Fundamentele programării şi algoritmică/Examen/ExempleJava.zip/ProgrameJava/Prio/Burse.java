import javax.swing.*;
import java.awt.event.*;
import java.*;
import java.io.*;
import java.lang.*;

public class Burse extends JFrame
	implements java.awt.event.ActionListener
{static CoadaP c1,c2;
 static Compar p1,p2;
 static JPanel p=new JPanel();
 static DefaultListModel lm=new DefaultListModel();
 static JList lista=new JList(lm);
 static JScrollPane jp=new JScrollPane(lista);

public Burse()
 {super("Acordare Burse");
  setBounds(100,100,400,400);
  JMenuBar mb=new JMenuBar();
  setJMenuBar(mb);
  JMenu m=new JMenu("Executa");
  mb.add(m);
  JMenuItem i=new JMenuItem("Introdu cerere");
  i.addActionListener(this);
  m.add(i);
  i=new JMenuItem("Schimba prioritatea");
  i.addActionListener(this);
  m.add(i);
  i=new JMenuItem("Acorda burse");
  i.addActionListener(this);
  m.add(i);
  i=new JMenuItem("Termina aplicatia");
  i.addActionListener(this);
  m.addSeparator();
  m.add(i);
  m=new JMenu("Listeaza");
  mb.add(m);
  i=new JMenuItem("Cererile in asteptare");
  i.addActionListener(this);
  m.add(i); 
  i=new JMenuItem("Bursele acordate");
  i.addActionListener(this);
  m.add(i);
  addWindowListener(new WindowAdapter()
		{public void windowClosing(WindowEvent a)
		 {sfarsit();
		  System.exit(0);
		 }
		});
  p.add(jp);
  getContentPane().add(p);
  pack();
  //initializez cozile avand initial prioritatea dupa medie
  initializeaza();  
  
  setVisible(true);
 };

public void actionPerformed(ActionEvent e)
 {if (e.getActionCommand().equals("Introdu cerere"))
  {JFrame f=new Introduce();
  }
  if (e.getActionCommand().equals("Schimba prioritatea"))
  {JFrame f=new Prioritate();
  }
  if (e.getActionCommand().equals("Acorda burse"))
  {JFrame f=new Acorda();
  }
  if (e.getActionCommand().equals("Termina aplicatia"))
  {sfarsit();
  System.exit(0);
  }
  if (e.getActionCommand().equals("Cererile in asteptare"))
  {lm.clear();
  try{
   for (int i=c1.nr()-1;i>=0 ;i--)
	{lm.addElement((Student)c1.elem(i));
	}
     }
  catch(ExceptieCoadaVida ex)
	{}
  }
  if (e.getActionCommand().equals("Bursele acordate"))
  {lm.clear();
  try{
   for (int i=c2.nr()-1;i>=0 ;i--)
        {lm.addElement((Student)c2.elem(i));
        }
     }
  catch(ExceptieCoadaVida ex)
        {System.out.println("Eroare  de a mea");}
  }
 };

private void initializeaza()
  {
 /*p1=new Prioritate_Medie();
   c1=new CoadaP(p1);
   p2=new Prioritate_Medie();
   c2=new CoadaP(p2); */
   try {
  	ObjectInput f1=new ObjectInputStream(new FileInputStream("cereri.dat"));
  	c1=(CoadaP)f1.readObject();
	f1.close();
       }
  catch(FileNotFoundException e)
        {System.out.println("File not found");
	p1=new Prioritate_Medie();
        c1=new CoadaP(p1);
        }
  catch(IOException e)
        {System.out.println("Io error");
	p1=new Prioritate_Medie();
        c1=new CoadaP(p1);
        }
  catch(ClassNotFoundException e)
        {System.out.println("Clasa negasita");
	p1=new Prioritate_Medie();
        c1=new CoadaP(p1);
        }
  try {
        ObjectInput f2=new ObjectInputStream(new FileInputStream("burse.dat"));
        c2=(CoadaP)f2.readObject();
        f2.close();
       }
  catch(FileNotFoundException e)
        {System.out.println("File not found");
	p2=new Prioritate_Medie();
        c2=new CoadaP(p2);
        }
  catch(IOException e)
        {System.out.println("Io error");
	p2=new Prioritate_Medie();
	c2=new CoadaP(p2);
        }
  catch(ClassNotFoundException e)
        {System.out.println("Clasa negasita");
	p2=new Prioritate_Medie();
        c2=new CoadaP(p2);
        }
  }

private void sfarsit()
 {try{ObjectOutput f1=new ObjectOutputStream(new FileOutputStream("cereri.dat"));
      f1.writeObject(c1); f1.close();}
  catch(FileNotFoundException e)
        {System.out.println("File not found");
        }
  catch(IOException e)
        {System.out.println("Io error");
        }
  try{ObjectOutput f2=new ObjectOutputStream(new FileOutputStream("burse.dat"));
      f2.writeObject(c2); f2.close();}
  catch(FileNotFoundException e)
        {System.out.println("File not found");
        }
  catch(IOException e)
        {System.out.println("Io error");
        }
 }
}
