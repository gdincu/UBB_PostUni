import java.io.*;
public class Cauta_Cod extends Cauta implements Serializable
{
	private ICoada c;
	public Cauta_Cod (ICoada cc)
	{
		c = cc;
	}
	public int cauta(Object a,Object o)
	{
	    int nr = c.nr()-1;
	    int t = 0;
	    try
	    {
			while ((nr >= 0) && (t == 0))
		    {
				if ((((Student)(c.elem(nr))).gcod()).equals((String)a)) 
				{
					t = 1;
					o = c.elem(nr);
			    	System.out.println((((Student)(o)).gnume()).toString());
				}
			    nr = nr-1;
		    }
	    }
	    catch(Exception ex)
     	{
			System.out.println(ex.toString());
     	}
		return t;
	}
}	
		
		
	
	
