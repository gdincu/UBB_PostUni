public class Prioritate_Medie implements Compar
{
	public int compara(Object a,Object b)
	{
		if (((Student)a).gmedie()<((Student)b).gmedie())
			return 1;
		else	
	    if (((Student)a).gmedie()>((Student)b).gmedie())
			return -1;
		else 
		    return 0;
	}
}								 
