import java.io.*;
public class EcGr1
{ public static void main(String args[])
  {  String s1,s2;
     int a=0,b=0;
     InputStreamReader stdin =	new InputStreamReader(System.in);
     BufferedReader console =	new BufferedReader(stdin);
     try {System.out.print("coef. lui x:");
	  s1 = console.readLine();
	  a = Integer.parseInt(s1);
	  System.out.print("coef. liber:");
	  s2 = console.readLine();
	  b = Integer.parseInt(s2);
	}
     catch(IOException ioex)
	{ System.out.println("Eroare la intrare");
	  System.exit(1);
	}
     catch(NumberFormatException nfex)
	{ System.out.println("\"" + nfex.getMessage() + "\" nu-i numeric");
          System.exit(1);
	}

     System.out.print("Ecuatia: "+a+"x");

     if (b>=0) System.out.print("+"+b+"=0"); // daca b>=0 atunci se tipareste si semnul +
     else      System.out.print(b+"=0");     // daca b<0  atunci nu se tipareste semnul -
     
     if (a==0)
       if (b==0)
	 System.out.println(" are o infinitate de solutii");
       else
	  System.out.println("  nu are solutii");
     else { double x=-(double)b/a;
	    System.out.print("  are solutia ");
            if (b>=0) System.out.print("-"+b);// daca b>=0 atunci se tipareste si semnul +
            else      System.out.print(-b   );// daca b<0  atunci nu se tipareste semnul -
            System.out.println("/" + a + "="+x);
          }   
   }
}
