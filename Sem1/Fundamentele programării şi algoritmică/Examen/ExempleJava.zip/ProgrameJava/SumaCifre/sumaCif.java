import java.io.*;
public class sumaCif
 { public static long sumaCifre(long x)
    { if (x==0)return 0;
               return x % 10 +sumaCifre(x/10);       
    }  
  
   public static void main(String args[])
    { String s1;
      InputStreamReader stdin = new InputStreamReader(System.in);
      BufferedReader console  = new BufferedReader(stdin);
      long n=0;
      try { System.out.print("dati un numar natural:");
	    s1 = console.readLine();
	    n = Integer.parseInt(s1);
	  }
      catch(IOException ioex)
	  { System.out.println("Input error");
	    System.exit(1);
	  }
      catch(NumberFormatException nfex)
	  { System.out.println("\"" + nfex.getMessage() + 	"\" nu-i natural");
            System.exit(1);
	  }
      System.out.println("suma cifrelor lui "+n+" este "+sumaCifre(n));
    }
 }

