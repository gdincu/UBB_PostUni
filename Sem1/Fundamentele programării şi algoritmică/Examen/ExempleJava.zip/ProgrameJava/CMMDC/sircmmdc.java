import java.io.*;
import java.lang.Math.*;

public class sircmmdc 
{public static long cmmdcR(long a, long b) 
   { while (a!=b)
     if (a>b) a=a-b;
     else     b=b-a;
    return a;  
   } 

 public static void main(String args[])
  { long a=0,b=0,r;
    int  n=0,i;
    long[] div = new long[100];
    String s1;
    InputStreamReader stdin = new InputStreamReader(System.in);
    BufferedReader console  = new BufferedReader(stdin);

    try { System.out.print("cate numere: ");
	     s1 = console.readLine();
	     n  = Integer.parseInt(s1);
	}
    catch(IOException ioex)
	   { System.out.println("Input error");
	     System.exit(1);
	   }
    catch(NumberFormatException nfex)
	    {System.out.println("\"" + nfex.getMessage() + "\" nu toate caracterele sunt cifre");
             System.exit(1);
	    }

    for (i=0; i<n; i++)
      {
       try { System.out.print("alt numar: ");
	     s1 = console.readLine();
	     div[i] = Integer.parseInt(s1);
	   }
       catch(IOException ioex)
	   { System.out.println("Input error");
	     System.exit(1);
	   }
       catch(NumberFormatException nfex)
	    {System.out.println("\"" + nfex.getMessage() + "\" nu toate caracterele sunt cifre");
             System.exit(1);
	    }
    
      }

    a=div[0];
    b=div[1];
    r=cmmdcR(Math.abs(a), Math.abs(b));
    i=2;
    while (i<n) 
      { r=cmmdcR(r,Math.abs(div[i]));
        i++;				//i=i+1
       }
    System.out.print("Cmmdc-ul numerelor date este: ");
    System.out.println(r);
   }
}