import java.io.*;
import java.lang.Math.*;
public class cmmdcRecDif 
{public static long cmmdcR(long a, long b) 
  { if (a>b) return cmmdcR(a-b,b);
    if (a<b) return cmmdcR(a,b-a);
    return a;  
  }

 public static void main(String args[])
  { long a=0,b=0,r;
    String s1;
    InputStreamReader stdin = new InputStreamReader(System.in);
    BufferedReader console  = new BufferedReader(stdin);
    try { System.out.print("primul numar: ");
	  s1 = console.readLine();
	  a = Integer.parseInt(s1);
	}
    catch(IOException ioex)
	{ System.out.println("Input error");
	  System.exit(1);
	}
    catch(NumberFormatException nfex)
	{System.out.println("\"" + nfex.getMessage() + 	"\" is not numeric");
         System.exit(1);
	}
    try { System.out.print("al 2-lea numar: ");
	  s1 = console.readLine();
	  b = Integer.parseInt(s1);
	}
    catch(IOException ioex)
	{ System.out.println("Input error");
	  System.exit(1);
	}
    catch(NumberFormatException nfex)
	{System.out.println("\"" + nfex.getMessage() + 	"\" is not numeric");
         System.exit(1);
	}
    System.out.print("Cmmdc-ul numerelor "+a+" si "+b+" este: ");
    System.out.println(cmmdcR(Math.abs(a),Math.abs(b)));

 }

}
