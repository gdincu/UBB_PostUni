import java.util.Scanner;
import java.text.NumberFormat;

public class fractie
{
   public static void main( String args[] )
   {
      Scanner input = new Scanner( System.in );

      int k, m, s;
      int n;
      
      System.out.print( "Enter k: " );
      k = input.nextInt();

      System.out.print( "Enter m: " );
      m = input.nextInt();
      
      System.out.print( "Enter n: " );
      n = input.nextInt();
      
      System.out.print("0.");
      int i=1;
      while (i<=n){
         k        =k*10;
         int res = k % m;
         int cat = k / m;
         System.out.print(cat);
         k=k-cat*m;
         i++;
      }

   }
}