import javax.swing.*;
import java.awt.*;
import java.lang.*;

class Calc extends JFrame implements java.awt.event.ActionListener
{JTextField numar;
 JLabel n=new JLabel("Dati numarul: ");
 int putere=1;
 JTextField rezultat;
 Checkbox radical;
 JPanel p=new JPanel(); // declarare panou
 
 public Calc()
	{ super("Calculator");
	  //JPanel p=new JPanel();
	  p.setLayout(new GridLayout(5,1));
	  JPanel p1=new JPanel();
	  //JLabel n=new JLabel("Dati numarul: ");
	  numar=new JTextField(10);
	  p1.add(n);
	  p1.add(numar);
	  p.add(p1);

	  JPanel p2=new JPanel();
	  JLabel pwr=new JLabel("La ce putere?");
	  JRadioButton b1=new JRadioButton("unu");
	  JRadioButton b2=new JRadioButton("doi");
	  JRadioButton b3=new JRadioButton("trei");
	  ButtonGroup buton=new ButtonGroup();
	  buton.add(b1);
	  buton.add(b2);
	  buton.add(b3);
	  b1.addActionListener(this);
	  b2.addActionListener(this);
	  b3.addActionListener(this);
	  p2.add(pwr); 
	  p2.add(b1);
	  p2.add(b2);
	  p2.add(b3);
	  p.add(p2);
	
	  JPanel p3=new JPanel();
	  radical=new Checkbox("Radacina Patrata ");
						//	  radical.addActionListener(this);
      p3.add(radical);
      p.add(p3);

	  JPanel p4=new JPanel();
	  JButton C=new JButton("Calculeaza");
	  C.addActionListener(this);
	  p4.add(C);
	  p.add(p4);
	
	  JPanel p5=new JPanel();
	  JLabel r=new JLabel("Rezultatul este ");
	  String zero=new String("0");
	  rezultat=new JTextField(zero,20);
	  rezultat.setEditable(false);
	  p5.add(r);
	  p5.add(rezultat);
	  p.add(p5);
	  getContentPane().add(p);
}

 public void actionPerformed(java.awt.event.ActionEvent e)
	{if (e.getActionCommand()=="unu") putere=1;
	 if (e.getActionCommand()=="doi") putere=2;
	 if (e.getActionCommand()=="trei") putere=3;
	 if (e.getActionCommand()=="Calculeaza")
		{try {int i=Integer.parseInt(numar.getText());
			  int prod=1;
        	  for(int j=1;j<=putere;j++) prod*=i;
			  double proddouble=prod;
			  if (radical.getState()) 
			    {   if (prod>=0)
			    	proddouble=Math.sqrt(prod);
			    	else JOptionPane.showMessageDialog(numar,"Numar negativ","EROARE",JOptionPane.ERROR_MESSAGE);
			    }
              rezultat.setText(""+proddouble);
		     }
		catch(NumberFormatException a)
		{JOptionPane.showMessageDialog(numar,"Numar nu e intreg","EROARE",JOptionPane.ERROR_MESSAGE);}
		}
	}
}