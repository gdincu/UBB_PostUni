
public class Ecuatie1{

  static public void main(String args[]){
     double a=12.5, b=5;
     if(a!=0) System.out.println("ecuatia are solutia "+(-b/a));
     else if (b!=0) System.out.println("ecuatia nu are solutii");
          else      System.out.println("ecuatia are o infinitate de solutii"); 

  }

}
