import java.io.*;

public class Maxim 
{ public static void main(String args[])
  { int s[] = new int [100];                  	// declarare tablou
    String sirCar;									// sirCar e sir de caractere
    InputStreamReader tastatura = new InputStreamReader(System.in); // stream(flux) de intrare
    BufferedReader 		 ecran  = new BufferedReader(tastatura);	// stream(flux) de iesire
    int n=0;									// n este dimensiunea efectiva a secventei
    try 
    { 		System.out.print("cate numere?: ");
	  		sirCar = ecran.readLine();
	  		n  = Integer.parseInt(sirCar);
	}
    catch(IOException ioex)
	{ System.out.println("Eroare generala de intrare");
	  System.exit(1);
	}
    catch(NumberFormatException nfex)
	{System.out.println("\"" + nfex.getMessage() + 	"\" nu e numeric");
     System.exit(1);
	}

    for (int i=0;i<n;i++)
     { s[i]=0;
       try {	System.out.print("s["+i+"]=");
	    		sirCar = ecran.readLine();
	    		s[i] = Integer.parseInt(sirCar);
       	   }
       catch(IOException ioex)
       		{ System.out.println("Eroare generala de intrare");
       		  System.exit(1);
       		}
       catch(NumberFormatException nfex)
       		{System.out.println("\"" + nfex.getMessage() + 	"\" nu e numeric");
             System.exit(1);
	        }
     }									// terminat intrare date

    									// prelucrare
    System.out.println("secventa este:");// afisare secventa
    for (int i=0;i<n; i++)  System.out.print(s[i]+" ");
    System.out.println();				// se trece la rand nou

    int max=s[0];						// determinare maxim
    for (int i=1;i<n;i++)
      if (s[i]>max) max=s[i];
    System.out.println("Maximul din secventa este: " + max);  // afisare maxim
  }
}

