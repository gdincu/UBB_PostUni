class StivaD implements IStiva
{
	class Nod
	{
		private Object inf;
		private Nod leg;
		public Nod(Object i,Nod l)
		{
		    inf=i;
		    leg=l;
		}
	}
	private Nod cap;
	public StivaD()
	{
		cap=null;
	}
	public void adauga(Object a)
	{
        Nod aux=new Nod(a,cap);
	cap=aux;
	}
	public boolean eVida()
	{
	    if (cap==null) return true;
		else return false;
	}
	public Object scoate() throws ExceptieStivaVida
	{
	try {	Object aux=new Object();
		aux=cap.inf;
		cap=cap.leg;
		return aux;}
	catch (Exception e)
	{throw new ExceptieStivaVida("Stiva vida!!!");}
	}
	public Object getCap() throws ExceptieStivaVida
	{
	try{	return cap.inf;}
	catch(Exception e)
        {throw new ExceptieStivaVida("Stiva vida!!!");}
	}
}
