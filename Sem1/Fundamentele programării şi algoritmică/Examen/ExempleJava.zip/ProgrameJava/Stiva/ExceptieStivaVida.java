public class ExceptieStivaVida extends Exception
{
        private String msg;
        public ExceptieStivaVida(String m)
        {
                msg=m;
        }
        public String toString()
        {
                return msg;
        }
}
