class StivaS implements IStiva
{
        private Object[] elem;
        private int cap;
	public StivaS()
	{
		cap=0;
	}
	public void adauga(Object a)
	{
		cap=cap+1;
		Object[] temp=new Object[cap];
		for (int i=0;i<cap-1;i++) temp[i]=elem[i];
		elem=temp;
		elem[cap-1]=a;
	}
	public Object scoate() throws ExceptieStivaVida
    	{
		try{Object aux=elem[cap-1];
		cap=cap-1;
		return aux;}
		catch(Exception e)
		{throw new ExceptieStivaVida("Stiva vida!!!");}
	}	
	public boolean eVida()
	{
		if (cap==0) return true;
		else return false;
	}
	public Object getCap() throws ExceptieStivaVida
	{
	try{	return elem[cap-1];}
	catch(Exception e)
                {throw new ExceptieStivaVida("Stiva vida!!!");}

	}
}
