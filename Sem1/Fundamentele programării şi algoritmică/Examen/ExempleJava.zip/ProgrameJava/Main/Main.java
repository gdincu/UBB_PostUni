import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.GregorianCalendar;

public class Main {
	public static void main(String[] args) {
		// print error and exit application if there weren't 2 arguments received in the command line
		if (args.length != 2) {
			System.err.println("Please enter both the year and the number of the day in that year.");
			System.exit(1);
		}

		// initialize variables
		int year = 0;
		int dayOfYear = 0;

		// read and parse the year from the command line
		try {
			year = Integer.parseInt(args[0]);
		} catch (NumberFormatException e) {
			System.err.println("The value entered for the year is not an integer number");
			System.exit(1);
		}
		
		// read and parse the day number from the command line
		try {
			dayOfYear = Integer.parseInt(args[1]);
		} catch (NumberFormatException e) {
			System.err.println("The value entered for the day of the year is not an integer number");
			System.exit(1);
		}

		// get an instance of the Calendar class
		Calendar calendar = GregorianCalendar.getInstance();
		// set the year and the day of the year fields, received from the command line
		calendar.set(Calendar.YEAR, year);
		calendar.set(Calendar.DAY_OF_YEAR, dayOfYear);

		// get the maximum number of days constant from that year (365 in normal years and 366 in leap years)
		final int MAX_DAYS_IN_YEAR = calendar.getActualMaximum(Calendar.DAY_OF_YEAR);
		// make sure the day of year read from the command line is not bigger than the maximum day of that year
		if (dayOfYear > MAX_DAYS_IN_YEAR) {
			System.err.println("There are only " + MAX_DAYS_IN_YEAR + " in the year " + year);
			System.exit(1);
		}

		// get an instance of a date formatter with the desired format
		SimpleDateFormat sdf = new SimpleDateFormat("dd-MM-yyyy");

		// print the response
		System.out.println("The day number " + dayOfYear + " of the year "
				+ year + " represents the date: "
				+ sdf.format(calendar.getTime()));
	}
}
