import java.io.*;
public class Perfect {
	public static long Suma (long n){
		long i, sum=1;
		i=2;
		{while (i<=n/2)
		  {if (n % i ==0)
			  sum+=i;
		   i++;
		  }
		}
		return sum;
	}
	
	public static void main(String[] args) {
		long n=0,i;
		String s;
	    InputStreamReader stdin = new InputStreamReader(System.in);
	    BufferedReader console  = new BufferedReader(stdin);
	    try 
	    { System.out.print("numarul:");
		  s = console.readLine();
		  n = Integer.parseInt(s);
		}
	    catch(IOException ioex)
		{ System.out.println("Input error");
		  System.exit(1);
		}
	    catch(NumberFormatException nfex)
		{System.out.println("\"" + nfex.getMessage() + 	"\" is not numeric");
	         System.exit(1);
		}
	    boolean b=true;
	    i=n+1;
	    while (b)
	     {	//System.out.println(Suma(i));
	    	if (Suma(i)==i)
                {System.out.println(i + " e perfect");
                 b=false;
                }
	        i++;
	     }
  }
}
