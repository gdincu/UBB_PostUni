class Punct{
  int x, y;				//linia 2
  static int nrPuncte=0;		//linia 3
  Punct(int xx, int yy){
    x=xx; y=yy;
    nrPuncte++;
  }
}

class TestPunct{
  public static void main(String args[]){
    Punct p1=new Punct(10, 10);
    Punct p2=new Punct(20, 20);
    Punct p3=new Punct(30, 30);
    System.out.println(Punct.nrPuncte);
  }
} 
