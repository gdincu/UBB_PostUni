import java.io.*;
public class GoldBach {
	
	public static boolean Prim (long n){
		long i;
		i=2;
		while (i<=Math.sqrt(n)+1 && (n % i) !=0)
		  if (i==2)
			  i++;
		   else i+=2;
		if (i>Math.sqrt(n)+1)
			return true;
		else
			return false;
	}
	
	public static void main(String[] args) {
		long n=0,i;
		String s;
	    InputStreamReader stdin = new InputStreamReader(System.in);
	    BufferedReader console  = new BufferedReader(stdin);
	    try 
	    { System.out.print("numarul:");
		  s = console.readLine();
		  n = Integer.parseInt(s);
		}
	    catch(IOException ioex)
		{ System.out.println("Input error");
		  System.exit(1);
		}
	    catch(NumberFormatException nfex)
		{System.out.println("\"" + nfex.getMessage() + 	"\" is not numeric");
	         System.exit(1);
		}
	    for(i=2;i<=n / 2; i++)
	     {	if (Prim(i)&& Prim (n-i))
                System.out.println(n + "="+i+"+"+(n-i));
	     }
	}

}
