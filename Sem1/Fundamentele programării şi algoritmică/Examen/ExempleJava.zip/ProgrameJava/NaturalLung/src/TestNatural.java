﻿public class TestNatural {
	
	public static int  SECVENTA(int n, NATURAL t[], int i)
	  //i este dat astfel incat X[i] este par. Se obtine cel mai mare j pentru}
	  // care secventa   X[i..j] contine numai numere pare, j se va returna ca 
	  // valoare a functiei
	{ int j=i;
	  while ( j<n-1 && t[j+1].Modulo2() )   j++;
	  return j;
	}

	public static void LONGSECV (int n, NATURAL t[])
    {// Se obtin indicii s si  f pentru care secventa 
	 // X[s..f]  contine numai numere prime si e cea mai lunga 
	 int i,j,s,f;
     s=0;
     f=-1;                        //codifica "Sirul nu contine numere pare"
     i=0;
     j=-1;
      while  (i<n) 
       { while (i<n && !t[i].Modulo2()) i++; //se sare peste numerele impare
         if (i<n)  
             {j=SECVENTA(n,t,i);
              if (j-i > f-s)
              { s=i;
                f=j;       					//s-a gasit o secventa mai lunga
              }
              i=j+2;  
             }  
                                //pozitie pentru o noua secventa
       }
     if (f==-1)
           {System.out.println();
    	    System.out.println("Nu exista numere pare");
           }
     else {System.out.println();
    	   System.out.println("Secventa dorita este:");
           for (i=s;i<=f;i++) 
        	   {t[i].Afisare();
        	    System.out.println();
        	   }
           }
     
      
      
    }
	public static void main(String[] args) {
	NATURAL a  =new NATURAL("169");
	NATURAL Rad=new NATURAL();
	Rad.Radical(a);
	System.out.println();
	System.out.print("Rad(");a.Afisare();System.out.print(")=");
	Rad.Afisare();
	System.out.println();
	if (Rad.MaiMareEgal(a)) System.out.println("rad e mai mare ca a");
	else  System.out.println("a e mai mare ca rad");
	NATURAL b = new NATURAL("111111");
	NATURAL Suma= new NATURAL();
	Suma.Aduna(a,b);
	System.out.print("suma este:");
	Suma.Afisare();
	
	NATURAL t []=new NATURAL[10];
	t[0]=new NATURAL ("1234561");
	t[1]=new NATURAL ("11111111111111112122222222222222222222222222222222222222222");
	t[2]=new NATURAL ("2222222221121222222222222222222222222222222");
	t[3]=new NATURAL ("00000000000044444444444444441444444444444444444444444444444444444444444444444444");
    t[4]=new NATURAL ("1234561");
	t[5]=new NATURAL ("1112121");
	t[6]=new NATURAL ("2222222226812");
	t[7]=new NATURAL ("44444444441010");
	t[8]=new NATURAL ("222222222681011");
	t[9]=new NATURAL ("4444444444121011");
	
	for (int i=0; i<10;i++)
	  {System.out.println();
	   System.out.print("t["+i+"]=");
	   t[i].Afisare();
	  }
	
	LONGSECV(10,t);
	
 }
  
}
