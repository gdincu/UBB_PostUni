import java.io.*;
public class fact
 { public static void main(String args[])
    { long f=1;
      String s1;
      InputStreamReader stdin = new InputStreamReader(System.in);
      BufferedReader console  = new BufferedReader(stdin);
      int n=0;
      try { System.out.print("dati un numar natural:");
	    s1 = console.readLine();
	    n = Integer.parseInt(s1);
	  }
      catch(IOException ioex)
	  { System.out.println("Input error");
	    System.exit(1);
	  }
      catch(NumberFormatException nfex)
	  { System.out.println("\"" + nfex.getMessage() + 	"\" nu-i natural");
           System.exit(1);
	  }
      for(int i=2; i<=n; i++)
	      f*=i;
      System.out.println(n+"!="+f);
    }
 }
