import javax.swing.*;
import java.awt.*;
import java.lang.*;
class Invers extends  JFrame implements java.awt.event.ActionListener
{ JLabel     litere;
  JTextField text;
  JTextField text1;
  JButton  schimba; 
   public Invers()
	{ super("Schimbator");
	  JPanel p = new JPanel();
	  p.setLayout(new GridLayout(3,1));
	  JPanel p1 = new JPanel();
	  litere = new JLabel ("Baga Textul");
	  text= new JTextField(20);
	  p1.add(litere);
	  p1.add(text);	  p.add(p1);
	  JPanel p2 = new JPanel();
	  schimba = new JButton("INVERS");
	  schimba.addActionListener(this);
	  p2.add(schimba);
	  p.add(p2);
	  JPanel p3 = new JPanel();
	  JLabel Inv = new JLabel ("OK");
	  text1= new JTextField(20);
	  text1.setEditable(false);
	  p3.add(Inv);
	  p3.add(text1);
	  p.add(p3);
	  getContentPane().add(p);
	  
    }

  


 public void actionPerformed(java.awt.event.ActionEvent e)
	{if (e.getActionCommand()=="INVERS")
	     { String VechiText = text.getText();
           String tt="";
           for (int i=VechiText.length()-1; i>=0; i--)
	          tt+=VechiText.charAt(i);
	       text1.setText(""+tt);     
	       
	     }
        	     
		
	}
}

