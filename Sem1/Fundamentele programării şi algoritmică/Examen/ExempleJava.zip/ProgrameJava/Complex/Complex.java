import java.lang.Math;
public class Complex {
	private float	real;					//partea reala
	private float	img;					//coef partii imaginare 
	public Complex(float real,float img){	//constructor de initializare cu parametri
		this.real=real;
		this.img=img;
	}
	public Complex(){
	}
	
	public float getReal() {			//accesor de tip get pentru p. reala
		return real;
	}
	public void setReal(float real) {   //accesor de tip set pentru p. reala
		this.real = real;
	}
	public float getImg() {				//accesor de tip get pentru coef.p.imag
		return img;
	}
	public void setImg(float img) {		//accesor de tip set pentru coef.p.imag
		this.img = img;
	}
	public void Suma(Complex c){		//this=this+c
		real=real+c.real;
		img =img+c.img;
	}
	public Complex Suma(Complex c1, Complex c2){ 		//this=c1+c2
		this.real=c1.real+c2.real;
		this.img =c1.img+c2.img;
		return this;
	}
	public Complex Produs(Complex c1, Complex c2){
		this.real =c1.real*c2.real-c1.img*c2.img;
		this.img=c1.real*c2.img+c1.img*c2.real;
		return this;
	}
    public double Modul(){
                return Math.sqrt(real*real+img*img);
        }
        
    public static void Swap (Complex a, Complex b){   //de ce nu merge???
    	Complex temp	=a;
    	a           	=b;
    	b				=temp;
    }
}
