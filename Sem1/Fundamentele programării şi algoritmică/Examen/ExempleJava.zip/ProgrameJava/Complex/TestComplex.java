public class TestComplex {
	public static void Afisare(Complex c){
		if(c.getReal()==0.0)
			if(c.getImg()==0.0)
				System.out.println("z=0");
			else
				System.out.println("z="+c.getImg()+"i");
		else
			if(c.getImg()==0.0)
				 System.out.println("z="+c.getReal()+"i");
			else System.out.println("z="+c.getReal()+"+"+c.getImg()+"i");
	}
	public static void main(String[] args) {
		Complex c1=new Complex(1,1);
		System.out.println(c1.Modul()+ " ");
		Complex c2=new Complex(3,4);
		System.out.println(c2.Modul()+ " ");
		Complex s=new Complex();
		c1.Suma(c2);
		Afisare(c1);
		s.Suma(c1,c2);
		
		Afisare(c1);
		Afisare(s);
		c1.setImg(0);
		c1.setReal(0);
		s.Produs(c1, c2);
        Afisare(s);
        System.out.println("valoarea lui c1:");
        Afisare(c1);
        System.out.println("valoarea lui c2:");
        Afisare(c2);
        Complex.Swap(c1,c2);
        Afisare(c1);
        Afisare(c2);
    	System.out.println("\n program terminat");
        
	}

}
