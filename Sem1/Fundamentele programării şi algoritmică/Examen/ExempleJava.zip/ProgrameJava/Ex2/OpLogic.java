public class OpLogic
{public static void main(String args[])
  { byte a=0;
    System.out.println("Primul if");
    if ((a!=0) && (1/a<1))
  	 System.out.println("Ambele conditii sunt adevarate");
    else
  	 System.out.println("O conditie este falsa");
    System.out.println("Al doilea if");
    if ((1/a<1) && (a!=0))
  	 System.out.println("Ambele conditii sunt adevarate");
    else
  	 System.out.println("O conditie este falsa");
  }
}
