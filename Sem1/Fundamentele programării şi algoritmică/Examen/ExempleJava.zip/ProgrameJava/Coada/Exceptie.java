class Exceptie extends Exception
{
        private String msg;
        public Exceptie(String m)
        {
                msg=m;
        }
        public String toString()
        {
                return msg;
        }
}
