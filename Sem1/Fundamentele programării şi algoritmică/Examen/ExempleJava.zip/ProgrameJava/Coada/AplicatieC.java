public class AplicatieC
{
	public static void main(String a[])
	{
	try{	String a1=new String("ab");
		String a2=new String("cd");
		String a3=new String("ef");
		ICoada s2=new CoadaD();
		s2.adauga(a1);
		s2.adauga(a2);
		s2.adauga(a3);	
		while (!s2.eVida())
			System.out.print(((String)s2.scoate()).toString()+" ");
		System.out.println();
		s2.scoate();
		}
	catch(Exceptie e)
        {System.out.println(e.toString());}
	try{
		ICoada s1=new CoadaS();
		Integer i1=new Integer(1);
		s1.adauga(i1);
        	Integer i2=new Integer(2);
		s1.adauga(i2);
        	Integer i3=new Integer(3);
		s1.adauga(i3);
		while (!s1.eVida())
          		  System.out.print(((Integer)s1.scoate()).toString()+" ");
     		System.out.println();	
		}
	catch(Exceptie e)
	{System.out.println(e.toString());}
    }
}