class CoadaS implements ICoada
{
        private Object[] elem;
        private int nr;
	public CoadaS()
	{
		nr=0;
	}
	public void adauga(Object a)
	{
		nr=nr+1;
		Object[] temp=new Object[nr];
		for (int i=0;i<nr-1;i++) temp[i]=elem[i];
		elem=temp;
		elem[nr-1]=a;
	}
	public Object scoate() throws Exceptie
    	{
		try {Object aux=elem[0];
		nr=nr-1;
		Object[] temp=new Object[nr];
                for (int i=0;i<nr;i++) temp[i]=elem[i+1];
                elem=temp;
		return aux;}
		catch (Exception e)
		{throw new Exceptie("Coada vida!!!");
		}
	}	
	public boolean eVida()
	{
		if (nr==0) return true;
		else return false;
	}
	public Object getPrim() throws Exceptie 
	{
		try {return elem[0];}
		catch (Exception e)
		{throw new Exceptie("Coada vida!!!");}
	}
	public Object getUltim() throws Exceptie
	{	
		try {return elem[nr-1];}
                catch (Exception e)
                {throw new Exceptie("Coada vida!!!");}
		
	}
}