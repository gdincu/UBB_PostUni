class CoadaD implements ICoada
{
	class Nod
	{
		private Object inf;
		private Nod leg;
		public Nod(Object i,Nod l)
		{
		    inf=i;
		    leg=l;
		}
	}
	private Nod prim;
	private Nod ultim;
	public CoadaD()
	{
		prim=null;
		ultim=null;
	}
	public void adauga(Object a)
	{
        if ((prim==null)&&(ultim==null))
		{Nod aux=new Nod(a,null);
		prim=aux;
		ultim=aux;
		}
	else {Nod aux=new Nod(a,null);
	      ultim.leg=aux;
	      ultim=aux;
	     }
	}
	public boolean eVida()
	{
	    if (prim==null) return true;
		else return false;
	}
	public Object scoate() throws Exceptie
	{
	 try{Object aux=new Object();
		aux=prim.inf;
		prim=prim.leg;
		return aux;}
	catch (Exception e)
	{throw new Exceptie("coada vida!!!");}
	}
	public Object getPrim() throws Exceptie
	{
	try{	return prim.inf;}
	catch(Exception e)
	{throw new Exceptie("coada vida!!!");}
	}
	public Object getUltim() throws Exceptie
        {
        try{    return ultim.inf;}
        catch(Exception e)
        {throw new Exceptie("coada vida!!!");}
        }

}
