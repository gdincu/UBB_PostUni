interface ICoada
{
	void adauga(Object a);
	Object scoate() throws Exceptie;
	boolean eVida();
	Object getPrim() throws Exceptie;
 	Object getUltim() throws Exceptie;
}