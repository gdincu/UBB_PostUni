class Rational
{ private int a;//Specificatie: Rational=a/b ireductibile, a,b intregi
  private int b;

 public Rational(int x,int y)
 {a=x;
  b=y;
  Simplifica();
 }

 public Rational(Rational x)
 {a=x.a;
  b=x.b;
 }

 public Rational(int x)
 {a=x;
  b=1;
 }

 public static int Cmmdc(int x,int y)
 {if(x==y) return x;
	else if (x>y) return Cmmdc(x-y,y);
		else  return Cmmdc(x,y-x);

 }

 private void Simplifica()
 {int x=Math.abs(a),y=Math.abs(b);
  int temp=Cmmdc(x,y);
  a/=temp;
  b/=temp;
 }

 public void Aduna(Rational x)
 {int auxa=a*x.b+b*x.a;
  int auxb=b*x.b;
  a=auxa; b=auxb;
  Simplifica();
 }
 
 public void Scade(Rational x)
 {int auxa=a*x.b-b*x.a;
  int auxb=b*x.b;
  a=auxa; b=auxb;
  Simplifica();
 }

 public void Inmulteste(Rational x)
 {a*=x.a;
  b*=x.b;
  Simplifica();
 }

 public Rational Invers()
 {Rational aux=new Rational(b,a);
  return aux;
 }

 public void Imparte(Rational x)
 {Inmulteste(x.Invers());
 }

//exemplu de operatie care apartine clasei...
 public static Rational suma(Rational x,Rational y)
 {Rational z=new Rational(x);
  z.Aduna(y);
  return z;
 }
 public boolean esteZero()
  { if (a==0) return true;
              return false;
  } 


public void Afiseaza()
 { if (b==1)
      System.out.print(a);
   else 
      System.out.print(a+"/"+b);
 }
}

class Aplicatie
 { public static void main(String aa[])
   {Rational a=new Rational(1,2);
    Rational b=new Rational(1,3);
    Rational c=new Rational(8,3);
    Rational d=new Rational(3,2);
    Rational e=new Rational(4,3);
    Rational f=new Rational(49,6);

    System.out.println("sistemul de 2 ecuatii cu 2 nec=");
    a.Afiseaza();System.out.print("X+");b.Afiseaza();System.out.print("Y=");c.Afiseaza();System.out.println();
    d.Afiseaza();System.out.print("X+");e.Afiseaza();System.out.print("Y=");f.Afiseaza();System.out.println();
    Rational delta=new Rational(a);
    delta.Inmulteste(e);
    Rational temp =new Rational(b);
    temp.Inmulteste(d);
    delta.Scade(temp);
    System.out.print("delta=");delta.Afiseaza();System.out.println();


    Rational delta1=new Rational(c);
    delta1.Inmulteste(e);
    Rational temp1 =new Rational(b);
    temp1.Inmulteste(f);
    delta1.Scade(temp1);
    System.out.print("delta1=");delta1.Afiseaza(); System.out.println();
    
    Rational delta2=new Rational(a);
    delta2.Inmulteste(f);
    Rational temp2 =new Rational(c);
    temp2.Inmulteste(d);
    delta2.Scade(temp2);
    System.out.print("delta2=");delta2.Afiseaza(); System.out.println();

    if (!delta.esteZero())
       { Rational x= new Rational(delta1);
         x.Imparte(delta);
         Rational y= new Rational(delta2);
         y.Imparte(delta);
         System.out.print("x=");x.Afiseaza();System.out.println();
         System.out.print("y=");y.Afiseaza();System.out.println();
        }
    else if (delta1.esteZero() && delta2.esteZero())
              System.out.println("sistem nedeterminat");
         else System.out.println("sistem incompatibil");  
         
 }
}