public class OrdDiagPrinc
{ public static void main(String args[])
   { int a[][]={{2,1,4,7},{3,5,1,8},{2,5,1,9},{3,2,5,8}};
     boolean ordonat;
     for(int i=0; i<a.length; i++)
       { for(int j=0; j<a[i].length; j++)
	   System.out.print(a[i][j]+" ");
	 System.out.println("");
       }  
     do 
      {ordonat=true;	
       for(int i=0; i<a.length-1; i++)
	 if (a[i][i]>a[i+1][i+1])
               {  int aux    =a[i][i];
	          a[i][i]    =a[i+1][i+1];
	          a[i+1][i+1]=aux;
	          ordonat=false;
	       }
      } while (!ordonat);
     System.out.println("Matricea cu diagonala ordonata:");  	
     for(int i=0; i<a.length; i++)
       { for(int j=0; j<a[i].length; j++)
	   System.out.print(a[i][j]+" ");
	 System.out.println("");
       }  
   }
}
