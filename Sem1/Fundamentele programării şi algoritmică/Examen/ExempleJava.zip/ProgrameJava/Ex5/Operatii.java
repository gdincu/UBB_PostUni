//import java.lang.Math.*;
public class Operatii
{ public static void main(String args[])
   { double a=12, b=5, r=0,r1=0;
     char operator=' ';
     try {System.out.print("Introduceti operatorul(+-*/^):");
	  operator=(char)System.in.read();
         }
    catch(Exception e){}
    switch (operator) 
     {	case '+': r=a+b; break;
	case '-': r=a-b; break;
	case '*': r=a*b; break;
	case '/': r=a/b; break;
        case '^': r=Math.pow(a,b);
                  r1=Math.exp(b*Math.log(a));break;
	default: System.out.println("Operator invalid");
	 	 System.exit(1);
     }		
    System.out.println(a+" "+operator+" "+b+" = "+r);
    if (r1!=0.0) System.out.println("r1="+r1);
   }
}
