package demo.steps.serenity;

import demo.pages.DictionaryPage;
import demo.pages.ResultPage;
import net.thucydides.core.annotations.Step;
import net.thucydides.core.annotations.StepGroup;

import static org.hamcrest.MatcherAssert.assertThat;
import static org.hamcrest.Matchers.containsString;
import static org.hamcrest.Matchers.hasItem;

public class ResultPageSteps {

    ResultPage resultPage;

    @Step
    public void should_see_definition(String definition) {
        assertThat(resultPage.getDefinitions(), hasItem(containsString(definition)));
    }


}