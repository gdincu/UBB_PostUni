package demo.features.search;

import demo.steps.serenity.DictionaryPageSteps;
import demo.steps.serenity.ResultPageSteps;
import net.serenitybdd.junit.runners.SerenityParameterizedRunner;
import net.serenitybdd.junit.runners.SerenityRunner;
import net.thucydides.core.annotations.Issue;
import net.thucydides.core.annotations.Managed;
import net.thucydides.core.annotations.Pending;
import net.thucydides.core.annotations.Steps;
import net.thucydides.junit.annotations.UseTestDataFrom;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.openqa.selenium.WebDriver;

@RunWith(SerenityParameterizedRunner.class)
@UseTestDataFrom("src/test/resources/features/search/SearchData.csv")
public class SearchByKeywordStoryCSV {

    @Managed(uniqueSession = true)
    public WebDriver webdriver;

    @Steps
    public DictionaryPageSteps dictSteps;

    @Steps
    public ResultPageSteps steps;

    String word, description;


    @Issue("#WIKI-1")
    @Test
    public void searching_by_keyword_should_display_the_corresponding_article() {
        dictSteps.is_the_home_page();
        dictSteps.looks_for(word);
        steps.should_see_definition(description);

    }



} 