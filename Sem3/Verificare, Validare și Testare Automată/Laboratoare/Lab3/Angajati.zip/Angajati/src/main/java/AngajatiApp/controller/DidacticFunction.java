package AngajatiApp.controller;

public enum DidacticFunction {
	ASISTENT, LECTURER, TEACHER, CONFERENTIAR;
}
