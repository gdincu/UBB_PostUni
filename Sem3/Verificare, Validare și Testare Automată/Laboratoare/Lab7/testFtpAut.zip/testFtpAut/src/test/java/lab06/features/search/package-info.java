
@Narrative(
        title = "Search for definitions",
        text = {"In order to impress people",
                "As a party goer",
                "I want to be able to look up the meaning of unusual and impressive words"},
        cardNumber = "#123"
)
package lab06.features.search;

import net.thucydides.core.annotations.Narrative;
