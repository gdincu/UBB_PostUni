package lab06.pages;

import net.serenitybdd.core.annotations.findby.FindBy;
import net.serenitybdd.core.pages.WebElementFacade;
import net.thucydides.core.annotations.DefaultUrl;
import net.thucydides.core.pages.PageObject;
import org.openqa.selenium.By;

import java.util.List;
import java.util.stream.Collectors;

//corespunde paginii care ii arata utilizatorului contul sau
public class AccountPage extends PageObject {

    //vom interactiona cu butonul de logout si vom verifica daca am ajuns in aceasta pagina

    //butonul de logout il identificam dupa xpath deoarece nu am gasit pentru el un mijloc mai simplu
    @FindBy(xpath = "//*[@id=\"StatusbarForm\"]/a[3]/img")
    private WebElementFacade logoutButton;

    //am mai găsit 2 elemente mai usor de identificat care contin numele utilizatorului, de exemplu, TextBox-ul care contine numele directorului in care ne aflam, situat in artea e stanga sus a paginii
    //nu putem sa ne folosim de nume in identificarea sa, deoarece nu e unicul element cu numele "directory", de aceea folosim si pentru acesta xpath
    @FindBy(xpath = "//*[@id=\"toptable\"]/tbody/tr/td[2]/input")
    private WebElementFacade currentDir;

    //pe butonul de logout vom da click
    public void click_logout() {
        logoutButton.click();
    }

    //vom scoare valoarea directorului curent, pentru a verifica in steps daca ea se termina cu numele utilizatorului
    public String get_currentDir() {
        return currentDir.getValue();
    }

}