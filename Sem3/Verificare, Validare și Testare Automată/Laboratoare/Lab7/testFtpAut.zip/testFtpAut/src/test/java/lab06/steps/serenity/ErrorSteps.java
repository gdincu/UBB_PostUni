package lab06.steps.serenity;

import lab06.pages.ErrorPage;
import lab06.pages.LogoutPage;
import net.thucydides.core.annotations.Step;

import static org.hamcrest.MatcherAssert.assertThat;
import static org.hamcrest.Matchers.containsString;
import static org.hamcrest.Matchers.hasItem;


//in aceasta clasa definim pasii de urmat in pagina de raportare a erorii
public class ErrorSteps {

    //avem nevoie de pagina de raportare a erorii
    ErrorPage errorPage;

    //in acest pas vom verifica daca se afla testul "error" in locul identificat de pe pagina
    @Step
    public void should_see_text(String text) {
        assertThat(errorPage.get_textError(), hasItem(containsString(text)));
    }

}