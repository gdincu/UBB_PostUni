package lab06.features.search;

import lab06.steps.serenity.AccountSteps;
import lab06.steps.serenity.LoginSteps;
import lab06.steps.serenity.LogoutSteps;
import net.serenitybdd.junit.runners.SerenityRunner;
import net.thucydides.core.annotations.Issue;
import net.thucydides.core.annotations.Managed;
import net.thucydides.core.annotations.Steps;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.openqa.selenium.WebDriver;

//acest fisier se executa
@RunWith(SerenityRunner.class)
public class ValidLoginTest {

    @Managed(uniqueSession = true)
    public WebDriver webdriver;

    //vom folosi pasii corespunzatori paginii de login si account
    @Steps
    public LoginSteps login;

    @Steps
    public AccountSteps account;

    @Steps
    public LogoutSteps logout;

    @Issue("#login-1")
    @Test
    public void validLogintest() {
        //pornim de la pagina de login
        login.is_the_home_page();
        //se introduc toate datele si se da click pe butonul de Login
        login.enters_data_and_click_login("linux.scs.ubbcluj.ro","vvta","2019vvta");
        //verificam ca am ajuns in contul utilizatorului vvta
        account.should_see_username("vvta");
        //se iese din cont
        account.click_logout();
        logout.should_see_text("logged out");
    }

} 