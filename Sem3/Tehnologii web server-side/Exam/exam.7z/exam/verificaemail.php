<?php

$subiect=$mesaj=$fail="";

if (isset($_POST['subiect']))
    $subiect = $_POST['subiect'];
if (isset($_POST['mesaj']))
    $mesaj = $_POST['mesaj'];

$fail .= validate_subiect($subiect);
$fail .= validate_mesaj($mesaj);
?>

<?php
function validate_subiect($field) {
if ($field == "")
return "No subject was entered<br />";
return "";
}
?> 

<?php
function validate_mesaj($field) {
if ($field == "")
return "No message was entered<br />";
return "";
}
?> 