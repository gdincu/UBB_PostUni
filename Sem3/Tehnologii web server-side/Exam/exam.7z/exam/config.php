<?php

/**
 * Configuration for database connection
 *
 */

$servername       = "localhost";
$username   = "root";
$password   = "";
$dbname     = "userapp";

?>