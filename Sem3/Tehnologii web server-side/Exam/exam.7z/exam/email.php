<?php include "templates/header.php"; ?>
<?php include "login.php"; ?>
<?php include "logout.php"; ?>
<?php include "db_connect.php"; ?>

<?php
if(!isset($_SESSION["user"])) {
    //Daca nu suntem logati redirectioneaza catre index.php
    header("Location: index.php");
    session_start();
}

?>

<?php include "verificaemail.php"; ?>

<form method="post">

    <p>
    <div class="form-row col-sm-4">
    Subiect:<div class="col">
    <input type="text" class="form-control" id="subiect" name="subiect" placeholder="<?php echo $subiect;?>" value="<?php echo $subiect;?>" required> 
    </div></div>
    </p>

    <p>
    <div class="form-row col-sm-4">
    Mesaj:<div class="col">
    <input type="textarea" class="form-control" id="mesaj" name="mesaj" placeholder="<?php echo $mesaj;?>" value="<?php echo $mesaj;?>">
    </div></div>
    </p>

    <p>
    <div class="form-row col-sm-4">
   <div class="col">
    <input type="hidden" class="form-control" id="idutilizator" name="idutilizator"  placeholder="<?php echo $_GET['id'];?>" value="<?php echo $_GET['id'];?>">
    </div></div>
    </p>

    <p>
    <div class="form-row col-sm-6">
    <div class="col">
    <button type="submit" name="submit" id="submit" class="btn btn-primary">Verifica mesaj!</button>
    </div></div>
    </p>

    </form>

<?php

if (isset($_POST['submit'])) {  


    if ($fail == "") {
        echo "Email verificat! Trimite folosind link-ul de mai jos:";
    }
    else {
        echo $fail;
        exit;
    }

//Preventing SQL Injections & XSS Injections
$subiect = htmlentities($_POST["subiect"],ENT_HTML5,'UTF-8',TRUE);
$mesaj = htmlentities($_POST["mesaj"],ENT_HTML5,'UTF-8',TRUE) . "\r\n\n Acest mesaj a fost trimis de pe pagina...";
$sendto = $_GET["email"];
$headers =  'MIME-Version: 1.0' . "\r\n"; 
$headers .= 'From: Your name <info@address.com>' . "\r\n";
$headers .= 'Content-type: text/html; charset=iso-8859-1' . "\r\n"; 

echo $sendto;
echo "</br>";
echo $subiect;
echo "</br>";
echo $mesaj;
echo "</br>";
echo $headers;
echo "</br>";
exit();

}
?>

<?php include "templates/footer.php"; ?>