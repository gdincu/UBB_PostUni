<?php include "templates/header.php"; ?>
<?php include "login.php"; ?>
<?php include "logout.php"; ?>
<?php include "db_connect.php"; ?>

<?php

//Afisarea utilizatorilor fara logare
if(!isset($_SESSION["user"])) {

$sql = "SELECT * FROM utilizatori";
	
$result = $connection->query($sql);
					if($result->num_rows > 0) {
					echo "Current user list:
					<br><br>
					<table class=\"table\">
					<tr>
    				<th>Username</th>
    				<th>Nume</th>
    				<th>Prenume</th>
  					</tr>";	
					while($row = $result->fetch_assoc()) {
						echo "<tr>";
						echo "<td>" . $row["usernume"] . "</td>";
						echo "<td>" . $row["nume"] . "</td>";
						echo "<td>" . $row["prenume"] . "</td>";
						echo "</tr>";
					}
				echo "</table>";
				}
					else echo "No current users.";
	}


//Afisarea utilizatorilor cu logare
if(isset($_SESSION["user"])) {

	$images = glob("uploads/*.*");
	$sql = "SELECT * FROM utilizatori";
	$fotoTemp = "<td>N/A</td>";
	if($ascheck) { $sql = "SELECT * FROM utilizatori ORDER BY nume ASC"; }
	else if ($descheck) {$sql = "SELECT * FROM utilizatori ORDER BY nume DESC"; }
	
	$result = $connection->query($sql);
					if($result->num_rows > 0) {
					echo "Current user list:
					<br><br>
					<table class=\"table\">
					<tr>
					<th>Foto</th>
					<th>Username</th>
					<th>Extensie</th>
    				<th>Nume</th>
					<th>Prenume</th>
					<th>Email</th>
					<th>Telefon</th>
					<th>Stare civila</th>
					<th>Sex</th>
					<th>Data Inregistrare</th>
					<th>Data Login</th>
					<th>Send Email</th>
					</tr>
					<tr>";	
					while($row = $result->fetch_assoc()) {
						echo "<tr>";
						
						foreach($images as $image) {
						if(pathinfo($image,PATHINFO_FILENAME) == $row["usernume"]) {
							$fotoTemp = '<td><img src="'.$image.'" width=20 height=20></td>';
						break;
						}
						}
						echo $fotoTemp;
						$fotoTemp = "<td>N/A</td>";
						echo "<td>" . $row["usernume"] . "</td>";
						echo "<td>" . $row["extensie"] . "</td>";
						echo "<td>" . $row["nume"] . "</td>";
						echo "<td>" . $row["prenume"] . "</td>";
						echo "<td>" . $row["email"] . "</td>";
						echo "<td>" . $row["telefon"] . "</td>";
						echo "<td>" . $row["starecivila"] . "</td>";
						echo "<td>" . $row["sex"] . "</td>";
						echo "<td>" . $row["dataregistrare"] . "</td>";
						echo "<td>" . $row["datalogin"] . "</td>";
						echo "<td><a href='email.php?email=" . $row["email"] ."&id=". $row["id"] ."'>Email</a></td></tr>";
					}
				echo "</table>";
			}
					else echo "0 results";
	
}
?>

<?php include "templates/footer.php"; ?>