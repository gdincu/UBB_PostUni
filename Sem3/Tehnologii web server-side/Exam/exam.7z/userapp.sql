-- phpMyAdmin SQL Dump
-- version 4.8.5
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Feb 08, 2020 at 05:26 PM
-- Server version: 10.1.38-MariaDB
-- PHP Version: 7.1.28

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `userapp`
--

-- --------------------------------------------------------

--
-- Table structure for table `utilizatori`
--

CREATE TABLE `utilizatori` (
  `id` int(11) UNSIGNED NOT NULL,
  `usernume` varchar(30) NOT NULL,
  `parola` varchar(50) NOT NULL,
  `sex` varchar(20) NOT NULL,
  `starecivila` varchar(15) DEFAULT NULL,
  `nume` varchar(50) DEFAULT NULL,
  `prenume` varchar(50) DEFAULT NULL,
  `email` varchar(50) DEFAULT NULL,
  `dataregistrare` date DEFAULT NULL,
  `extensie` text,
  `datalogin` datetime DEFAULT NULL,
  `telefon` text
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `utilizatori`
--

INSERT INTO `utilizatori` (`id`, `usernume`, `parola`, `sex`, `starecivila`, `nume`, `prenume`, `email`, `dataregistrare`, `extensie`, `datalogin`, `telefon`) VALUES
(27, 'r', 'e47ca7a09cf6781e29634502345930a7', '', 'Casatorit', 'r', 'r', 'r@r.com', '2020-01-26', 'png', '2020-02-07 17:33:33', NULL),
(30, 'cv', 'de3ec0aa2234aa1e3ee275bbc715c6c9', 'Casatorit(a)', 'Barbat', 'cv', 'cv', 'cv@cv.com', '2020-01-26', 'png', '2020-02-07 17:33:33', NULL),
(31, 'bb', '21ad0bd836b90d08f4cf640b4c298e7c', 'Nespecificat', 'Nespecificat', 'bb', 'bb', 'bb@b.com', '2020-01-26', 'png', '2020-02-07 17:33:33', NULL),
(32, 'kk', 'dc468c70fb574ebd07287b38d0d0676d', 'Necasatorit(a)', 'Nespecificat', 'kk', 'kk', 'k@k.com', '2020-01-26', 'png', '2020-02-07 17:33:33', NULL),
(37, 'c1', '9ab62b5ef34a985438bfdf7ee0102229', 'Nespecificat', 'Nespecificat', 'c', 'c', 'c@c', '2020-01-26', 'png', '2020-02-07 17:33:33', NULL),
(38, 'c555', 'a9f7e97965d6cf799a529102a973b8b9', 'Nespecificat', 'Nespecificat', 'c123', 'c', 'c@c', '2020-01-26', 'png', '2020-02-07 17:33:33', NULL),
(39, 'c999', 'a9f7e97965d6cf799a529102a973b8b9', 'Nespecificat', 'Nespecificat', 'c9', 'c', 'c@c', '2020-01-26', 'png', '2020-02-07 17:33:33', NULL),
(55, 'teodincu', '040b7cf4a55014e185813e0644502ea9', 'Nespecificat', 'Necasatorit(a)', 'Dincu', 'Teo', 'teo&commat;dd&period;com', '2020-01-26', 'jpg', '2020-02-07 17:33:33', NULL),
(56, 'ionutdincu', '4ef16e5bd0940409f2955e95e2d986bf', 'Barbat', 'Casatorit(a)', 'Dincu', 'Ionutd', 'dincu&commat;dd&period;com', '2020-01-26', 'jpg', '2020-02-07 17:33:33', NULL),
(58, 'alexm', 'accc9105df5383111407fd5b41255e23', 'Barbat', 'Casatorit(a)', 'alex', 'muresan', 'gabrieldincu@outlook.com', '2020-01-26', 'jpg', '2020-02-07 17:33:33', NULL),
(59, 'examen', '32bd3b82800c20c82f979e3cf1b26917', 'Nespecificat', 'Nespecificat', 'exam', 'exam', 'ex&commat;am&period;com', '2020-02-07', '', '2020-02-07 19:06:32', '+9938372');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `utilizatori`
--
ALTER TABLE `utilizatori`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `utilizatori`
--
ALTER TABLE `utilizatori`
  MODIFY `id` int(11) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=60;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
