-- phpMyAdmin SQL Dump
-- version 4.9.2
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jan 22, 2020 at 08:18 AM
-- Server version: 10.4.11-MariaDB
-- PHP Version: 7.4.1

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `userapp`
--

-- --------------------------------------------------------

--
-- Table structure for table `utilizatori`
--

CREATE TABLE `utilizatori` (
  `usernume` text DEFAULT NULL,
  `parola` varchar(50) DEFAULT NULL,
  `nume` text DEFAULT NULL,
  `prenume` text DEFAULT NULL,
  `email` text DEFAULT NULL,
  `date` text DEFAULT NULL,
  `starecivila` text DEFAULT NULL,
  `sex` text DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `utilizatori`
--

INSERT INTO `utilizatori` (`usernume`, `parola`, `nume`, `prenume`, `email`, `date`, `starecivila`, `sex`) VALUES
('abc', '900150983cd24fb0d6963f7d28e17f72', 'a', 'b', 'b@b.com', '2020-01-21 07:56:18', 'Necasatorit(a)', 'Femeie'),
('zy', '4345ed1bd9c52c31610be7c0080981c3', 'y', 'z', 'z@z.com', '2020-01-21 10:58:56', 'Necasatorit(a)', 'Femeie'),
('r', '4b43b0aee35624cd95b910189b3dc231', 'r', 'r', 'rr@r.com', '2020-01-21 11:05:42', 'Necasatorit(a)', 'Femeie'),
('uu', '6277e2a7446059985dc9bcf0a4ac1a8f', 'uu', 'uu', 'uu@uu.com', '2020-01-21 11:55:34', 'Necasatorit(a)', 'Femeie'),
('uu', '6277e2a7446059985dc9bcf0a4ac1a8f', 'uu', 'uu', 'u@u.com', '2020-01-21 11:55:57', 'Necasatorit(a)', 'Femeie'),
('bb', '21ad0bd836b90d08f4cf640b4c298e7c', 'bb', 'bb', 'b@b.com', '2020-01-21 11:57:15', 'Necasatorit(a)', 'Femeie'),
('gg', '73c18c59a39b18382081ec00bb456d43', 'gg', 'gg', 'g@g.com', '2020-01-21 12:04:39', 'Necasatorit(a)', 'Femeie'),
('cv', 'de3ec0aa2234aa1e3ee275bbc715c6c9', 'cv', 'cv', 'cv@c.com', '2020-01-21 12:06:40', 'Necasatorit(a)', 'Femeie'),
('ty', '36f3af6226e0b5303e19b824e7442272', 'ty', 'ty', 'ty@ty.com', '2020-01-21 12:06:57', 'Necasatorit(a)', 'Femeie'),
('uu', '6277e2a7446059985dc9bcf0a4ac1a8f', 'uu', 'uu', 'uu@u.com', '2020-01-21 12:07:55', 'Necasatorit(a)', 'Femeie'),
('df', 'eff7d5dba32b4da32d9a67a519434d3f', 'df', 'df', 'df@d.com', '2020-01-21 12:09:21', 'Necasatorit(a)', 'Femeie'),
('bv', '121aa3ee4a7d5b1bbbc760fd0c6de79b', 'bv', 'bv', 'bv@b.com', '2020-01-21 12:10:39', 'Necasatorit(a)', 'Femeie'),
('qwe', '76d80224611fc919a5d54f0ff9fba446', 'qwe', 'qwe', 'qwe@q.com', '2020-01-21 12:12:26', 'Necasatorit(a)', 'Femeie'),
('lkj', '48e2e79fec9bc01d9a00e0a8fa68b289', 'lkj', 'lkj', 'lk@k.com', '2020-01-21 12:14:03', 'Necasatorit(a)', 'Femeie'),
('rtg', '1da33616e19f532fca9bf8e3c095d11d', 'rtg', 'rtg', 'rtg@r.com', '2020-01-21 12:15:32', 'Necasatorit(a)', 'Femeie'),
('lll', 'bf083d4ab960620b645557217dd59a49', 'llll', 'lll', '', '2020-01-22 08:35:14', 'Barbat', 'Casatorit(a)');
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
