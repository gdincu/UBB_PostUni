package ro.ubb.hello.server;

import ro.ubb.hello.server.tcp.TcpServer;

import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/**
 * Created by radu.
 */
public class ServerApp {
    public static void main(String[] args) {
        ExecutorService service = Executors.newFixedThreadPool(
                Runtime.getRuntime().availableProcessors()
        );
        TcpServer tcpServer = new TcpServer(service);

        tcpServer.startServer();

        System.out.println("Server oprit");
    }
}
