package ro.ubb.hello.server.tcp;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.concurrent.ExecutorService;

/**
 * Created by radu.
 */
public class TcpServer {
    private ExecutorService service;

    public TcpServer(ExecutorService service) {
        this.service = service;
    }

    public void startServer() {
        System.out.println("waiting for clients...");
        try (var serverSocket = new ServerSocket(1234)) {
            while (true) {
                Socket clientSocket = serverSocket.accept();
                System.out.println("client connected");

                service.submit(new ClientHandler(clientSocket));
            }

        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}

class ClientHandler implements Runnable {
    private Socket socket;

    public ClientHandler(Socket socket) {
        this.socket = socket;
    }

    @Override
    public void run() {
        try (var is = socket.getInputStream();
             var os = socket.getOutputStream();
             var br = new BufferedReader(new InputStreamReader(is))
        ) {
            System.out.println("processing client");

            String request = br.readLine();
            System.out.println("received request: " + request);
            String arr[] = request.split(" ");
            String result = "";
            if (arr[0].equals("add"))
                result = doAdd(arr);
            else if (arr[0].equals("multiply"))
                result = doMultiply(arr);
            else if (arr[0].equals("interval1"))
                result = doInterval1(arr);
            else if (arr[0].equals("interval2"))
                result = doInterval2(arr);

            System.out.println("computed response: " + result);
            os.write(result.getBytes());//

        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    private String doInterval1(String[] arr) {
        String res = "";
        for (int i = Integer.parseInt(arr[1]);i <= Integer.parseInt(arr[arr.length - 2]); i++)
            if (i % Integer.parseInt(arr[arr.length - 1]) == 0)
                res += (i + " ");
        return res;
    }

    private String doInterval2(String[] arr) {
        String res = "";
        for (int i = Integer.parseInt(arr[1]);i <= Integer.parseInt(arr[arr.length - 2]); i++)
            if ((i > 10) & (i%10 + ((i/10)%10)*10) % Integer.parseInt(arr[arr.length - 1]) == 0 & (i%10 + ((i/10)%10)*10) != 0)
                res += (i + " ");
        return res;
    }

    private String doAdd(String[] arr) {
        int res = 0;
        for(int i=1;i<arr.length;i++)
            res += Integer.parseInt(arr[i]);
        return "" + res;
    }

    private String doMultiply(String[] arr) {
        int res = 1;
        for(int i=1;i<arr.length;i++)
            res *= Integer.parseInt(arr[i]);
        return "" + res;
    }

}