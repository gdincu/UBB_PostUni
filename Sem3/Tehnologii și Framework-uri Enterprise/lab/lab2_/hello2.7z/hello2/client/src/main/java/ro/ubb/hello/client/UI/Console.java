package ro.ubb.hello.client.UI;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.Socket;
import java.util.*;

public class Console {

    /**
     * Metoda de citire a unui intreg de la tastatura
     * @param
     * @return
     */
    private static int CitIntreg(String A){
        System.out.print(A);
        return (new Scanner(System.in).nextInt());
    }

    /**
     * Metoda de citire a unui string de la tastatura
     * @param
     * @return
     */
    private static String CitString(){
        System.out.print("\nLista de numere cu spatiu intre ele: ");
        return (new Scanner(System.in).nextLine());
    }


    public int showMenu() {
        System.out.println(String.format("%-90s","------------------------------------------------------------------------------"));
        System.out.println(String.format("%-45s %-45s", "1.Sum", "2.Product"));
        System.out.println(String.format("%-45s %-45s", "3.Interval[1]", "4.Interval[2]"));
        System.out.println(String.format("%-90s","------------------------------------------------------------------------------"));
        System.out.println(String.format("%-90s","0.Exit"));
        System.out.println(String.format("%-90s","------------------------------------------------------------------------------"));
        return(CitIntreg("\nOptiune : "));
    }

    public void sendNumbers(String tipOperatie) {
        try (var socket = new Socket("localhost", 1234);
             var is = socket.getInputStream();
             var os = socket.getOutputStream();
             var br = new BufferedReader(new InputStreamReader(is))) {

            String[] tempStr = CitString().split(" ").clone();

            String request = (tipOperatie + " ");
            for(String c : tempStr)
                request += (c + " ");
            request += "\n";

            os.write(request.getBytes());
            System.out.println("sent request: " + request);

            String response = br.readLine();
            System.out.println("received response: " + response);

        } catch (IOException e) {
            e.printStackTrace();
        }

    }
}