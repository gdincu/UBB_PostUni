package ro.ubb.hello.client;
import ro.ubb.hello.client.UI.Console;

/**
 * Created by radu.
 */
public class ClientApp {
    public static void main(String[] args) {

        Console console = new Console();
        int opt = console.showMenu();


        while (opt != 0) {
            switch (opt) {
                case 1:
                    console.sendNumbers("add");
                    opt = console.showMenu();
                    break;
                case 2:
                    console.sendNumbers("multiply");
                    opt = console.showMenu();
                    break;
                case 3:
                    console.sendNumbers("interval1");
                    opt = console.showMenu();
                    break;
                case 4:
                    console.sendNumbers("interval2");
                    opt = console.showMenu();
                    break;
                default:
                    System.out.println("Try again!!!");
                    opt = console.showMenu();
                    break;
            }
        }
        System.out.println("Client inchis");
    }
}
