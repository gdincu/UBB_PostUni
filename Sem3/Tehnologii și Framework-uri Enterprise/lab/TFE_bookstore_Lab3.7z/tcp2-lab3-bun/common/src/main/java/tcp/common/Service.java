package tcp.common;

public interface Service {
    String SERVER_HOST = "localhost";
    int SERVER_PORT = 1234;
}
