package tcp.client.ui;
import tcp.common.BookService;
import tcp.common.ClientService;
import tcp.common.domain.Book;
import tcp.common.domain.Client;
import tcp.common.domain.validators.ValidatorException;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.*;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.Future;

public class Console {
    private BookService bookService;
    private ClientService clientService;
    private Scanner scanner;

    public Console(BookService bookService, ClientService clientService) {
        this.bookService = bookService;
        this.clientService = clientService;
        this.scanner = new Scanner(System.in);
    }

    /**
     * Metoda de citire a unui intreg de la tastatura
     * @param
     * @return
     */
    private static int CitIntreg(String A){
        System.out.print(A);
        return (new Scanner(System.in).nextInt());
    }

    private int showMenu() {
        System.out.println(String.format("%-90s","------------------------------------------------------------------------------"));
        System.out.println(String.format("%-30s %-30s %-30s", "1.Add a book", "6.Add a client", "11.Add a purchase"));
        System.out.println(String.format("%-30s %-30s %-30s", "2.Remove a book", "7.Remove a client", "12.Remove a purchase"));
        System.out.println(String.format("%-30s %-30s %-30s", "3.Update a book", "8.Update a client", "13.Update a purchase"));
        System.out.println(String.format("%-30s %-30s %-30s", "4.Print all books", "9.Print all clients", "14.Print all purchases"));
        System.out.println(String.format("%-30s %-30s %-30s", "5.Filter books", "10.Filter clients", "15.Filter purchases"));
        System.out.println(String.format("%-90s","------------------------------------------------------------------------------"));
        System.out.println(String.format("%-90s","0.Exit"));
        System.out.println(String.format("%-90s","------------------------------------------------------------------------------"));
        return(CitIntreg("\nOptiune : "));
    }



    public void runConsole() throws IOException {
        int opt = showMenu();

        while(opt!=0){
            switch(opt){
                case 1:addBook();
                    break;
                case 6:addClient();
                    break;
                case 11:;
                    break;

                case 2:deleteBookById();
                    break;
                case 7:deleteClientById();
                    break;
                case 12:;
                    break;

                case 3:updateBook();
                    break;
                case 8:updateClient();
                    break;
                case 13:;
                    break;

                case 4:printAllBooks();
                    break;
                case 9:printAllClients();
                    break;
                case 14:;
                    break;

                case 5://filterBooks();
                    break;
                case 10://filterClients();
                    break;
                case 15:;
                    break;

                default:
                    System.out.println("Try again!!!");
            }
            opt=showMenu();
        }
        }

    private void addBook() throws IOException{
        BufferedReader bufferRead = new BufferedReader(new InputStreamReader(System.in));

        System.out.println("Enter id: ");
        int id = Integer.parseInt(bufferRead.readLine());
        System.out.println("Enter title: ");
        String name = bufferRead.readLine();
        System.out.println("Enter author: ");
        String author = bufferRead.readLine();
        System.out.println("Enter publisher: ");
        String publisher = bufferRead.readLine();
        System.out.println("Enter year of publication: ");
        String yearOfPublication = bufferRead.readLine();
        System.out.println("Enter price: ");
        double price = Double.parseDouble(bufferRead.readLine());

        Book book = new Book(id, name, author, publisher, yearOfPublication, price);
        book.setId(id);

        bookService.addBook(book);
    }

    private void printAllBooks() {
        Future<String> result = bookService.findAllBooks();

        try {
            String[] bookList = result.get().split(", Book");

            System.out.println("Client: received result - List of books: ");

            for (String s : bookList) {
                System.out.println(s);
            }
        } catch (InterruptedException | ExecutionException e) {
            e.printStackTrace();
        }
    }

    private void deleteBookById() {
        BufferedReader bufferRead = new BufferedReader(new InputStreamReader(System.in));
        try {
            System.out.println("Enter id: ");
            int id = Integer.parseInt(bufferRead.readLine());

            bookService.delete(id);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    private void updateBook() {
        BufferedReader bufferRead = new BufferedReader(new InputStreamReader(System.in));

        try {
            System.out.println("Enter id: ");
            int id = Integer.parseInt(bufferRead.readLine());
            System.out.println("Enter title: ");
            String name = bufferRead.readLine();
            System.out.println("Enter author: ");
            String author = bufferRead.readLine();
            System.out.println("Enter publisher: ");
            String publisher = bufferRead.readLine();
            System.out.println("Enter year of publication: ");
            String yearOfPublication = bufferRead.readLine();
            System.out.println("Enter price: ");
            double price = Double.parseDouble(bufferRead.readLine());

            Book book = new Book(id, name, author, publisher, yearOfPublication, price);
            book.setId(id);

            bookService.update(book);

        } catch (IOException ex) {
            ex.printStackTrace();
        } catch (ValidatorException e) {
            e.printStackTrace();
        }
    }


    private void addClient() throws IOException {
        BufferedReader bufferRead = new BufferedReader(new InputStreamReader(System.in));
        try {
            System.out.println("Enter id: ");
            int id = Integer.parseInt(bufferRead.readLine());
            System.out.println("Enter name: ");
            String name = bufferRead.readLine();
            System.out.println("Enter date of registration: ");
            String dateOfRegistration = bufferRead.readLine();

            Client client = new Client(id, name, dateOfRegistration);
            client.setId(id);

            clientService.addClient(client);

        } catch (IOException ex) {
            ex.printStackTrace();
        } catch (ValidatorException ex) {
            ex.printStackTrace();
        }
    }

    private void printAllClients() {
        Future<String> result = clientService.findAllClients();

        try {
            String[] clientList = result.get().substring(1, result.get().length() - 1).split(", Client");

            System.out.println();

            for (String c : clientList) {
                System.out.println(c);
            }
        } catch (InterruptedException | ExecutionException e) {
            e.printStackTrace();
        }
    }

    private void deleteClientById() {
        BufferedReader bufferRead = new BufferedReader(new InputStreamReader(System.in));
        try {
            System.out.println("Enter id: ");
            int id = Integer.parseInt(bufferRead.readLine());

            clientService.delete(id);
        } catch (IOException e) {
            e.printStackTrace();
        }
        System.out.println("The client was deleted!");
    }

    private void updateClient() {
        BufferedReader bufferRead = new BufferedReader(new InputStreamReader(System.in));

        try {
            System.out.println("Enter id: ");
            int id = Integer.parseInt(bufferRead.readLine());
            System.out.println("Enter name: ");
            String name = bufferRead.readLine();
            System.out.println("Enter date of registration: ");
            String dateOfRegistration = bufferRead.readLine();

            Client client = new Client(id, name, dateOfRegistration);
            client.setId(id);

            clientService.update(client);

        } catch (IOException ex) {
            ex.printStackTrace();
        } catch (ValidatorException e) {
            e.printStackTrace();
        }
        System.out.println("The client was updated!");
    }

}