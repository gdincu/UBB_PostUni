package Domain.Validators;
import Domain.Purchase;

public class PurchaseValidator implements Validator<Purchase> {

    @Override
    public void validate(Purchase entity) throws ValidatorException {

        //To do

    }

}
