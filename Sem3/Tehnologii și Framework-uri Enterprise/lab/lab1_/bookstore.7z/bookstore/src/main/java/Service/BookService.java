package Service;
import Domain.*;
import Repository.Repository;
import java.util.*;
import java.util.stream.*;

import static java.util.stream.Collectors.groupingBy;

public class BookService {

    private Repository<Integer, Book> repository;

    public BookService(Repository<Integer, Book> repository) {
        this.repository = repository;
    }

    /**
     * Adds a new book to the repository
     * @param book the book to be added
     */
    public void addBook(Book book) { repository.save(book); }

    public void removeBook(String name) {repository.delete(name); }

    public Set<Book> getAllBooks() {
            Iterable<Book> books = repository.findAll();
            return StreamSupport.stream(books.spliterator(), false).collect(Collectors.toSet());
        }

        public List<Book> filterBooksByPrice(double s) {

            Stream<Book> filteredBooks = repository.findAll().stream().filter(book -> book.getPrice() <= s);
            List<Book> result = filteredBooks.collect(Collectors.toList());

            result.addAll((repository.findAll().stream().filter(book -> book.getPrice() > s)).collect(Collectors.toList()));

            return result;
    }

    public List<Book> filterBooksByPrice2(double temp) {

        List<Book> a = (repository.findAll().stream().filter(book -> {
            return book.getPrice() <= temp;
            })).sorted(Comparator.comparing(book1 -> {
            return book1.getName();
            })).collect(Collectors.toList());

        a.addAll((repository.findAll().stream().filter(book -> book.getPrice() > temp)).sorted(Comparator.comparing(Book::getAuthor).reversed()).collect(Collectors.toList()));

        return a;
    }
}
