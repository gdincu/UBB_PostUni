import Domain.*;
import Domain.Validators.*;
import Repository.*;
import Service.*;
import UI.Console;
import java.io.File;
import java.io.IOException;

public class Main {
    private static final String URL = "jdbc:postgresql://localhost:5432/bookstore";
    private static final String USER = System.getProperty("username");
    private static final String PASSWORD = System.getProperty("password");

    public static void main(String[] args) {

        Validator<Book> bookValidator = new BookValidator();
        BookRepository bookRepository = new BookRepository(URL, USER, PASSWORD);
        BookService bookService = new BookService(bookRepository);

        Validator<Client> clientValidator = new ClientValidator();
        ClientRepository clientRepository = new ClientRepository(URL, USER, PASSWORD);
        ClientService clientService = new ClientService(clientRepository);


        Console console = new Console(bookService,clientService);
        int opt = console.showMenu();

        while(opt!=0){
                switch(opt){
                    case 1:console.addBooks();
                        break;
                    case 6:console.addClients();
                        break;
                    case 11:;
                        break;

                    case 2:console.removeBooks();
                    break;
                    case 7:console.removeClients();
                        break;
                    case 12:;
                        break;

                    case 3:console.updateBooks();
                    break;
                    case 8:console.updateClients();
                        break;
                    case 13:;
                        break;

                    case 4:console.printAllBooks();
                        break;
                    case 9:console.printAllClients();
                        break;
                    case 14:;
                        break;

                    case 5:console.filterBooks();
                        break;
                    case 10:console.filterClients();
                        break;
                    case 15:;
                        break;

                    case 16:
                        console.showClients();
                        break;
                    case 17:
                        console.showBooks();
                        break;
                    case 18:
                        console.showBooks2();
                        break;

                    default:
                        System.out.println("Try again!!!");
                }
                opt=console.showMenu();
            }

        try {
            System.out.println(new File(".").getCanonicalPath());
        } catch (IOException e) {
            e.printStackTrace();
        }
            System.out.println("Program terminat");

    }
}