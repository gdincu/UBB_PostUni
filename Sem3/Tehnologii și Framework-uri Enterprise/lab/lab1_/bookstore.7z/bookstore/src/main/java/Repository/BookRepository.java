package Repository;
import Domain.Book;
import java.sql.*;
import java.util.ArrayList;

import java.util.List;
import java.util.Optional;

public class BookRepository implements Repository<Integer, Book> {

    private String url;
    private String user;
    private String password;

    public BookRepository(String url, String user, String password) {
        this.url = url;
        this.user = user;
        this.password = password;
    }

    @Override
    public Optional<Book> findOne(Integer integer) {
        String sql = "select * from book where id=?";

        try (Connection connection = DriverManager.getConnection(url, user, password);
             PreparedStatement ps = connection.prepareStatement(sql))     {

            ps.setInt(1, integer);

            ps.executeUpdate();

        } catch (SQLException e) {
            e.printStackTrace();
        }
        return null;
    }

    public List<Book> findAll() {

        List<Book> books = new ArrayList<>();
        String sql = "select * from book";

        try (Connection connection = DriverManager.getConnection(url, user, password);
             PreparedStatement ps = connection.prepareStatement(sql);
             ResultSet rs = ps.executeQuery()) {

            while (rs.next()) {
                int id = rs.getInt("id");
                String name = rs.getString("name");
                String author = rs.getString("author");
                Double price = rs.getDouble("price");

                Book book = new Book(name,author,price);
                books.add(book);
            }

        } catch (SQLException e) {
            e.printStackTrace();
        }
        return books;
    }

    public Optional<Book> save(Book book) {
        String sql = "insert into book (name, author, price) values (?, ?, ?)";

        try (Connection connection = DriverManager.getConnection(url, user, password);
             PreparedStatement ps = connection.prepareStatement(sql))     {

            ps.setString(1, book.getName());
            ps.setString(2, book.getAuthor());
            ps.setDouble(3, book.getPrice());

            ps.executeUpdate();

        } catch (SQLException e) {
            e.printStackTrace();
        }
        return null;
    }

    @Override
    public Optional<Book> update(Book entity) {

            String sql = "update book set name=?, author=?, price=? where name=?";

            try (Connection connection = DriverManager.getConnection(url, user, password);
                 PreparedStatement ps = connection.prepareStatement(sql)) {

                ps.setString(1, entity.getName());
                ps.setString(2, entity.getAuthor());
                ps.setDouble(3, entity.getPrice());
                ps.setString(4, entity.getName());

                ps.executeUpdate();
            } catch (SQLException e) {
                e.printStackTrace();
            }
            return null;
        }

    @Override
    public Optional<Book> delete(String s) {
            String sql = "delete from book where name=?";

            try (Connection connection = DriverManager.getConnection(url, user, password);
                 PreparedStatement ps = connection.prepareStatement(sql)) {

                ps.setString(1, s);

                ps.executeUpdate();
            } catch (SQLException e) {
                e.printStackTrace();
            }
            return null;
        }
}
