package Domain;

import java.util.Objects;

public class Purchase extends BaseEntity<Integer>{

    private int clientID, bookID;
    private double total;

    public Purchase(int clientID, int bookID, double total) {
        this.clientID = clientID;
        this.bookID = bookID;
        this.total = total;
    }

    public Purchase(int id,int clientID, int bookID, double total) {
        super.setId(id);
        this.clientID = clientID;
        this.bookID = bookID;
        this.total = total;
    }

    public int getClientID() {
        return clientID;
    }

    public void setClientID(int clientID) {
        this.clientID = clientID;
    }

    public int getBookID() {
        return bookID;
    }

    public void setBookID(int bookID) {
        this.bookID = bookID;
    }

    public double getTotal() {
        return total;
    }

    public void setTotal(double total) {
        this.total = total;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        Purchase purchase = (Purchase) o;
        return clientID == purchase.clientID &&
                bookID == purchase.bookID &&
                Double.compare(purchase.total, total) == 0;
    }

    @Override
    public int hashCode() {
        return Objects.hash(clientID, bookID, total);
    }

    @Override
    public String toString() {
        return "Purchase{" +
                "clientID=" + clientID +
                ", bookID=" + bookID +
                ", total=" + total +
                '}';
    }
}
