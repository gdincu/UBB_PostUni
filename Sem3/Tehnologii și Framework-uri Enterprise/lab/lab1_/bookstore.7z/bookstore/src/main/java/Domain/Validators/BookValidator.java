package Domain.Validators;
import Domain.Book;

public class BookValidator implements Validator<Book> {

    @Override
    public void validate(Book entity) throws ValidatorException {

    }

}
