package Service;

import Domain.Client;
import Repository.Repository;

import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.stream.Collectors;
import java.util.stream.StreamSupport;

public class ClientService {

    private Repository<Integer, Client> repository;

    public ClientService(Repository<Integer, Client> repository) {
        this.repository = repository;
    }

    /**
     * Adds a new client to the repository
     *
     * @param client the client to be added
     */
    public void addClient(Client client) {
        repository.save(client);
    }

    public void removeClient(String name) {repository.delete(name); }

    public Set<Client> getAllClients() {
        Iterable<Client> clients = repository.findAll();
        return StreamSupport.stream(clients.spliterator(), false).collect(Collectors.toSet());
    }

    public Set<Client> filterClientsByName(String s) {
        Iterable<Client> clients = repository.findAll();
        //version 1
        Set<Client> filteredClients = StreamSupport.stream(clients.spliterator(), false)
                .filter(client -> client.getName().contains(s)).collect(Collectors.toSet());

        //version 2
//        Set<Client> filteredClients = new HashSet<>();
//        clients.forEach(filteredClients::add);
//        filteredClients.removeIf(client -> !client.getName().contains(s));
        return filteredClients;
    }
}
