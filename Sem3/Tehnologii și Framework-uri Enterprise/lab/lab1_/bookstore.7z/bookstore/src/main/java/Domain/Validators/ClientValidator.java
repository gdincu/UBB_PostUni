package Domain.Validators;
import Domain.Client;

public class ClientValidator implements Validator<Client> {

    @Override
    public void validate(Client entity) throws ValidatorException {

        //To do

    }

}
