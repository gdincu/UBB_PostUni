package UI;
import Domain.Book;
import Domain.Client;
import Domain.Purchase;
import Service.BookService;
import Service.ClientService;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.*;

public class Console {
    private BookService bookService;
    private ClientService clientService;

    public Console(BookService bookService, ClientService clientService) {
        this.bookService = bookService;
        this.clientService = clientService;
    }

    /**
     * Metoda de citire a unui intreg de la tastatura
     * @param
     * @return
     */
    private static int CitIntreg(String A){
        System.out.print(A);
        return (new Scanner(System.in).nextInt());
    }

    public int showMenu() {
        System.out.println(String.format("%-90s","------------------------------------------------------------------------------"));
        System.out.println(String.format("%-30s %-30s %-30s", "1.Add a book", "6.Add a client", "11.Add a purchase"));
        System.out.println(String.format("%-30s %-30s %-30s", "2.Remove a book", "7.Remove a client", "12.Remove a purchase"));
        System.out.println(String.format("%-30s %-30s %-30s", "3.Update a book", "8.Update a client", "13.Update a purchase"));
        System.out.println(String.format("%-30s %-30s %-30s", "4.Print all books", "9.Print all clients", "14.Print all purchases"));
        System.out.println(String.format("%-30s %-30s %-30s", "5.Filter books", "10.Filter clients", "15.Filter purchases"));
        System.out.println(String.format("%-90s","------------------------------------------------------------------------------"));
        System.out.println(String.format("%-90s","16.TFE_Lab_1 -> String"));
        System.out.println(String.format("%-90s","17.TFE_Lab_2 -> Double"));
        System.out.println(String.format("%-90s","18.TFE_Lab_3 -> Double"));
        System.out.println(String.format("%-90s","------------------------------------------------------------------------------"));
        System.out.println(String.format("%-90s","0.Exit"));
        System.out.println(String.format("%-90s","------------------------------------------------------------------------------"));
        return(CitIntreg("\nOptiune : "));
    }

    public void filterBooks() {
        System.out.println("filtered books (name containing 'A'):");
        List<Book> books = bookService.filterBooksByPrice(1);
        books.stream().forEach(System.out::println);
    }

    public void printAllBooks() {
        Set<Book> books = bookService.getAllBooks();
        books.stream().forEach(System.out::println);


    }

    public void addBooks() {
            Book book = readBook();
            if (book == null) return;
            bookService.addBook(book);
        }

    public void removeBooks() {
        System.out.println("Book Name: ");
        String s = new Scanner(System.in).nextLine();
        if (s == null) return;
        bookService.removeBook(s);
    }

    public void updateBooks() {

    }


    public Book readBook() {
        System.out.println("Read book {name,author,price}");

        BufferedReader bufferRead = new BufferedReader(new InputStreamReader(System.in));
        try {
            String name = bufferRead.readLine();
            String author = bufferRead.readLine();
            double price = Double.parseDouble(bufferRead.readLine());// ...

            Book book = new Book(name,author,price);

            return book;
        } catch (IOException ex) {
            ex.printStackTrace();
        }
        return null;
    }

    public void filterClients() {
        System.out.println("filtered clients (name containing 'E'):");
        Set<Client> clients = clientService.filterClientsByName("E");
        clients.stream().forEach(System.out::println);
    }

    public void printAllClients() {
        Set<Client> clients = clientService.getAllClients();
        clients.stream().forEach(System.out::println);
    }

    public void addClients() {
        Client client = readClient();
        if (client == null) return;
        clientService.addClient(client);
    }

    public void removeClients() {
        System.out.println("Client Name: ");
        String s = new Scanner(System.in).nextLine();
        if (s == null) return;
        clientService.removeClient(s);
    }

    public void updateClients() {

    }

    public Client readClient() {
        System.out.println("Read client {name}");

        BufferedReader bufferRead = new BufferedReader(new InputStreamReader(System.in));
        try {
            String name = bufferRead.readLine();

            Client client = new Client(name);

            return client;
        } catch (IOException ex) {
            ex.printStackTrace();
        }
        return null;
    }

    public void showClients() {
        System.out.println("String cautat: ");
        String temp = new Scanner( System. in).nextLine();
        System.out.println("filtered clients (name containing " + temp + "):");
        Set<Client> clients = clientService.filterClientsByName(temp);
        clients.stream().forEach(System.out::println);
    }

    public void showBooks() {
        System.out.println("Pret cautat: ");
        double temp = new Scanner( System. in).nextDouble();
        List<Book> books = bookService.filterBooksByPrice(temp);
        books.stream().forEach(System.out::println);
    }

    public void showBooks2() {
        System.out.println("Pret cautat: ");
        double temp = new Scanner( System. in).nextDouble();
        List<Book> books = bookService.filterBooksByPrice2(temp);
        books.stream().forEach(System.out::println);
    }
}
