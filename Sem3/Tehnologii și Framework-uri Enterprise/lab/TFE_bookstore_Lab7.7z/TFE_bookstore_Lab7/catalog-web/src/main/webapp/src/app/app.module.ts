import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import {HttpClientModule} from '@angular/common/http';
import {FormsModule} from '@angular/forms';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { BooksComponent } from './books/books.component';
import { ClientsComponent } from './clients/clients.component';
import { BookListComponent } from './books/book-list/book-list.component';
import { BookNewComponent } from './books/book-new/book-new.component';
import { BookService } from './books/shared/book.service';
import { ClientNewComponent } from './clients/client-new/client-new.component';
import { ClientListComponent } from './clients/client-list/client-list.component';
import { ClientService } from './clients/shared/client.service';
import { BookDeleteComponent } from './books/book-delete/book-delete.component';
import { BookUpdateComponent } from './books/book-update/book-update.component';
import { ClientUpdateComponent } from './clients/client-update/client-update.component';
import { ClientDeleteComponent } from './clients/client-delete/client-delete.component';

@NgModule({
  declarations: [
    AppComponent,
    BooksComponent,
    ClientsComponent,
    BookListComponent,
    BookNewComponent,
    ClientNewComponent,
    ClientListComponent,
    BookDeleteComponent,
    BookUpdateComponent,
    ClientUpdateComponent,
    ClientDeleteComponent
  ],
  imports: [
    BrowserModule,
    FormsModule,
    HttpClientModule,
    AppRoutingModule,
  ],
  providers: [BookService, ClientService],
  bootstrap: [AppComponent]
})
export class AppModule { }
