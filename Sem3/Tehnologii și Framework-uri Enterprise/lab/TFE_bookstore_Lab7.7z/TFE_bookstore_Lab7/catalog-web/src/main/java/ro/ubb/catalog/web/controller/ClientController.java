package ro.ubb.catalog.web.controller;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import ro.ubb.catalog.core.model.Client;
import ro.ubb.catalog.core.service.ClientService;
import ro.ubb.catalog.web.converter.ClientConverter;
import ro.ubb.catalog.web.dto.ClientDto;
import ro.ubb.catalog.web.dto.ClientsDto;

import java.util.List;
import java.util.Set;

@RestController
public class ClientController {
    public static final Logger log = LoggerFactory.getLogger(ClientController.class);

    @Autowired
    private ClientService clientService;

    @Autowired
    private ClientConverter clientConverter;


    // @RequestMapping(value = "/clients", method = RequestMethod.GET)
    // ClientsDto getClients() {
    //     log.trace("getAllClients --- method entered");

    //     List<Client> clients = clientService.getAllClients();
    //     ClientsDto result = new ClientsDto(clientConverter
    //             .convertModelsToDtos(clients));

    //     log.trace("getAllClients: result={}", result);
    //     return result;
    // }

    @RequestMapping(value = "/clients")
    Set<ClientDto> getClients() {
        return clientConverter.convertModelsToDtos(
                clientService.getAllClients());

    }

    @RequestMapping(value = "/clients", method = RequestMethod.POST)
    ClientDto saveClient(@RequestBody ClientDto clientDto) {
        log.trace("saveClient --- method entered");

        Client savedClient = clientService.saveClient(
                clientConverter.convertDtoToModel(clientDto));
        ClientDto result = clientConverter.convertModelToDto(savedClient);

        log.trace("saveClient: Client saved -> result={}", result);
        return result;
    }

    @RequestMapping(value = "/clients/{id}", method = RequestMethod.PUT)
    ClientDto updateClient(@PathVariable Long id,
                           @RequestBody ClientDto clientDto) {
        log.trace("updateClient --- method entered");

        Client client = clientService.updateClient(id, clientConverter.convertDtoToModel(clientDto));

        log.trace("updateClient: update={}", client);
        return clientConverter.convertModelToDto(client);
    }

    @RequestMapping(value = "/clients/{id}", method = RequestMethod.DELETE)
    ResponseEntity<?> deleteClient(@PathVariable Long id) {
        log.trace("deleteClient --- method entered");

        clientService.deleteClient(id);

        log.trace("deleteClientById --- client deleted");
        return new ResponseEntity<>(HttpStatus.OK);
    }
}
