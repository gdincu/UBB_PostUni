export class Book {
  id: number;
  name: string;
  author: string;
  publisher: string;
  yearofpublication: string;
  price: number;
}
