import { Component, OnInit } from '@angular/core';
import {BookService} from "../shared/book.service";
import {Location} from "@angular/common";

@Component({
  selector: 'app-book-delete',
  templateUrl: './book-delete.component.html',
  styleUrls: ['./book-delete.component.css']
})

export class BookDeleteComponent implements OnInit {

  constructor(private bookService: BookService, private location: Location) {
  }

  ngOnInit() {
  }

  delete(id) {
    
    this.bookService.delete(id).subscribe(book => this.location.back(),
      err => console.log("Err in deleting book: ", err),
      () => console.log("completed"));
  }

  goBack() {
    this.location.back();
  }
}
