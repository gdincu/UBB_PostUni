import {NgModule} from '@angular/core';
import {RouterModule, Routes} from '@angular/router';
import {BooksComponent} from "./books/books.component";
import {BookListComponent} from "./books/book-list/book-list.component";
import {BookNewComponent} from "./books/book-new/book-new.component";
import {BookDeleteComponent} from "./books/book-delete/book-delete.component";
import {BookUpdateComponent} from "./books/book-update/book-update.component";
import {ClientsComponent} from "./clients/clients.component";
import {ClientNewComponent} from "./clients/client-new/client-new.component";
import {ClientDeleteComponent} from "./clients/client-delete/client-delete.component";
import {ClientUpdateComponent} from "./clients/client-update/client-update.component";
import {ClientListComponent} from './clients/client-list/client-list.component';


const routes: Routes = [
  // { path: '', redirectTo: '/home', pathMatch: 'full' },
  {path: 'books', component: BooksComponent},
  {path: 'book-new', component: BookNewComponent},
  {path: 'book-update', component: BookUpdateComponent},
  {path: 'book-delete', component: BookDeleteComponent},
  // {path: 'book/list/:id', component: BookListComponent},
  {path: 'book-list', component: BookListComponent},

  {path: 'clients', component: ClientsComponent},
  {path: 'client-new', component: ClientNewComponent},
  {path: 'client-update', component: ClientUpdateComponent},
  {path: 'client-delete', component: ClientDeleteComponent},
  // {path: 'client/list/:id', component: ClientListComponent},
  {path: 'client-list', component: ClientListComponent}

];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule {
}

