import {Injectable} from '@angular/core';
import {HttpClient} from '@angular/common/http';
import {Book} from "./book.model";

import {Observable} from "rxjs";
import { map } from "rxjs/operators";
import 'rxjs/add/operator/catch';
import 'rxjs/add/operator/map';

@Injectable()
export class BookService {
  private url = 'http://localhost:8080/api/books';

  constructor(private httpClient: HttpClient) {
  }

  getBooks(): Observable<Book[]> {
    return this.httpClient
      .get<Array<Book>>(this.url);
  }

  getBook(id: number): Observable<Book> {
    return this.getBooks()
      .map(books => books.find(book => book.id === id));
  }

  update(book): Observable<Book> {
    const url = `${this.url}/${book.id}`;
    return this.httpClient
      .put<Book>(url, book);
  }

  save(book: Book): Observable<Book> {
    console.log(book);
    return this.httpClient
      .post<Book>(this.url, book);
  }

  delete(id: number): Observable<any> {
    const url = `${this.url}/${id}`;
    console.log("delete url: ", url);
    return this.httpClient
      .delete(url);
  }



}
