package ro.ubb.catalog.core.model;

import lombok.*;

import javax.persistence.Entity;

/**
 * Created by radu.
 */
@Entity
@NoArgsConstructor
@AllArgsConstructor
@Getter
@Setter
@ToString(callSuper = true)
@Builder
public class Client extends BaseEntity<Long> {
    private String name;
    private String dateofregistration;
}
