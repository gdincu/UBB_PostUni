package ro.ubb.catalog.core.service;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import ro.ubb.catalog.core.model.Book;
import ro.ubb.catalog.core.repository.BookRepository;

import java.util.List;

/**
 * Created by radu.
 */
@Service
public class BookServiceImpl implements BookService {
    public static final Logger log = LoggerFactory.getLogger(BookServiceImpl.class);

    @Autowired
    private BookRepository bookRepository;


    @Override
    public List<Book> getAllBooks() {
        log.trace("getAllBooks --- method entered");

        List<Book> result = bookRepository.findAll();

        log.trace("getAllBooks: result={}", result);

        return result;
    }

    @Override
    public Book saveBook(Book book) {
        //todo: logs
        return bookRepository.save(book);
    }

    @Override
    @Transactional
    public Book updateBook(Long id, Book book) {
        //todo: logs
        Book update = bookRepository.findById(id).orElseThrow();
        update.setName(book.getName());
        update.setAuthor(book.getAuthor());
        update.setPrice(book.getPrice());
        update.setPublisher(book.getPublisher());
        update.setYearofpublication(book.getYearofpublication());

        return update;
    }

    @Override
    public void deleteBook(Long id) {
        //todo: logs

        bookRepository.deleteById(id);
    }
}
