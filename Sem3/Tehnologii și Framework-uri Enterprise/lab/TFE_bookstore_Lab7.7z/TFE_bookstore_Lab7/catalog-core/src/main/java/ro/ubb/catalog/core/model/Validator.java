package ro.ubb.catalog.core.model;

public interface Validator<T> {
    void validate(T entity) throws ValidatorException;
}
