export class Client {
  id: number;
  name: string;
  dateofregistration: string;
}
