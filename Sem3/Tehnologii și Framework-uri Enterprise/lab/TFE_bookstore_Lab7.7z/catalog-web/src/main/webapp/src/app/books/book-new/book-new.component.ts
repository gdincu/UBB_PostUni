import { Component, OnInit } from '@angular/core';
import {BookService} from "../shared/book.service";
import {Location} from "@angular/common";

@Component({
  selector: 'app-book-new',
  templateUrl: './book-new.component.html',
  styleUrls: ['./book-new.component.css']
})

export class BookNewComponent implements OnInit {

  constructor(private bookService: BookService, private location: Location) {
  }

  ngOnInit() {
  }

  save(name, author, publisher, yearofpublication, price) {
    const id = 0;
    this.bookService.save({
      id,
      name,
      author,
      publisher,
      yearofpublication,
      price
    }).subscribe(book => this.location.back(),
      err => console.log('Err in saving book: ', err),
      () => console.log('completed'));
  }

  goBack() {
    this.location.back();
  }
}
