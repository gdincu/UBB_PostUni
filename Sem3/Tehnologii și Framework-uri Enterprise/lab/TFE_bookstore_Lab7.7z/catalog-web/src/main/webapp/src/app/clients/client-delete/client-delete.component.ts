import { Component, OnInit } from '@angular/core';
import {ClientService} from "../shared/client.service";
import {Location} from "@angular/common";

@Component({
  selector: 'app-client-delete',
  templateUrl: './client-delete.component.html',
  styleUrls: ['./client-delete.component.css']
})

export class ClientDeleteComponent implements OnInit {

  constructor(private clientService: ClientService, private location: Location) {
  }

  ngOnInit() {
  }

  delete(id) {
    
    this.clientService.delete(id).subscribe(client => this.location.back(),
      err => console.log("Err in deleting client: ", err),
      () => console.log("completed"));
  }

  goBack() {
    this.location.back();
  }
}
