import {Component, OnInit} from '@angular/core';
import {Client} from "../shared/client.model";
import {ClientService} from "../shared/client.service";
import {Router} from "@angular/router";
import {Location} from "@angular/common";


@Component({
  selector: 'app-client-list',
  templateUrl: './client-list.component.html',
  styleUrls: ['./client-list.component.css'],
})
export class ClientListComponent implements OnInit {
  errorMessage: string;
  clients: Array<Client>;
  selectedClient: Client;

  constructor(private clientService: ClientService,
              private router: Router, private location: Location) {
  }

  ngOnInit(): void {
    this.getClients();
  }

  getClients() {
    this.clientService.getClients()
      .subscribe(
        clients => this.clients = clients,
        error => this.errorMessage = <any>error
      );
  }

  onSelect(client: Client): void {
    this.selectedClient = client;
  }

  gotoUpdate(): void {
    this.router.navigate(['/client/update', this.selectedClient.id]);
  }

  delete(client: Client) {
    this.clientService.delete(client.id)
      .subscribe(_ => {
        console.log("Client deleted");
        this.clients = this.clients.filter(s => s.id !== client.id);
      });
  }

  goBack() {
    this.location.back();
  }
}
