import { Component, OnInit } from '@angular/core';
import {ClientService} from "../shared/client.service";
import {Location} from "@angular/common";

@Component({
  selector: 'app-client-new',
  templateUrl: './client-new.component.html',
  styleUrls: ['./client-new.component.css']
})

export class ClientNewComponent implements OnInit {

  constructor(private clientService: ClientService, private location: Location) {
  }

  ngOnInit() {
  }

  save(id, name, dateofregistration) {
    // const id = 0;
    this.clientService.save({
      id,
      name,
      dateofregistration
    }).subscribe(client => this.location.back(),
      err => console.log("Err in saving client: ", err),
      () => console.log("completed"));
  }

  goBack() {
    this.location.back();
  }
}