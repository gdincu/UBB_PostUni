import {Component, OnInit} from '@angular/core';
import {Book} from "../shared/book.model";
import {BookService} from "../shared/book.service";
import {Router} from "@angular/router";
import {Location} from "@angular/common";


@Component({
  // moduleId: module.id,
  selector: 'app-book-list',
  templateUrl: './book-list.component.html',
  styleUrls: ['./book-list.component.css'],
})
export class BookListComponent implements OnInit {
  errorMessage: string;
  books: Array<Book>;
  selectedBook: Book;

  constructor(private bookService: BookService,
              private router: Router, private location: Location) {
  }

  ngOnInit(): void {
    this.getBooks();
  }

  getBooks() {
    this.bookService.getBooks()
      .subscribe(
        books => this.books = books,
        error => this.errorMessage = 'error'
      );
  }

  onSelect(book: Book): void {
    this.selectedBook = book;
  }

  gotoUpdate(): void {
    this.router.navigate(['/book/update', this.selectedBook.id]);
  }

  delete(book: Book) {
    this.bookService.delete(book.id)
      .subscribe(_ => {
        console.log('Book deleted');
        this.books = this.books.filter(s => s.id !== book.id);
      });
  }

  save(name, author, publisher, yearOfPublication, price) {
    const id = 0;
    this.bookService.save({
      id,
      name,
      author,
      publisher,
      yearOfPublication,
      price
    }).subscribe(_ => window.location.reload());
  }

  goBack() {
    this.location.back();
  }
}
