import {Injectable} from '@angular/core';
import {Observable} from 'rxjs';
import {HttpClient} from '@angular/common/http';
// import { HttpClientModule } from '@angular/common/http';
import {Client} from "./client.model";
import { map } from "rxjs/operators";
import 'rxjs/add/operator/catch';
import 'rxjs/add/operator/map';
import 'rxjs/Rx';

@Injectable()
export class ClientService {
  private url = 'http://localhost:8080/api/clients';

  constructor(private httpClient: HttpClient) {
  }

  getClients(): Observable<Client[]> {
    return this.httpClient
      .get<Array<Client>>(this.url);
  }

  getClient(id: number): Observable<Client> {
    return this.getClients()
      .map(clients => clients.find(client => client.id === id));
  }

  update(client): Observable<Client> {
    const url = `${this.url}/${client.id}`;
    return this.httpClient
      .put<Client>(url, client);
  }

  save(client: Client): Observable<Client> {
    console.log(client);
    return this.httpClient
      .post<Client>(this.url, client);
  }

  delete(id: number): Observable<any> {
    const url = `${this.url}/${id}`;
    console.log("delete url: ", url);
    return this.httpClient
      .delete(url);
  }



}
