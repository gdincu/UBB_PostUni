package ro.ubb.catalog.web.dto;

import lombok.*;

/**
 * Created by radu.
 */
@NoArgsConstructor
@AllArgsConstructor
@Getter
@Setter
@ToString(callSuper = true)
@Builder
public class BookDto extends BaseDto {
    private String name;
    private String author;
    private String publisher;
    private double price;
    private String yearOfPublication;
}
