package ro.ubb.catalog.web.converter;

import org.springframework.stereotype.Component;
import ro.ubb.catalog.core.model.Book;
import ro.ubb.catalog.web.dto.BookDto;

/**
 * Created by radu.
 */
@Component
public class BookConverter extends BaseConverter<Book, BookDto> {
    @Override
    public Book convertDtoToModel(BookDto dto) {
        Book client = Book.builder()
                .name(dto.getName())
                .author(dto.getAuthor())
                .publisher(dto.getPublisher())
                .yearofpublication(dto.getYearOfPublication())
                .price(dto.getPrice())
                .build();
        client.setId(dto.getId());
        return client;
    }

    @Override
    public BookDto convertModelToDto(Book book) {
        BookDto dto = BookDto.builder()
                .name(book.getName())
                .author(book.getAuthor())
                .publisher(book.getPublisher())
                .yearOfPublication(book.getYearofpublication())
                .price(book.getPrice())
                .build();
        dto.setId(book.getId());
        return dto;
    }
}
