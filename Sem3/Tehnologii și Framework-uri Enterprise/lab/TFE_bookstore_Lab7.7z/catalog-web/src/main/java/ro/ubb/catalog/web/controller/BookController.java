package ro.ubb.catalog.web.controller;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import ro.ubb.catalog.core.model.Book;
import ro.ubb.catalog.core.service.BookService;
import ro.ubb.catalog.core.service.ClientService;
import ro.ubb.catalog.web.converter.BookConverter;
import ro.ubb.catalog.web.converter.ClientConverter;
import ro.ubb.catalog.web.dto.BookDto;
import ro.ubb.catalog.web.dto.BooksDto;

import java.util.List;
import java.util.Set;

@RestController
public class BookController {
    public static final Logger log = LoggerFactory.getLogger(BookController.class);

    @Autowired
    private BookService bookService;

    @Autowired
    private BookConverter bookConverter;


//    @RequestMapping(value = "/books", method = RequestMethod.GET)
//    BooksDto getBooks() {
//        log.trace("getAllBooks --- method entered");
//
//        List<Book> books = bookService.getAllBooks();
//        BooksDto result = new BooksDto(bookConverter
//                .convertModelsToDtos(books));
//
//        log.trace("getAllBooks: result={}", result);
//        return result;
//    }

    @RequestMapping(value = "/books")
    Set<BookDto> getBooks() {
        return bookConverter.convertModelsToDtos(
                bookService.getAllBooks());

    }

    @RequestMapping(value = "/books", method = RequestMethod.POST)
    BookDto saveBook(@RequestBody BookDto bookDto) {
        log.trace("saveBook --- method entered");

        Book savedBook = bookService.saveBook(
                bookConverter.convertDtoToModel(bookDto));
        BookDto result = bookConverter.convertModelToDto(savedBook);

        log.trace("saveBook: Book saved -> result={}", result);
        return result;
    }

    @RequestMapping(value = "/books/{id}", method = RequestMethod.PUT)
    BookDto updateBook(@PathVariable Long id,
                           @RequestBody BookDto bookDto) {
        log.trace("updateBook --- method entered");

        Book book = bookService.updateBook(id, bookConverter.convertDtoToModel(bookDto));

        log.trace("updateBook: update={}", book);
        return bookConverter.convertModelToDto(book);
    }

    @RequestMapping(value = "/books/{id}", method = RequestMethod.DELETE)
    ResponseEntity<?> deleteBook(@PathVariable Long id) {
        log.trace("deleteBook --- method entered");

        bookService.deleteBook(id);

        log.trace("deleteBookById --- book deleted");
        return new ResponseEntity<>(HttpStatus.OK);
    }
}
