package ro.ubb.catalog.core.repository;

import ro.ubb.catalog.core.model.Book;

/**
 * Created by radu.
 */
public interface BookRepository
        extends org.springframework.data.jpa.repository.JpaRepository<Book, Long> {
}
