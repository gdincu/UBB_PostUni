package ro.ubb.catalog.core.repository;

import ro.ubb.catalog.core.model.Client;

public interface ClientRepository
        extends GenericRepository <Client, Long> {
}
