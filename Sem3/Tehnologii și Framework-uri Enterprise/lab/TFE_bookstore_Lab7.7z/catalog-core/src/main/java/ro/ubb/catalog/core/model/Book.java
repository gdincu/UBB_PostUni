package ro.ubb.catalog.core.model;

import lombok.*;

import javax.persistence.Entity;

/**
 * Created by radu.
 */
@Entity
@NoArgsConstructor
@AllArgsConstructor
@Getter
@Setter
@ToString(callSuper = true)
@Builder
public class Book extends BaseEntity<Long> {
    private String name;
    private String author;
    public String publisher;
    private String yearofpublication;
    private double price;
}
