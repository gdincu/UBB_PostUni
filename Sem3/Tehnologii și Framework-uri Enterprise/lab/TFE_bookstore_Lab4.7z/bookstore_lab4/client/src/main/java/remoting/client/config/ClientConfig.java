package remoting.client.config;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.remoting.rmi.RmiProxyFactoryBean;
import remoting.client.service.BookServiceClient;
import remoting.client.service.ClientServiceClient;
import remoting.client.ui.Console;
import remoting.common.service.BookService;
import remoting.common.service.ClientService;

@Configuration
public class ClientConfig {
    @Bean
    RmiProxyFactoryBean rmiProxyFactoryBean() {
        RmiProxyFactoryBean rmiProxyFactoryBean = new RmiProxyFactoryBean();
        rmiProxyFactoryBean.setServiceInterface(BookService.class);
        rmiProxyFactoryBean.setServiceUrl("rmi://localhost:1099/BookService");

        return rmiProxyFactoryBean;
    }

    @Bean
    RmiProxyFactoryBean rmiProxyFactoryBean2() {
        RmiProxyFactoryBean rmiProxyFactoryBean2 = new RmiProxyFactoryBean();

        rmiProxyFactoryBean2.setServiceInterface(ClientService.class);
        rmiProxyFactoryBean2.setServiceUrl("rmi://localhost:1099/ClientService");

        return rmiProxyFactoryBean2;
    }

    @Bean
    BookServiceClient BookServiceClient() {
        return new BookServiceClient();
    }

    @Bean
    ClientServiceClient ClientServiceClient() {
        return new ClientServiceClient();
    }

    @Bean
    Console console() {
        return new Console(BookServiceClient(), ClientServiceClient());
    }

}
