package remoting.client;

import org.springframework.context.annotation.AnnotationConfigApplicationContext;
import remoting.client.ui.Console;

import java.io.IOException;


public class ClientApp {

    public static void main(String[] args) throws IOException {

        AnnotationConfigApplicationContext context =
                new AnnotationConfigApplicationContext(
                        "remoting.client.config");


        Console console = context.getBean(Console.class);

//        console.showMenu();
        console.runConsole();

        System.out.println("bye client");
    }
}


