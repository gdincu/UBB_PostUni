package remoting.client.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import remoting.common.service.BookService;
import remoting.common.domain.Book;
import java.util.List;


public class BookServiceClient implements BookService {

    @Autowired
    private BookService bookService;

    @Override
    public void save(Book book) {
        bookService.save(book);
    }

    @Override
    public void update(Book book) {
        bookService.update(book);
    }

    @Override
    public void delete(Integer id) {
        bookService.delete(id);
    }

    @Override
    public List<Book> getAllBooks() {
        return bookService.getAllBooks();
    }
}
