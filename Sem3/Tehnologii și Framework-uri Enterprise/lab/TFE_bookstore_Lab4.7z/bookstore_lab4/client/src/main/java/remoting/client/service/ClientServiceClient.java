package remoting.client.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import remoting.common.service.ClientService;
import remoting.common.domain.Client;
import java.util.List;


public class ClientServiceClient implements ClientService {


    @Autowired
    private ClientService clientService;


    @Override
    public void save(Client client) {
        clientService.save(client);
    }

    @Override
    public void update(Client client) {
        clientService.update(client);
    }

    @Override
    public void delete(Integer id) {
        clientService.delete(id);
    }

    @Override
    public List<Client> getAllClients() {
        return clientService.getAllClients();
    }
}
