package remoting.server.service;

import remoting.common.service.BookService;
import remoting.common.domain.Book;
import remoting.server.repository.Repository;
import java.util.ArrayList;
import java.util.List;

public class BookServiceServer implements BookService {

    private Repository<Integer, Book> bookRepository;

    public BookServiceServer(Repository<Integer, Book> bookRepository) {
        this.bookRepository = bookRepository;
    }

    @Override
    public void save(Book book) {
        this.bookRepository.save(book);
    }

    @Override
    public void update(Book book) {
        this.bookRepository.update(book);
    }

    @Override
    public void delete(Integer id) {
        this.bookRepository.delete(id);
    }

    @Override
    public List<Book> getAllBooks() {
        List<Book> book = new ArrayList<>();
        this.bookRepository.findAll().forEach(book::add);

        return book;
    }
}
