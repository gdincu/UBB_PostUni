package remoting.server.service;

import remoting.common.service.ClientService;
import remoting.common.domain.Client;
import remoting.server.repository.Repository;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import java.util.Set;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Future;
import java.util.stream.Collectors;
import java.util.stream.StreamSupport;

public class ClientServiceServer implements ClientService {
    private Repository<Integer, Client> clientRepository;

    public ClientServiceServer(Repository<Integer, Client> clientRepository) {
        this.clientRepository = clientRepository;
    }

    @Override
    public void save(Client client) {
        this.clientRepository.save(client);
    }

    @Override
    public void delete(Integer id) {
        this.clientRepository.delete(id);
    }

    @Override
    public void update(Client client) {
        this.clientRepository.update(client);
    }

    @Override
    public List<Client> getAllClients() {
        List<Client> client = new ArrayList<>();
        this.clientRepository.findAll().forEach(client::add);
        return client;
    }
}
