package remoting.server.config;


import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.remoting.rmi.RmiServiceExporter;
import remoting.common.domain.Book;
import remoting.common.domain.Client;
import remoting.common.service.BookService;
import remoting.common.service.ClientService;
import remoting.server.repository.BookDataBaseRepository;
import remoting.server.repository.ClientDataBaseRepository;
import remoting.server.repository.Repository;
import remoting.server.service.BookServiceServer;
import remoting.server.service.ClientServiceServer;

@Configuration
public class ServerConfig {
    @Bean
    RmiServiceExporter rmiServiceExporter1() {
        RmiServiceExporter exporter1 = new RmiServiceExporter();
        exporter1.setServiceName("BookService");
        exporter1.setServiceInterface(BookService.class);
        exporter1.setService(bookService());
        return exporter1;
    }


    @Bean
    RmiServiceExporter rmiServiceExporter2(){
        RmiServiceExporter  exporter2= new RmiServiceExporter();
        exporter2.setServiceName("ClientService");
        exporter2.setServiceInterface(ClientService.class);
        exporter2.setService(clientService());
        return exporter2;
    }

    @Bean
    BookService bookService(){
        return new BookServiceServer(bookRepository());
    }

    @Bean
    Repository<Integer, Book> bookRepository() {
        return new BookDataBaseRepository();
    }

    @Bean
    ClientService clientService(){
        return new ClientServiceServer(clientRepository());
    }

    @Bean
    Repository<Integer, Client> clientRepository(){
        return new ClientDataBaseRepository();
    }
}
