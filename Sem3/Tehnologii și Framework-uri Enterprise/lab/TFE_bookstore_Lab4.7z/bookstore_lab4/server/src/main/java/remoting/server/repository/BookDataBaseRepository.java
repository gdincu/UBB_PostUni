package remoting.server.repository;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcOperations;
import remoting.common.domain.Book;

import java.util.List;

public class BookDataBaseRepository implements Repository<Integer, Book> {

    @Autowired
    private JdbcOperations jdbcOperations;

    @Override
    public void save(Book book) {
        String sql = "INSERT INTO book (id, name, author, publisher, yearofpublication, price) VALUES (?,?,?,?,?,?)";
        jdbcOperations.update(sql, book.getId(), book.getName(), book.getAuthor(), book.getPublisher(), book.getYearOfPublication(), book.getPrice());
    }

    @Override
    public List<Book> findAll() {
        String sql = "SELECT * FROM book";
        return jdbcOperations.query(sql, (rs, i) -> {
            Book book = new Book();
            book.setId(rs.getInt("id"));
            book.setName(rs.getString("name"));
            book.setAuthor(rs.getString("author"));
            book.setPublisher(rs.getString("publisher"));
            book.setYearOfPublication(rs.getString("yearofpublication"));
            book.setPrice(rs.getDouble("price"));
            return book;
        });
    }

    @Override
    public void delete(Integer id) {
        String sql = "DELETE FROM book WHERE id=?";
        jdbcOperations.update(sql, id);
    }


    @Override
    public void update(Book book) {
        String sql = "UPDATE book SET(name, author, publisher, yearofpublication, price) = (?,?,?,?,?) WHERE id=?";
        jdbcOperations.update(sql, book.getName(), book.getAuthor(), book.getPublisher(), book.getYearOfPublication(), book.getPrice(), book.getId());
    }
}
