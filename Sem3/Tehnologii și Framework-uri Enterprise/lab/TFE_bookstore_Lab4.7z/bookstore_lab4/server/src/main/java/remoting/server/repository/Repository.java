package remoting.server.repository;

import org.xml.sax.SAXException;
import remoting.common.domain.BaseEntity;
import remoting.common.domain.validators.ValidatorException;

import javax.xml.parsers.ParserConfigurationException;
import java.io.IOException;
import java.util.List;
import java.util.Optional;

public interface Repository<ID, T extends BaseEntity<ID>> {

    void save(T entity);

    List<T> findAll();

    void delete(ID id);

    void update(T book);
}
