package remoting.server.repository;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcOperations;
import remoting.common.domain.Client;
import java.util.List;


public class ClientDataBaseRepository implements Repository<Integer, Client>{

    @Autowired
    private JdbcOperations jdbcOperations;


    @Override
    public void save(Client client) {
        String sql = "INSERT INTO clients (id, name, dateofregistration) VALUES (?,?,?)";
        jdbcOperations.update(sql, client.getId(), client.getName(), client.getDateOfRegistration());
    }

    @Override
    public List<Client> findAll() {
        String sql = "SELECT * FROM clients";
        return jdbcOperations.query(sql, (rs, i) -> {
            Client client = new Client();
            client.setId(rs.getInt("id"));
            client.setName(rs.getString("name"));
            client.setDateOfRegistration(rs.getString("dateofregistration"));
            return client;
        });
    }

    @Override
    public void delete(Integer id) {
        String sql = "DELETE FROM clients WHERE id=?";
        jdbcOperations.update(sql, id);
    }

    @Override
    public void update(Client client) {
        String sql = "UPDATE clients set(name,dateofregistration) = (?, ?) WHERE id=? ";
        jdbcOperations.update(sql, client.getName(), client.getDateOfRegistration(), client.getId());
    }
}
