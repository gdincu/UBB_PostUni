package remoting.common.service;

import remoting.common.domain.Client;

import java.util.List;

public interface ClientService {
    void save(Client client);

    void update(Client client);

    void delete(Integer id);

    List<Client> getAllClients();

}
