package remoting.common.service;

import remoting.common.domain.Book;

import java.util.List;

public interface BookService {
    void save(Book book);

    void update(Book book);

    void delete(Integer id);

    List<Book> getAllBooks();

}
