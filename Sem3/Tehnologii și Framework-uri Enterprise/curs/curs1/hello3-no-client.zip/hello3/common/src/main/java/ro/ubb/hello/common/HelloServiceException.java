package ro.ubb.hello.common;

/**
 * Created by radu.
 */
public class HelloServiceException extends RuntimeException {
}
