package ro.ubb.hello.common;

import java.util.concurrent.Future;

/**
 * Created by radu.
 */
public interface HelloService {
    int PORT = 1234;

    String SAY_HELLO = "sayHello";

    Future<String> sayHello(String name);
}
