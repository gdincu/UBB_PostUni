package ro.ubb.hello.server.tcp;

import ro.ubb.hello.common.Message;

import java.io.IOException;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.ExecutorService;
import java.util.function.UnaryOperator;

/**
 * Created by radu.
 */
public class TcpServer {
    private ExecutorService executorService;
    private int port;
    private Map<String, UnaryOperator<Message>> methodHandlers;

    public TcpServer(ExecutorService executorService, int port) {
        this.executorService = executorService;
        this.port = port;
        this.methodHandlers = new HashMap<>();
    }

    public void addHandler(String key, UnaryOperator<Message> handler) {
        methodHandlers.put(key, handler);
    }

    public void startServer() {
        try (var serverSocket = new ServerSocket(port)) {
            while (true) {
                Socket clientSocket = serverSocket.accept();
                System.out.println("client connected");
                executorService.submit(new ClientHandler(clientSocket));

            }

        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    class ClientHandler implements Runnable {
        private Socket socket;

        public ClientHandler(Socket socket) {
            this.socket = socket;
        }

        @Override
        public void run() {
            try (var is = socket.getInputStream();
                 var os = socket.getOutputStream()) {
                //Message request - get message from is
                Message request = new Message();
                request.readFrom(is);


                //compute response of type Message
                Message response = methodHandlers.get(request.getHeader())
                        .apply(request);

                //write response to os
                response.writeTo(os);

            } catch (IOException e) {
                e.printStackTrace();
            }
        }
    }
}

