package ro.ubb.hello.server.service;

import ro.ubb.hello.common.HelloService;

import java.util.concurrent.ExecutorService;
import java.util.concurrent.Future;

/**
 * Created by radu.
 */
public class HelloServiceImpl implements HelloService {
    private ExecutorService executorService;

    public HelloServiceImpl(ExecutorService executorService) {
        this.executorService = executorService;
    }

    @Override
    public Future<String> sayHello(String name) {
        //return "Hello "+name
        return executorService.submit(() -> {
            return "Hello " + name;
        });
    }
}
