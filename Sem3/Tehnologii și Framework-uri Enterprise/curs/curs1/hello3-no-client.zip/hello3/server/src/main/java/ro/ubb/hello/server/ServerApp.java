package ro.ubb.hello.server;

import ro.ubb.hello.common.HelloService;
import ro.ubb.hello.common.Message;
import ro.ubb.hello.server.service.HelloServiceImpl;
import ro.ubb.hello.server.tcp.TcpServer;

import java.util.concurrent.ExecutionException;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;

/**
 * Created by radu.
 */
public class ServerApp {
    public static void main(String[] args) {
        ExecutorService executorService = Executors.newFixedThreadPool(
                Runtime.getRuntime().availableProcessors()
        );
        HelloService helloService = new HelloServiceImpl(executorService);
        TcpServer tcpServer = new TcpServer(executorService, HelloService.PORT);

        tcpServer.addHandler(HelloService.SAY_HELLO, request -> {
            Future<String> res = helloService.sayHello(request.getBody());
            try {
                String result = res.get();
                Message response = new Message(Message.OK, result);
                return response;
            } catch (InterruptedException | ExecutionException e) {
                e.printStackTrace();
                return new Message(Message.ERROR, e.getMessage());
            }
        });

        tcpServer.startServer();

        System.out.println("bye server");
    }
}
