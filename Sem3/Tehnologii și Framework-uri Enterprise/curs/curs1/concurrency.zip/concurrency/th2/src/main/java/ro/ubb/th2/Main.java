package ro.ubb.th2;

/**
 * author: radu
 */
public class Main {
    public static void main(String[] args) {
        ex01();

        System.out.println("bye");
    }

    private static void ex01() {
        Counter counter = new Counter();
        for (int i = 0; i < 10; i++) {
            new Thread(new CounterRunnable(counter)).start();
        }
    }
}

class Counter {
    private static int count = 0;

    public  void doCount() {
        count++;
        try {
            Thread.sleep(count);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
        System.out.println("count=" + count);
    }
}

class CounterRunnable implements Runnable {
    private Counter counter;

    public CounterRunnable(Counter counter) {
        this.counter = counter;
    }

    @Override
    public void run() {
        counter.doCount();
    }
}
