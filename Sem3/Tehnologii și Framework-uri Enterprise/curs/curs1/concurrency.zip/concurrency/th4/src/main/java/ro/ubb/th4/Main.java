package ro.ubb.th4;

import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/**
 * author: radu
 */
public class Main {
    public static void main(String[] args) {
        ex01();

        System.out.println("bye");
    }

    private static void ex01() {
        ExecutorService service = Executors.newSingleThreadExecutor();
//        ExecutorService service = Executors.newFixedThreadPool(4);
//        ExecutorService service =
//                Executors.newFixedThreadPool(
//                        Runtime.getRuntime().availableProcessors());
//        ExecutorService service =
//                Executors.newCachedThreadPool();


        System.out.println("a");
        service.submit(() -> System.out.println("1"));
        System.out.println("b");
        service.submit(() -> {
            try {
                Thread.sleep(1000);
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
            System.out.println("2");
        });
        System.out.println("c");
        service.submit(() -> System.out.println("3"));
        System.out.println("d");

        service.shutdown();
    }


}
