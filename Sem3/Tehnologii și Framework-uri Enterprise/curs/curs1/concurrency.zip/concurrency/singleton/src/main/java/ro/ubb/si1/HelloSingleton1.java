package ro.ubb.si1;

/**
 * author: radu
 */
class HelloSingleton1 {
    private static HelloSingleton1 instance = null;

    private String greeting;

    private HelloSingleton1() {
        System.out.println("ctor1");
        greeting = "hello1";

        try {
            Thread.sleep(1000);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
    }

    public static HelloSingleton1 getInstance() {
        if (instance == null) {
            instance = new HelloSingleton1();
        }
        return instance;
    }

    public String getGreeting() {
        return greeting;
    }
}
