package ro.ubb.si1;

/**
 * author: radu
 */
class HelloSingleton3 {
    private static volatile HelloSingleton3 instance = null;

    private String greeting;

    private HelloSingleton3() {
        System.out.println("ctor3");
        greeting = "hello3";

        try {
            Thread.sleep(1000);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
    }

    public static HelloSingleton3 getInstance() {

        if (instance == null) {
            synchronized (HelloSingleton3.class) {

                instance = new HelloSingleton3();

            }
        }
        return instance;
    }

    public String getGreeting() {
        return greeting;
    }
}
