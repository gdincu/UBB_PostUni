package ro.ubb.si1;

/**
 * author: radu
 */
class HelloSingleton5 {
    private static final HelloSingleton5 instance = new HelloSingleton5();

    private String greeting;

    private HelloSingleton5() {
        System.out.println("ctor5");
        greeting = "hello5";

        try {
            Thread.sleep(1000);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
    }

    public static HelloSingleton5 getInstance() {
        return instance;
    }

    public String getGreeting() {
        return greeting;
    }
}
