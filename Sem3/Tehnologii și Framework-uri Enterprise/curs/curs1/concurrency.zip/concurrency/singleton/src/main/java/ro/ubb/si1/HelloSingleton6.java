package ro.ubb.si1;

/**
 * author: radu
 */
class HelloSingleton6 {
    private static class InstanceHolder {
        private static final HelloSingleton6 instance = new HelloSingleton6();
    }

    private String greeting;

    private HelloSingleton6() {
        System.out.println("ctor6");
        greeting = "hello6";

        try {
            Thread.sleep(1000);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
    }

    public static HelloSingleton6 getInstance() {
        return InstanceHolder.instance;
    }

    public String getGreeting() {
        return greeting;
    }
}
