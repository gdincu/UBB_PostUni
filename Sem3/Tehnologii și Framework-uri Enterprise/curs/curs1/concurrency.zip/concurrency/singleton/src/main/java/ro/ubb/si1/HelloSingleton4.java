package ro.ubb.si1;

/**
 * author: radu
 */
class HelloSingleton4 {
    private static volatile HelloSingleton4 instance = null;

    private String greeting;

    private HelloSingleton4() {
        System.out.println("ctor4");
        greeting = "hello4";

        try {
            Thread.sleep(1000);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
    }

    public static HelloSingleton4 getInstance() {
        if (instance == null) {
            synchronized (HelloSingleton4.class) {
                if (instance == null) {
                    instance = new HelloSingleton4();
                }
            }
        }
        return instance;
    }

    public String getGreeting() {
        return greeting;
    }
}
