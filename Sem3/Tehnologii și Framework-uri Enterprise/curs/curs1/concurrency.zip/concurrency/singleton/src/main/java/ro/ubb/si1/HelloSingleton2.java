package ro.ubb.si1;

/**
 * author: radu
 */
class HelloSingleton2 {
    private static HelloSingleton2 instance = null;

    private String greeting;

    private HelloSingleton2() {
        System.out.println("ctor2");
        greeting = "hello2";

        try {
            Thread.sleep(1000);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
    }

    public static synchronized HelloSingleton2 getInstance() {

        if (instance == null) {

            instance = new HelloSingleton2();
        }
        return instance;
    }

    public String getGreeting() {
        return greeting;
    }
}
