package ro.ubb.si1;

/**
 * author: radu
 */
enum HelloSingleton7 {
    INSTANCE;

    private String greeting;

    HelloSingleton7() {
        System.out.println("ctor7");
        this.greeting = "hello7";

        try {
            Thread.sleep(1000);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
    }

    public String getGreeting() {
        return greeting;
    }

}

