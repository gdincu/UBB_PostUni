package ro.ubb.si1;

import java.util.Map;
import java.util.Random;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.function.Supplier;

/**
 * author: radu
 * <p>
 * Singleton
 * <p>
 * 1 - single thread
 * 2 - thread safe
 */
public class Main {
    public static void main(String[] args) {
//        ex01();

        ex02();

        System.out.println("bye");
    }


    private static void ex01() {
        HelloSingleton1 hs1 = HelloSingleton1.getInstance();
        System.out.println(hs1.getGreeting());

        HelloSingleton1 hs2 = HelloSingleton1.getInstance();
        System.out.println(hs2.getGreeting());

        for (int i = 0; i < 10; i++) {
            System.out.println(HelloSingleton1.getInstance().getGreeting());
        }
    }

    private static void ex02() {

        ExecutorService executor = Executors.newFixedThreadPool(10);

        for (int i = 0; i < 10; i++) {
            executor.submit(() -> {
                System.out.println(
                        getGreetingSupplierFromSingleton(
                                "HelloSingleton3").get());
            });
        }

        executor.shutdown();
    }

    private static Supplier<String> getGreetingSupplierFromSingleton(
            String singletonName) {
        Map<String, Supplier<String>> map = Map.of(
                "HelloSingleton1",
                () -> HelloSingleton1.getInstance().getGreeting(),

                "HelloSingleton2",
                () -> HelloSingleton2.getInstance().getGreeting(),

                "HelloSingleton3",
                () -> HelloSingleton3.getInstance().getGreeting(),

                "HelloSingleton4",
                () -> HelloSingleton4.getInstance().getGreeting(),

                "HelloSingleton5",
                () -> HelloSingleton5.getInstance().getGreeting(),

                "HelloSingleton6",
                () -> HelloSingleton6.getInstance().getGreeting(),

                "HelloSingleton7",
                () -> HelloSingleton7.INSTANCE.getGreeting()
        );

        return map.get(singletonName);
    }
}
