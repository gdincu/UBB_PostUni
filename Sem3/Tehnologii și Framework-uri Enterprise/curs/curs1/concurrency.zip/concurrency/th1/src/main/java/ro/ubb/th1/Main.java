package ro.ubb.th1;

/**
 * author: radu
 * <p>
 * 1 - Thread
 * 2 - Runnable
 */
public class Main {
    public static void main(String[] args) {
//        ex01();

        ex02();

        System.out.println("bye");

    }

    private static void ex01() {
        new Printer().start();
    }





    private static void ex02() {
        new Thread(new Printer2("th1")).start();
        new Thread(new Printer2("th2")).start();
        new Thread(new Printer2("th3")).start();
    }
}

class Printer extends Thread {
    @Override
    public void run() {
        for (int i = 1; i <= 3; i++) {
            System.out.println("i=" + i);
        }
    }
}








class Printer2 implements Runnable {
    private String name;

    public Printer2(String name) {
        this.name = name;
    }

    @Override
    public void run() {
        for (int i = 1; i <= 3; i++) {
            System.out.println(name + ": i=" + i);
            try {
                Thread.sleep(i);
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
        }
    }
}
