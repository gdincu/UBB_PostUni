package ro.ubb.th3;

import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/**
 * author: radu
 * <p>
 * 1 - executors
 * 2 - synchronized
 */
public class Main {
    public static void main(String[] args) {

//        ex01();

        ex02();

        System.out.println("bye");
    }

    private static void ex01() {
        ExecutorService service = Executors.newFixedThreadPool(10);

        Counter counter = new Counter();
        for (int i = 0; i < 10; i++) {
            service.submit(() -> counter.doCount());
        }

        service.shutdown();
    }





    private static void ex02() {
        ExecutorService service = Executors.newFixedThreadPool(10);

        Counter2 counter = new Counter2();
        for (int i = 0; i < 10; i++) {
            service.submit(() -> counter.doCount());
        }

        service.shutdown();
    }
}

class Counter {
    private static int count = 0;

    public void doCount() {
        count++;
        try {
            Thread.sleep(count);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
        System.out.println("count=" + count);
    }
}






class Counter2 {
    private static int count = 0;

    public synchronized void doCount() {
        count++;
        try {
            Thread.sleep(count);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
        System.out.println("count=" + count);
    }
}

