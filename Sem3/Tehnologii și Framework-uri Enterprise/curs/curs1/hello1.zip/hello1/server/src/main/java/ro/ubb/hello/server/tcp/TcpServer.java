package ro.ubb.hello.server.tcp;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.concurrent.ExecutorService;

/**
 * Created by radu.
 */
public class TcpServer {
    private ExecutorService service;

    public TcpServer(ExecutorService service) {
        this.service = service;
    }

    public void startServer() {
        System.out.println("waiting for clients...");
        try (var serverSocket = new ServerSocket(1234)) {
            while (true) {
                Socket clientSocket = serverSocket.accept();
                System.out.println("client connected");

                service.submit(new ClientHandler(clientSocket));
            }

        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}

class ClientHandler implements Runnable {
    private Socket socket;

    public ClientHandler(Socket socket) {
        this.socket = socket;
    }

    @Override
    public void run() {
        try (var is = socket.getInputStream();
             var os = socket.getOutputStream();
             var br = new BufferedReader(new InputStreamReader(is))
        ) {
            System.out.println("processing client");

            String name = br.readLine();
            System.out.println("received request: " + name);

            String result = "Hello " + name;

            os.write(result.getBytes());//

        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}