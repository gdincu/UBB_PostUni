package ro.ubb.hello.client;

import ro.ubb.hello.client.tcp.TcpClient;

/**
 * Created by radu.
 */
public class ClientApp {
    public static void main(String[] args) {
        TcpClient tcpClient = new TcpClient();

        tcpClient.sayHello();

        System.out.println("bye client");
    }
}
