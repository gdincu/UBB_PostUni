package ro.ubb.hello.client.tcp;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.Socket;
import java.net.UnknownHostException;

/**
 * Created by radu.
 */
public class TcpClient {
    public void sayHello() {
        try (var socket = new Socket("localhost", 1234);
             var is = socket.getInputStream();
             var os = socket.getOutputStream();
             var br = new BufferedReader(new InputStreamReader(is))) {

            String request = "John\n";
            os.write(request.getBytes());
            System.out.println("sent request: " + request);

            String response = br.readLine();
            System.out.println("received response" + response);


        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public void add() {
        try (var socket = new Socket("localhost", 1234);
             var is = socket.getInputStream();
             var os = socket.getOutputStream();
             var br = new BufferedReader(new InputStreamReader(is))) {

            int nr1 = 1, nr2 = 2;

            String request = "add " + nr1 + " " + nr2 + "\n";
            os.write(request.getBytes());
            System.out.println("sent request: " + request);

            String response = br.readLine();
            System.out.println("received response: " + response);


        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}
