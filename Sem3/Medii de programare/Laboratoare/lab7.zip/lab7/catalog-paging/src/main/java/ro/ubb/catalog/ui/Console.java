package ro.ubb.catalog.ui;

import ro.ubb.catalog.domain.Student;
import ro.ubb.catalog.domain.validators.ValidatorException;
import ro.ubb.catalog.service.StudentService;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.Scanner;
import java.util.Set;
import java.util.stream.Stream;

/**
 * @author radu.
 */
public class Console {
    private StudentService studentService;

    public Console(StudentService studentService) {
        this.studentService = studentService;
    }

    public void runConsole() {
//        addStudents();
        printAllStudents();
//        filterStudents();

        printStudentsWithPaging();
    }

    private void printStudentsWithPaging() {
        Scanner scanner = new Scanner(System.in);
        System.out.println("enter page size: ");
        int size = scanner.nextInt();
        studentService.setPageSize(size);

        System.out.println("enter 'n' - for next; 'x' - for exit: ");

        while (true) {
            String cmd = scanner.next();
            if (cmd.equals("x")) {
                System.out.println("exit");
                break;
            }
            if (!cmd.equals("n")) {
                System.out.println("this option is not yet implemented");
                continue;
            }

            Set<Student> students = studentService.getNextStudents();
            if (students.size() == 0) {
                System.out.println("no more students");
                break;
            }
            students.forEach(student -> System.out.println(student));
        }
    }

    private void filterStudents() {
        System.out.println("filtered students (name containing 's2'):");
        Set<Student> students = studentService.filterStudentsByName("s2");
        students.stream().forEach(System.out::println);
    }

    private void printAllStudents() {
        Set<Student> students = studentService.getAllStudents();
        students.stream().forEach(System.out::println);
    }

    private void addStudents() {
//        while (true) {
//            Student student = readStudent();
//            if (student == null || student.getId() < 0) {
//                break;
//            }
//            try {
//                studentService.addStudent(student);
//            } catch (ValidatorException e) {
//                e.printStackTrace();
//            }
//        }
        Stream.generate(
                () -> {
                    try {
                        Student student = readStudent();
                        if (student == null || student.getId() < 0) {
                            throw new RuntimeException(
                                    "problem reading student");
                        }
                        try {
                            studentService.addStudent(student);
                        } catch (ValidatorException e) {
                            e.printStackTrace();
                        }
                    } catch (RuntimeException ex) {
                        ex.printStackTrace();
                    }

                    return new Object();
                }
        )
              .forEach(o -> System.out.println(""));
    }

    private Student readStudent() {
        System.out.println("Read student {id,serialNumber, name, group}");

        BufferedReader bufferRead = new BufferedReader(
                new InputStreamReader(System.in));
        try {
            Long id = Long.valueOf(bufferRead.readLine());// :(
            String serialNumber = bufferRead.readLine();
            String name = bufferRead.readLine();
            int group = Integer.parseInt(bufferRead.readLine());// :(

            Student student = new Student(serialNumber, name, group);
            student.setId(id);

            return student;
        } catch (IOException ex) {
            ex.printStackTrace();
        }
        return null;
    }
}
