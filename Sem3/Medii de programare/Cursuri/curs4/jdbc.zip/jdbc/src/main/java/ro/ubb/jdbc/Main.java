package ro.ubb.jdbc;

import java.util.List;

/**
 * Created by radu.
 */
public class Main {
    private static final String URL = "jdbc:postgresql://localhost:5432/catalog";
    private static final String USER = System.getProperty("username");
    private static final String PASSWORD = System.getProperty("password");


    public static void main(String[] args) {
        StudentRepository studentRepository = new StudentRepository(URL, USER, PASSWORD);

        Student student = new Student("sn1", "n1", 12);
        studentRepository.save(student);

        List<Student> all = studentRepository.findAll();
        all.forEach(System.out::println);



        Student update = new Student("sn-u", "n-u", 199);
        System.out.println("update:  " + all.get(0));
        studentRepository.update(all.get(0).getId(), update);

        System.out.println("after update...");
        all = studentRepository.findAll();
        all.forEach(System.out::println);



        System.out.println("delete: " + all.get(0));
        System.out.println("count: " + all.size());
        studentRepository.delete(all.get(0).getId());

        all = studentRepository.findAll();
        System.out.println("after delete: " + all.size());


    }
}
