package ro.ubb.reflection;

/**
 * Created by radu.
 */
public class Person {

    private String name;

    @Override
    public String toString() {
        return "Person{" +
                "name='" + name + '\'' +
                '}';
    }
}
