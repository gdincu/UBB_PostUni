package ro.ubb.catalog.domain.validators;

import ro.ubb.catalog.domain.Student;

/**
 * @author radu.
 */
public class StudentValidator implements Validator<Student> {
    @Override
    public void validate(Student entity) throws ValidatorException {
        //TODO validate student
    }
}
