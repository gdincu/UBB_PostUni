package ro.ubb.c6;

import java.util.Arrays;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

/**
 * Created by radu.
 * <p>
 * <p>
 * e07
 * * given the following list of persons (name, age)
 * * "Max", 18
 * * "Peter", 23
 * * "Pamela", 23
 * * "David", 12
 * * print:
 * * <p>
 * * 1. a list of persons whose name start with 'P'; (--> collectors)
 * * <p>
 * * 2. persons grouped by age
 * * <p>
 * * 3. the average age
 * * <p>
 * * 4. the person with max age (using reduce)
 */
public class Main {
    public static void main(String[] args) {

        List<Person> persons = Arrays.asList(
                new Person("Max", 18),
                new Person("Peter", 23),
                new Person("Pamela", 23),
                new Person("David", 12)
        );
        System.out.println(problem1(persons));

        problem2(persons);
        problem3(persons);
        problem4(persons);
    }

    private static void problem4(List<Person> persons) {
        persons.stream()
                .reduce((p1, p2) -> p1.getAge() > p2.getAge() ?  p1 : p2)
                .ifPresent(person -> System.out.println(person));
    }

    private static void problem3(List<Person> persons) {
        persons.stream()
                .map(person -> person.getAge())
                .mapToInt(age -> age)
                .average()
                .ifPresent(avg -> System.out.println(avg));
    }

    private static void problem2(List<Person> persons) {
        Map<Integer, List<Person>> ageGroups = persons.stream()
                .collect(Collectors.groupingBy(Person::getAge));
        System.out.println(ageGroups);
    }

    private static List<Person> problem1(List<Person> persons) {
        return persons.stream()
                .filter(person -> person.getName().startsWith("P"))
                .collect(Collectors.toList());
    }
}
