package ro.ubb.c6;

import java.util.Optional;

/**
 * Created by radu.
 * <p>
 * e05 - Optional
 */
public class Main {
    public static void main(String[] args) {

//        String res = m1();
//        if (res != null) {
//            System.out.println(res.toUpperCase());
//        } else {
//            System.out.println("bye");
//        }

        Optional<String> res = m1();
//        if (res.isPresent()) {
//            System.out.println(res.get().toUpperCase());
//        } else {
//            System.out.println("bye");
//        }
//        res.ifPresent(s -> System.out.println(s));

//        String r2 = res.orElse("bye");
//        System.out.println(r2);

        res.ifPresentOrElse(s -> System.out.println(s),
                () -> System.out.println("bye"));

        System.out.println(res.orElseThrow(() -> new RuntimeException("ssss")));





//        System.out.println("hello");
    }

    private static Optional<String> m1() {
        return Optional.ofNullable("hello");
    }
}
