package ro.ubb.c06;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.stream.IntStream;
import java.util.stream.Stream;

/**
 * Created by radu.
 * <p>
 * e06 - streams; interm & term oper
 * <p>
 * ["a1", "a2", "b1", "c2", "c1"]
 * 1. print the list elems that start with 'c', letters in uppercase, list
 * * elems sorted.
 * * -> intermediate and terminal operations.
 *
 * 2. print the first elem of a stream.
 *  * -> streamof
 *  *
 *  * 3. print ints in a range
 *  *
 *  * 4. given an intstream, double each value, compute avg.
 *  *
 *  * 5. given the strings ["a1", "a2", "a3"] (the first elem in a string is a
 *  * letter,
 *  * then only numbers), print the maximum number.
 */
public class Main {
    public static void main(String[] args) {
//        problem1();

        problem2();
        problem3();
        problem4();
        problem5();
    }

    private static void problem5() {
        Stream.of("a1", "a2", "a3")
                .map(s -> s.substring(1))
                .mapToInt(s -> Integer.parseInt(s))
                .max()
                .ifPresent(max -> System.out.println(max));
    }

    private static void problem4() {
        IntStream.range(1,4)
                .map(nr -> nr*2)
                .average()
                .ifPresent(avg -> System.out.println(avg));
    }

    private static void problem3() {
        IntStream.range(10, 20)
                .forEach(nr -> System.out.println(nr));
    }

    private static void problem2() {
        Stream.of("abc","def","hdhd")
                .findFirst()
                .ifPresent(s -> System.out.println(s));
    }

    private static void problem1() {
        List<String> list = Arrays.asList("a1", "a2", "b1", "c2", "c1", "c3");
        list.stream()
                .filter(x -> {
                    System.out.println("Filter: " + x);
                    return x.startsWith("c");
                })
                .map(x -> {
                    System.out.println("Map: " + x);
                    return x.toUpperCase();
                })
//                .map(x -> {
//                    System.out.println("Map 2: " + x);
//                    return x;
//                })
                .sorted()
                .forEach(System.out::println);
    }
}
