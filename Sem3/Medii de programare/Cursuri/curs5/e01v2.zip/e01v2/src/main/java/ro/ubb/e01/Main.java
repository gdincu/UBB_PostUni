package ro.ubb.e01;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

/**
 * Created by radu.
 * <p>
 * e01
 * Given a list of Employee (name, age, salary),
 * * * print the following reports (lists of employees):
 * * * - name contains the letter 'a'
 * * * - age is between 20 and 30
 * * * - salary higher than 1000
 * * * - age is between 20 and 30 AND salary higher than 1000
 * * * - name contains the letter 'a' and salary is higher than 1000
 * * * - etc
 */
public class Main {
    public static void main(String[] args) {
        List<Employee> employees = Arrays.asList(
                new Employee("e1", 19, 1000),
                new Employee("ana", 21, 1001),
                new Employee("qa", 40, 1002),
                new Employee("bbbb", 25, 1001)
        );

//        List<Employee> employeesNameContains = doFilter(employees,
//                new NameContainsCondition("a"));
//        List<Employee> employeesNameContains = doFilter(employees,
//                e -> e.getName().contains("a"));
        List<Employee> employeesNameContains = doFilter(employees,
                (Employee e) -> {
                    return e.getName().contains("a");
                });
        printEmployees(employeesNameContains);

        System.out.println("");
//        List<Employee> employeesAgeBetween = doFilter(employees,
//                new AgeBetweenCondition(20, 30));
        List<Employee> employeesAgeBetween = doFilter(employees,
                e -> e.getAge() < 30 && e.getAge() > 20);
        printEmployees(employeesAgeBetween);


        System.out.println("hello");
    }

    private static void printEmployees(List<Employee> employees) {
        employees.forEach(System.out::println);
    }

    private static List<Employee> doFilter(List<Employee> employees,
                                           Condition condition) {
        List<Employee> res = new ArrayList<>();
        for (Employee e : employees) {
            if (condition.test(e)) {
                res.add(e);
            }
        }
        return res;
    }
}

//@FunctionalInterface
interface Condition {
    boolean test(Employee employee);
//    boolean test2(Employee employee);
}

//class AgeBetweenCondition implements Condition {
//    private int age1;
//    private int age2;
//
//    public AgeBetweenCondition() {
//    }
//
//    public AgeBetweenCondition(int age1, int age2) {
//        this.age1 = age1;
//        this.age2 = age2;
//    }
//
//    @Override
//    public boolean test(Employee employee) {
//        return employee.getAge() < age2 && employee.getAge() > age1;
//    }
//}

//class NameContainsCondition implements Condition {
//    private String letter;
//
//    public NameContainsCondition(String letter) {
//        this.letter = letter;
//    }
//
//    @Override
//    public boolean test(Employee employee) {
//        return employee.getName().contains(this.letter);
//    }
//}

class Employee {
    private String name;
    private int age;
    private int salary;

    public Employee() {
    }

    public Employee(String name, int age, int salary) {
        this.name = name;
        this.age = age;
        this.salary = salary;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public int getAge() {
        return age;
    }

    public void setAge(int age) {
        this.age = age;
    }

    public int getSalary() {
        return salary;
    }

    public void setSalary(int salary) {
        this.salary = salary;
    }

    @Override
    public String toString() {
        return "Employee{" +
                "name='" + name + '\'' +
                ", age=" + age +
                ", salary=" + salary +
                '}';
    }
}
