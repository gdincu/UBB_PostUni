package ro.ubb.xml;


import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;
import java.io.File;
import java.util.ArrayList;
import java.util.List;

/**
 * Created by radu.
 */
public class Main {
    public static void main(String[] args) {
        List<Book> books = new ArrayList<>();
        try {
            books = loadBooksFromXML();
        } catch (Exception e) {
            e.printStackTrace();
        }
        books.forEach(System.out::println);


        try {
            saveToXML();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private static void saveToXML() throws Exception {
        DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();
        DocumentBuilder docBuilder = factory.newDocumentBuilder();
        Document booksDoc = docBuilder.parse("./data/bookstore.xml");

        Book book = new Book("c1", "title1", "author1", 2000, 10);
        addBookToDOM(booksDoc, book);

        Transformer transformer = TransformerFactory.newInstance().newTransformer();
        transformer.transform(new DOMSource(booksDoc),
                new StreamResult(new File("./data/bookstore2.xml")));

    }

    private static void addBookToDOM(Document booksDoc, Book book) {
        Node root = booksDoc.getDocumentElement();

        Element bookElement = createBookElement(booksDoc, book);

        root.appendChild(bookElement);
    }

    private static Element createBookElement(Document booksDoc, Book book) {
        Element bookElement = booksDoc.createElement("book");

        bookElement.setAttribute("category", book.getCategory());
        addChildWithTextContent(booksDoc, bookElement, "title", book.getTitle());
        addChildWithTextContent(booksDoc, bookElement, "author", book.getAuthor());
        addChildWithTextContent(booksDoc, bookElement, "price",
                Double.toString(book.getPrice()));
        addChildWithTextContent(booksDoc, bookElement, "year",
                Integer.toString(book.getYear()));

        return bookElement;
    }

    private static void addChildWithTextContent(Document document, Element parent,
                                                String tagName, String textContent) {
        Element element = document.createElement(tagName);
        element.setTextContent(textContent);
        parent.appendChild(element);
    }

    private static List<Book> loadBooksFromXML() throws Exception {
        DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();
        DocumentBuilder docBuilder = factory.newDocumentBuilder();
        Document booksDoc = docBuilder.parse("./data/bookstore.xml");

        Element root = booksDoc.getDocumentElement();
        NodeList children = root.getChildNodes();
        ArrayList<Book> books = new ArrayList<>();

        for (int i = 0; i < children.getLength(); i++) {
            Node current = children.item(i);
            if (current instanceof Element) {
                Book currentBook = createBookFromNode(current);
                books.add(currentBook);
            }
        }

        return books;
    }

    private static String getTextFromTagName(Element element, String tagName) {
        NodeList children = element.getElementsByTagName(tagName);
        Node valueNode = children.item(0);
        String value = valueNode.getTextContent();

        return value;
    }


    private static Book createBookFromNode(Node current) {
        Element bookElement = (Element) current;
//        NodeList childNodes = current.getChildNodes();
        Book book = new Book();

        String category = bookElement.getAttribute("category");
        book.setCategory(category);

        String title = getTextFromTagName(bookElement, "title");
        book.setTitle(title);

        String author = getTextFromTagName(bookElement, "author");
        book.setAuthor(author);

        int year = Integer.parseInt(getTextFromTagName(bookElement, "year"));
        book.setYear(year);


        double price = Double.parseDouble(getTextFromTagName(bookElement, "price"));
        book.setPrice(price);


        return book;
    }


}
